#!/bin/sh
# Установка DNet на macOS для текущего пользователя (без sudo). Запускать из распакованной папки: sh install.sh
# Если macOS пишет «разработчик не проверен»: xattr -dr com.apple.quarantine <папка>   (программа не подписана)
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
DEST="$HOME/Applications/DNet"
if [ "$1" = "--remove" ]; then
	"$DEST/dnet" --autostart off 2>/dev/null || true
	rm -rf "$DEST"; echo "DNet удалён (данные в ~/.dnet остались)"; exit 0
fi
mkdir -p "$DEST"
cp "$HERE/dnet" "$DEST/dnet"; chmod 755 "$DEST/dnet"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
for d in extension extension-firefox; do [ -d "$HERE/$d" ] && { rm -rf "$DEST/$d"; cp -r "$HERE/$d" "$DEST/$d"; }; done
echo "Установлено в $DEST. Запуск: $DEST/dnet --gui (окно) или $DEST/dnet (консоль)."
printf "Запускать при входе в систему? [y/N] "
read -r ans || ans=n
case "$ans" in y|Y) "$DEST/dnet" --autostart on ;; esac
