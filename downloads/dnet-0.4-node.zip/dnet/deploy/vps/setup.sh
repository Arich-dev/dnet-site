#!/bin/sh
# Установка сайта DNet на VPS (Debian/Ubuntu). Запускать от root:
#   sh setup.sh /tmp/dnet-site.tar.gz [server_name]
# Что делает: ставит nginx, если его нет, кладёт сайт в /var/www/dnet и добавляет один конфиг на порт 80.
# Чего НЕ делает: не трогает порт 443, Docker, iptables, чужие службы и конфиги; не включает файрвол.
# Если порт 80 занят не nginx — останавливается, ничего не меняя.
set -eu

ARCHIVE=${1:?"usage: sh setup.sh site.tar.gz [server_name]"}
NAME=${2:-_}
WEB=/var/www/dnet
CONF=/etc/nginx/conf.d/dnet.conf
HERE=$(dirname "$0")

[ "$(id -u)" = 0 ] || { echo "запусти от root"; exit 1; }
[ -f "$ARCHIVE" ] || { echo "нет архива $ARCHIVE"; exit 1; }
[ -f "$HERE/nginx-dnet.conf" ] || { echo "нет $HERE/nginx-dnet.conf"; exit 1; }

echo "== порт 80"
if ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq '[:.]80$'; then
    if ss -ltnp 2>/dev/null | grep -E '[:.]80[[:space:]]' | grep -q nginx; then
        echo "порт 80 уже слушает nginx — работаем с ним"
    else
        echo "ОШИБКА: порт 80 занят не nginx, выхожу ничего не меняя:"
        ss -ltnp | grep -E '[:.]80[[:space:]]'
        exit 2
    fi
fi

FRESH=0
if ! command -v nginx >/dev/null 2>&1; then
    echo "== ставлю nginx"
    DEBIAN_FRONTEND=noninteractive apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends nginx
    FRESH=1
fi

echo "== кладу сайт в $WEB"
rm -rf "$WEB.new"
mkdir -p "$WEB.new"
tar -xzf "$ARCHIVE" -C "$WEB.new"
chmod -R a+rX "$WEB.new"
rm -rf "$WEB.old"
[ -d "$WEB" ] && mv "$WEB" "$WEB.old"
mv "$WEB.new" "$WEB"
rm -rf "$WEB.old"

echo "== конфиг nginx"
# стандартную заглушку убираем только если nginx поставили мы сами
if [ "$FRESH" = 1 ] && [ -L /etc/nginx/sites-enabled/default ]; then
    rm -f /etc/nginx/sites-enabled/default
fi
OLD=""
[ -f "$CONF" ] && { OLD=$(mktemp); cp "$CONF" "$OLD"; }
sed "s/__SERVER_NAME__/$NAME/" "$HERE/nginx-dnet.conf" > "$CONF"
if ! nginx -t 2>/tmp/nginx-test.log; then
    echo "ОШИБКА в конфиге nginx, откатываю:"; cat /tmp/nginx-test.log
    if [ -n "$OLD" ]; then cp "$OLD" "$CONF"; else rm -f "$CONF"; fi
    exit 3
fi
systemctl enable nginx >/dev/null 2>&1 || true
systemctl reload nginx 2>/dev/null || systemctl start nginx

echo "== файрвол"
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
    ufw allow 80/tcp >/dev/null && echo "ufw: разрешён 80/tcp"
else
    echo "ufw не активен — правил не трогаю"
fi

echo "== готово"
curl -s -o /dev/null -w "локальная проверка: HTTP %{http_code}\n" http://127.0.0.1/ || true
