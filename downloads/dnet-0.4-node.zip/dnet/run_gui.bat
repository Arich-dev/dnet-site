@echo off
rem DNet: window + tray icon, no console. Needs Python 3.8+ with Tk (included by default on Windows).
cd /d "%~dp0"
where pythonw >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.8+ from python.org and tick "Add to PATH".
    pause
    exit /b 1
)
start "" pythonw daemon\main.py --gui %*
