"""Связь через NAT: постоянный канал, ретранслятор и пробивка.

Если узел за NAT и роутер не открыл порт (CGNAT, UPnP выключен), до него не достучаться. Тогда:

* Ретранслятор. Узел A (за NAT) держит исходящее соединение с публичным узлом R. Когда узел B хочет
  спросить A, он отправляет запрос R (op "fwd"), R по каналу передаёт его A и возвращает ответ.
  Это не прокси общего назначения: пересылаются только запросы протокола DNet (hello, index, get, …).
* Пробивка (hole punching). Два узла за NAT через R обмениваются своими внешними адресами и одновременно
  подключаются друг к другу с того же локального порта, с которого соединены с R (TCP simultaneous open).
  Получилось — дальше говорят напрямую по постоянному каналу, а R не нагружается. Не получилось (симметричный NAT,
  CGNAT с разными портами) — остаётся ретранслятор.

Канал (Channel) — одно постоянное TCP-соединение, по которому с обеих сторон идут запросы и ответы.
Кадр: строка JSON {"t": "req"|"res"|"ping", "rid": N, "len": L} и L байт: запрос — JSON, ответ — то же,
что вернул бы обычный ответ узла (строка заголовка и тело).
"""
import json
import socket
import threading
import time

import dlog

MAX_PAGE = 20 * 1024 * 1024
LIMIT = MAX_PAGE + 65536
ALLOWED = {"hello", "index", "peers", "hot", "get", "wiki", "want", "punch"}  # что можно пересылать через ретранслятор
PING = 20
IDLE = 75


def split_reply(raw):
    """Ответ узла (строка JSON + тело) -> (head, body) либо None."""
    try:
        line, _, rest = raw.partition(b"\n")
        head = json.loads(line)
        n = head.pop("len", 0) if isinstance(head, dict) else 0
        if not isinstance(n, int) or not 0 <= n <= MAX_PAGE or len(rest) < n:
            return None
        return head, rest[:n]
    except ValueError:
        return None


class Channel:
    """Постоянное соединение с запросами в обе стороны."""

    def __init__(self, sock, handler, on_close=None, name=""):
        self.sock, self.handler, self.on_close, self.name = sock, handler, on_close, name
        self.f = sock.makefile("rb")
        self.wlock = threading.Lock()
        self.pending = {}
        self.rid = 0
        self.alive = True
        self.sock.settimeout(IDLE)

    def start(self):
        threading.Thread(target=self._read, daemon=True, name="chan-r").start()
        threading.Thread(target=self._ping, daemon=True, name="chan-p").start()

    def _send(self, t, rid, payload=b""):
        hdr = json.dumps({"t": t, "rid": rid, "len": len(payload)}).encode() + b"\n"
        with self.wlock:
            self.sock.sendall(hdr + payload)

    def _ping(self):
        while self.alive:
            time.sleep(PING)
            try:
                self._send("ping", 0)
            except OSError:
                self.close()

    def request(self, msg, timeout=15):
        """Отправляет запрос; возвращает байты ответа или None."""
        if not self.alive:
            return None
        with self.wlock:
            self.rid += 1
            rid = self.rid
        slot = [threading.Event(), None]
        self.pending[rid] = slot
        try:
            self._send("req", rid, json.dumps(msg).encode())
        except OSError:
            self.pending.pop(rid, None)
            self.close()
            return None
        slot[0].wait(timeout)
        self.pending.pop(rid, None)
        return slot[1]

    def _read(self):
        try:
            while self.alive:
                line = self.f.readline(2048)
                if not line:
                    break
                h = json.loads(line)
                n = int(h.get("len", 0))
                if not 0 <= n <= LIMIT:
                    break
                payload = self.f.read(n) if n else b""
                if len(payload) != n:
                    break
                t, rid = h.get("t"), h.get("rid")
                if t == "req":
                    threading.Thread(target=self._serve, args=(rid, payload), daemon=True).start()
                elif t == "res":
                    slot = self.pending.get(rid)
                    if slot:
                        slot[1] = payload
                        slot[0].set()
        except (OSError, ValueError):
            pass
        finally:
            self.close()

    def _serve(self, rid, payload):
        try:
            out = self.handler(json.loads(payload)) or b'{"error": "bad op"}\n'
            self._send("res", rid, out)
        except (OSError, ValueError):
            self.close()
        except Exception as e:
            dlog.exc("channel serve", e)

    def close(self):
        if not self.alive:
            return
        self.alive = False
        for slot in list(self.pending.values()):
            slot[0].set()
        try:
            self.sock.close()
        except OSError:
            pass
        if self.on_close:
            self.on_close(self)


# ---------- ретранслятор: сервер ----------
class RelayServer:
    """Публичный узел: принимает исходящие каналы от узлов за NAT и передаёт им запросы других."""

    def __init__(self, cfg, p2p):
        self.cfg, self.p2p = cfg, p2p
        self.clients = {}
        self.lock = threading.Lock()

    def serving(self):
        """auto — служим, только если до нас можно достучаться снаружи; true/false — принудительно."""
        mode = (self.cfg.get("relay") or {}).get("serve", "auto")
        if mode == "auto":
            return self.p2p.nat.reachable is True
        return bool(mode)

    def attach(self, sock, msg, ip, port):
        """Новый канал от узла за NAT (op "relay"). Возвращает True, если сокет теперь наш."""
        pid = msg.get("id")
        if not (self.serving() and self.p2p.valid_hello({**msg, "op": "hello"})):
            self._deny(sock, "no relay")
            return False
        with self.lock:
            if len(self.clients) >= int((self.cfg.get("relay") or {}).get("max_clients", 20)) and pid not in self.clients:
                self._deny(sock, "full")
                return False
        try:
            sock.sendall(json.dumps({"ok": True, "you": [ip, port]}).encode() + b"\n")
        except OSError:
            return False
        chan = Channel(sock, lambda m: None, on_close=lambda c: self._gone(pid, c), name="relay-client")
        with self.lock:
            old = self.clients.get(pid)
            self.clients[pid] = {"chan": chan, "ep": (ip, port), "nick": str(msg["nick"])[:32], "sup": bool(msg["sup"]),
                                 "kiwix": msg.get("kiwix") is True}
        if old:
            old["chan"].close()
        chan.start()
        dlog.log(f"relay: подключился {pid} ({ip}:{port}), клиентов {len(self.clients)}")
        return True

    @staticmethod
    def _deny(sock, why):
        try:
            sock.sendall(json.dumps({"ok": False, "error": why}).encode() + b"\n")
        except OSError:
            pass

    def _gone(self, pid, chan):
        with self.lock:
            c = self.clients.get(pid)
            if c and c["chan"] is chan:
                del self.clients[pid]
                dlog.log(f"relay: отключился {pid}")

    def forward(self, to, msg):
        if not isinstance(msg, dict) or msg.get("op") not in ALLOWED:
            return None
        with self.lock:
            c = self.clients.get(to)
        return c["chan"].request(msg, timeout=20) if c else None

    def listing(self):
        with self.lock:
            return [[pid, c["nick"], c["sup"], c["kiwix"], c["ep"][0], c["ep"][1]] for pid, c in self.clients.items()]


# ---------- ретранслятор: клиент ----------
class RelayClient:
    """Узел за NAT: держит каналы с 1–2 публичными ретрансляторами и пробивает прямые соединения."""

    def __init__(self, cfg, p2p):
        self.cfg, self.p2p = cfg, p2p
        self.chans = {}   # id ретранслятора -> Channel
        self.me = None    # наш внешний адрес [ip, port], как его видит ретранслятор
        self.lport = 0    # локальный порт канала; с него же пробиваем NAT
        self.tried = {}
        self.punched = set()

    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="relay-client").start()

    def wanted(self):
        return bool((self.cfg.get("relay") or {}).get("use", True)) and self.p2p.nat.reachable is False

    def _loop(self):
        while True:
            time.sleep(10)
            try:
                if self.wanted():
                    self.ensure()
                else:
                    self.drop()
            except Exception as e:
                dlog.exc("relay client", e)

    def drop(self):
        for c in list(self.chans.values()):
            c.close()
        self.chans.clear()

    def ensure(self):
        for pid in [k for k, c in self.chans.items() if not c.alive]:
            del self.chans[pid]
        cands = [p for p in self.p2p.alive() if p.get("relay_ok") and not p.get("relay") and not p["bt"]]
        for p in cands:
            if len(self.chans) >= 2:
                break
            if p["id"] not in self.chans:
                self.connect(p)

    def sock(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        try:
            s.bind(("0.0.0.0", self.lport))
        except OSError:
            s.bind(("0.0.0.0", 0))
        self.lport = s.getsockname()[1]
        return s

    def connect(self, p):
        s = self.sock()
        s.settimeout(6)
        try:
            s.connect((p["ip"], p["port"]))
            s.sendall(json.dumps({**self.p2p.hello_msg(), "op": "relay"}).encode() + b"\n")
            reply = json.loads(s.makefile("rb").readline(4096))
        except (OSError, ValueError):
            s.close()
            return
        if not (isinstance(reply, dict) and reply.get("ok")):
            s.close()
            return
        self.me = reply.get("you")
        chan = Channel(s, self.p2p.serve_bytes, name="to-relay")
        self.chans[p["id"]] = chan
        chan.start()
        dlog.log(f"relay: канал к {p['ip']}:{p['port']}, наш внешний адрес {self.me}")

    # ----- пробивка -----
    def initiate(self, p):
        """B -> A через ретранслятор: обменяться адресами и одновременно подключиться."""
        if not (self.cfg.get("punch", True) and self.me and p.get("ep")) or p.get("chan") and p["chan"].alive:
            return
        if time.time() - self.tried.get(p["id"], 0) < 600:
            return
        self.tried[p["id"]] = time.time()
        threading.Thread(target=self._initiate, args=(p,), daemon=True, name="punch").start()

    def _initiate(self, p):
        r = self.p2p.rpc(p, {"op": "punch", "id": self.p2p.id, "ep": self.me}, timeout=10)
        if r and r[0].get("ok") and self.valid_ep(r[0].get("ep")):
            self.run(p["id"], tuple(r[0]["ep"]))

    def on_punch(self, msg):
        """Нас просят пробить NAT (op punch, пришёл через ретранслятор)."""
        if not (self.cfg.get("punch", True) and self.me and self.valid_ep(msg.get("ep")) and isinstance(msg.get("id"), str)):
            return {"ok": False}
        threading.Thread(target=self.run, args=(msg["id"], tuple(msg["ep"])), daemon=True, name="punch").start()
        return {"ok": True, "ep": self.me}

    @staticmethod
    def valid_ep(ep):
        try:
            socket.inet_aton(ep[0])
            return isinstance(ep[1], int) and 0 < ep[1] < 65536
        except (OSError, TypeError, IndexError):
            return False

    def run(self, pid, ep, seconds=7):
        end = time.time() + seconds
        while time.time() < end and pid not in self.punched:
            s = self.sock()
            s.settimeout(0.8)
            try:
                s.connect(ep)
            except OSError:
                s.close()
                time.sleep(0.15)
                continue
            if self.p2p.adopt_channel(pid, s):
                self.punched.add(pid)
                dlog.log(f"punch: прямое соединение с {pid} через {ep}")
                return
            s.close()
            return
        dlog.log(f"punch: не вышло с {pid} (остаёмся на ретрансляторе)")
