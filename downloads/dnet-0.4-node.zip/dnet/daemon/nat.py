"""Доступность узла снаружи: автопроброс порта (UPnP IGD, NAT-PMP) и проверка «достучится ли сосед».

Пока узел за NAT без проброса, до него не достучаться. Здесь два шага:
1. Просим роутер открыть наш TCP-порт (UPnP, затем NAT-PMP). Проброс снимается при выходе и обновляется каждый час.
2. Проверяем результат: публичный сосед пробует подключиться к нам обратно (op "whoami"). Итог — nat.reachable:
   True (до нас можно достучаться), False (мы за NAT: используем ретранслятор и пробивку), None (пока неизвестно).
"""
import ipaddress
import os
import re
import socket
import struct
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse

import dlog
import netcheck

SSDP = ("239.255.255.250", 1900)
ST = "urn:schemas-upnp-org:device:InternetGatewayDevice:1"
LEASE = 3600
SOAP = ('<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
        's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:{act} xmlns:u="{svc}">{args}</u:{act}>'
        '</s:Body></s:Envelope>')


def local_ip_towards(host):
    """Наш адрес в сети, из которой достижим host (адрес интерфейса, который увидит роутер)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((host, 9))
        return s.getsockname()[0]
    finally:
        s.close()


def is_public(ip):
    if os.environ.get("DNET_REGISTRY_PRIVATE"):  # тесты на одном компьютере: частные адреса считаем публичными
        return True
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


class UPnP:
    """Минимальный клиент UPnP IGD (WANIPConnection / WANPPPConnection)."""

    def __init__(self):
        self.ctl = None
        self.svc = None

    def discover(self, timeout=2.5):
        msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n"
               f"ST: {ST}\r\n\r\n").encode()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        try:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            s.sendto(msg, SSDP)
            end = time.time() + timeout
            while time.time() < end:
                try:
                    data, addr = s.recvfrom(4096)
                except socket.timeout:
                    break
                m = re.search(rb"(?im)^location:\s*(\S+)", data)
                if not m:
                    continue
                loc = m.group(1).decode("ascii", "ignore")
                # описание устройства берём только у того, кто ответил: защита от подмены адреса
                if urlparse(loc).hostname == addr[0] and self._load(loc):
                    return True
        except OSError as e:
            dlog.exc("upnp discover", e)
        finally:
            s.close()
        return False

    def _load(self, loc):
        try:
            with urllib.request.urlopen(loc, timeout=3) as r:
                root = ET.fromstring(r.read(200000))
        except Exception:
            return False
        base = loc
        for el in root.iter():
            if el.tag.endswith("URLBase") and el.text:
                base = el.text
        for svc in root.iter():
            if not svc.tag.endswith("service"):
                continue
            kv = {c.tag.split("}")[-1]: (c.text or "") for c in svc}
            if re.search(r"WAN(IP|PPP)Connection", kv.get("serviceType", "")) and kv.get("controlURL"):
                url = urljoin(base, kv["controlURL"])
                if urlparse(url).hostname == urlparse(loc).hostname:
                    self.ctl, self.svc = url, kv["serviceType"]
                    return True
        return False

    def call(self, act, args=""):
        body = SOAP.format(act=act, svc=self.svc, args=args).encode()
        req = urllib.request.Request(self.ctl, data=body, headers={
            "Content-Type": 'text/xml; charset="utf-8"', "SOAPAction": f'"{self.svc}#{act}"'})
        with urllib.request.urlopen(req, timeout=4) as r:
            return r.read(100000).decode("utf-8", "ignore")

    def external_ip(self):
        m = re.search(r"<NewExternalIPAddress>([^<]*)<", self.call("GetExternalIPAddress"))
        return m.group(1) if m else None

    def add(self, port, internal_ip, lease=LEASE):
        args = (f"<NewRemoteHost></NewRemoteHost><NewExternalPort>{port}</NewExternalPort><NewProtocol>TCP</NewProtocol>"
                f"<NewInternalPort>{port}</NewInternalPort><NewInternalClient>{internal_ip}</NewInternalClient>"
                f"<NewEnabled>1</NewEnabled><NewPortMappingDescription>DNet</NewPortMappingDescription>"
                f"<NewLeaseDuration>{lease}</NewLeaseDuration>")
        try:
            self.call("AddPortMapping", args)
        except urllib.error.HTTPError:
            if lease:  # часть роутеров принимает только бессрочный проброс
                return self.add(port, internal_ip, 0)
            raise

    def remove(self, port):
        self.call("DeletePortMapping", f"<NewRemoteHost></NewRemoteHost><NewExternalPort>{port}</NewExternalPort>"
                                       "<NewProtocol>TCP</NewProtocol>")


def pmp_request(gateway, payload, timeout=1.5):
    """Запрос NAT-PMP (RFC 6886) к шлюзу: UDP 5351, три попытки."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        for _ in range(3):
            s.sendto(payload, (gateway, 5351))
            try:
                data, addr = s.recvfrom(64)
            except socket.timeout:
                continue
            if addr[0] == gateway:
                return data
    except OSError:
        pass
    finally:
        s.close()
    return None


def pmp_external_ip(gateway):
    d = pmp_request(gateway, struct.pack("!BB", 0, 0))
    if d and len(d) >= 12:
        _, op, result, _, ip = struct.unpack("!BBHI4s", d[:12])
        if op == 128 and result == 0:
            return socket.inet_ntoa(ip)
    return None


def pmp_map(gateway, port, lease=LEASE):
    d = pmp_request(gateway, struct.pack("!BBHHHI", 0, 2, 0, port, port, lease))
    if d and len(d) >= 16:
        _, op, result, _, _, ext, _ = struct.unpack("!BBHIHHI", d[:16])
        return op == 130 and result == 0 and ext == port
    return False


class Nat:
    """Состояние доступности. reachable: True / False / None (не знаем)."""

    def __init__(self, cfg, p2p, tcp_port):
        self.cfg, self.p2p, self.port = cfg, p2p, tcp_port
        self.reachable = None
        self.mapping = None  # "upnp" | "natpmp" | None
        self.ext_ip = None
        self.cgnat = False
        self.note = "ещё не проверено"
        self.upnp = None
        self.last_probe = 0.0
        self.force = None  # для тестов: принудительно «за NAT» (DNET_FORCE_NAT=1)

    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="nat").start()

    def stop(self):
        """Снимает проброс при выходе (если ставили)."""
        try:
            if self.mapping == "upnp" and self.upnp:
                self.upnp.remove(self.port)
        except Exception:
            pass

    def _loop(self):
        time.sleep(8)
        while True:
            try:
                self.refresh()
            except Exception as e:
                dlog.exc("nat", e)
            time.sleep(3600 if self.reachable else 120)

    def refresh(self):
        if self.cfg.get("nat", {}).get("upnp", True) and not os.environ.get("DNET_NO_UPNP") and not self.force:
            self.map_port()
        self.probe()

    def map_port(self):
        gw = netcheck.gateway()
        if not gw:
            return
        try:
            ip = local_ip_towards(gw)
        except OSError:
            return
        up = UPnP()
        try:
            if up.discover():
                up.add(self.port, ip)
                self.upnp, self.mapping = up, "upnp"
                ext = up.external_ip()
                self._ext(ext)
                dlog.log(f"nat: UPnP-проброс {self.port} -> {ip}, внешний адрес {ext}")
                return
        except Exception as e:
            dlog.exc("nat upnp", e)
        try:
            ext = pmp_external_ip(gw)
            if ext is not None and pmp_map(gw, self.port):
                self.mapping = "natpmp"
                self._ext(ext)
                dlog.log(f"nat: NAT-PMP проброс {self.port}, внешний адрес {ext}")
                return
        except Exception as e:
            dlog.exc("nat pmp", e)
        self.mapping = None

    def _ext(self, ip):
        self.ext_ip = ip
        self.cgnat = bool(ip) and not is_public(ip)  # роутер сам за NAT провайдера: проброс бесполезен

    def probe(self):
        """Спрашиваем публичных соседей, достучатся ли они до нас. Один «да» — достаточно."""
        if self.force:
            self.reachable, self.note = False, "принудительно за NAT (тест)"
            return
        results = []
        for p in self.p2p.alive():
            if p["kind"] == "router" or p.get("relay") or p["bt"] or not is_public(p["ip"]):
                continue
            r = self.p2p.rpc(p, {"op": "whoami", "port": self.port}, timeout=8)
            if r and isinstance(r[0].get("ip"), str):
                results.append(bool(r[0].get("back")))
                if r[0].get("back"):
                    break
            if len(results) >= 3:
                break
        self.last_probe = time.time()
        if any(results):
            self.reachable = True
            self.note = {"upnp": "открыт через UPnP", "natpmp": "открыт через NAT-PMP"}.get(self.mapping, "доступен напрямую")
        elif results:
            self.reachable = False
            self.note = "CGNAT у провайдера: проброс бесполезен" if self.cgnat else "за NAT, порт закрыт"
        else:
            self.note = "нет публичных соседей для проверки"

    def status(self):
        return {"reachable": self.reachable, "mapping": self.mapping, "ext_ip": self.ext_ip, "cgnat": self.cgnat,
                "note": self.note}
