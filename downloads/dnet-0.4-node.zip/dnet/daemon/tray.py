"""Значок в системном трее. Windows: чистый ctypes (без зависимостей). Linux: pystray, если установлен.

Tray(on_event, menu_cb): on_event(имя, данные) вызывается из потока трея, menu_cb() даёт пункты меню
[(событие, подпись, отмечен)], None — разделитель. set_state(состояние, подсказка) меняет цвет значка.
"""
import os
import threading

import icon

STATES = ("ok", "warn", "bad", "off")


class NullTray:
    available = False

    def __init__(self, *a, **k):
        pass

    def start(self):
        return False

    def set_state(self, *a):
        pass

    def stop(self):
        pass


if os.name == "nt":
    import ctypes
    from ctypes import wintypes as w

    u32 = ctypes.WinDLL("user32", use_last_error=True)
    s32 = ctypes.WinDLL("shell32", use_last_error=True)
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    LRESULT = ctypes.c_ssize_t
    WNDPROC = ctypes.WINFUNCTYPE(LRESULT, w.HWND, w.UINT, w.WPARAM, w.LPARAM)

    class WNDCLASS(ctypes.Structure):
        _fields_ = [("style", w.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int),
                    ("cbWndExtra", ctypes.c_int), ("hInstance", w.HINSTANCE), ("hIcon", w.HICON),
                    ("hCursor", w.HANDLE), ("hbrBackground", w.HBRUSH), ("lpszMenuName", w.LPCWSTR),
                    ("lpszClassName", w.LPCWSTR)]

    class GUID(ctypes.Structure):
        _fields_ = [("a", ctypes.c_ulong), ("b", ctypes.c_ushort), ("c", ctypes.c_ushort), ("d", ctypes.c_ubyte * 8)]

    class NID(ctypes.Structure):
        _fields_ = [("cbSize", w.DWORD), ("hWnd", w.HWND), ("uID", w.UINT), ("uFlags", w.UINT),
                    ("uCallbackMessage", w.UINT), ("hIcon", w.HICON), ("szTip", w.WCHAR * 128),
                    ("dwState", w.DWORD), ("dwStateMask", w.DWORD), ("szInfo", w.WCHAR * 256),
                    ("uVersion", w.UINT), ("szInfoTitle", w.WCHAR * 64), ("dwInfoFlags", w.DWORD),
                    ("guidItem", GUID), ("hBalloonIcon", w.HICON)]

    u32.DefWindowProcW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
    u32.DefWindowProcW.restype = LRESULT
    u32.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASS)]
    u32.RegisterClassW.restype = w.ATOM
    u32.CreateWindowExW.argtypes = [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, w.HWND, w.HMENU, w.HINSTANCE, w.LPVOID]
    u32.CreateWindowExW.restype = w.HWND
    u32.LoadImageW.argtypes = [w.HINSTANCE, w.LPCWSTR, w.UINT, ctypes.c_int, ctypes.c_int, w.UINT]
    u32.LoadImageW.restype = w.HANDLE
    u32.CreatePopupMenu.restype = w.HMENU
    u32.AppendMenuW.argtypes = [w.HMENU, w.UINT, ctypes.c_size_t, w.LPCWSTR]
    u32.TrackPopupMenu.argtypes = [w.HMENU, w.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.HWND, w.LPVOID]
    u32.DestroyMenu.argtypes = [w.HMENU]
    u32.SetForegroundWindow.argtypes = [w.HWND]
    u32.PostMessageW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
    u32.GetMessageW.argtypes = [ctypes.POINTER(w.MSG), w.HWND, w.UINT, w.UINT]
    u32.TranslateMessage.argtypes = [ctypes.POINTER(w.MSG)]
    u32.DispatchMessageW.argtypes = [ctypes.POINTER(w.MSG)]
    u32.DestroyWindow.argtypes = [w.HWND]
    u32.RegisterWindowMessageW.argtypes = [w.LPCWSTR]
    u32.GetCursorPos.argtypes = [ctypes.POINTER(w.POINT)]
    s32.Shell_NotifyIconW.argtypes = [w.DWORD, ctypes.POINTER(NID)]
    k32.GetModuleHandleW.argtypes = [w.LPCWSTR]
    k32.GetModuleHandleW.restype = w.HINSTANCE

    WM_USER_TRAY = 0x0400 + 20
    WM_CLOSE, WM_DESTROY = 0x0010, 0x0002
    WM_LBUTTONUP, WM_LBUTTONDBLCLK, WM_RBUTTONUP = 0x0202, 0x0203, 0x0205
    NIM_ADD, NIM_MODIFY, NIM_DELETE = 0, 1, 2
    NIF_MESSAGE, NIF_ICON, NIF_TIP = 1, 2, 4
    MF_STRING, MF_CHECKED, MF_SEPARATOR = 0, 8, 0x800
    TPM_RETURNCMD_FLAGS = 0x0100 | 0x0080 | 0x0002

    class Tray:
        available = True

        def __init__(self, on_event, menu_cb, home):
            self.on_event = on_event
            self.menu_cb = menu_cb
            self.hwnd = None
            self.state = "off"
            self.tip = "DNet"
            self.icons = {}
            self.ready = threading.Event()
            self.ok = False
            folder = os.path.join(home, "icons")
            os.makedirs(folder, exist_ok=True)
            for st in STATES:
                path = os.path.join(folder, f"tray-{st}.ico")
                with open(path, "wb") as f:
                    f.write(icon.ico((16, 20, 24, 32, 48), st))
                self.icons[st] = path
            self.hicons = {}

        def start(self):
            threading.Thread(target=self._loop, daemon=True, name="tray").start()
            self.ready.wait(5)
            return self.ok

        def _hicon(self, st):
            if st not in self.hicons:
                self.hicons[st] = u32.LoadImageW(None, self.icons[st], 1, 0, 0, 0x10 | 0x40)
            return self.hicons[st]

        def _nid(self, flags):
            n = NID()
            n.cbSize = ctypes.sizeof(NID)
            n.hWnd = self.hwnd
            n.uID = 1
            n.uFlags = flags
            n.uCallbackMessage = WM_USER_TRAY
            n.hIcon = self._hicon(self.state)
            n.szTip = self.tip[:127]
            return n

        def set_state(self, state, tip):
            state = state if state in STATES else "off"
            if (state, tip) == (self.state, self.tip) or not self.hwnd:
                return
            self.state, self.tip = state, tip
            s32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self._nid(NIF_ICON | NIF_TIP | NIF_MESSAGE)))

        def stop(self):
            if self.hwnd:
                u32.PostMessageW(self.hwnd, WM_CLOSE, 0, 0)

        def _menu(self):
            items = self.menu_cb()
            menu = u32.CreatePopupMenu()
            ids = {}
            for i, it in enumerate(items, 1):
                if it is None:
                    u32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
                    continue
                ev, label, checked = it
                ids[i] = ev
                u32.AppendMenuW(menu, MF_STRING | (MF_CHECKED if checked else 0), i, label)
            pt = w.POINT()
            u32.GetCursorPos(ctypes.byref(pt))
            u32.SetForegroundWindow(self.hwnd)  # без этого меню не закрывается кликом мимо
            cmd = u32.TrackPopupMenu(menu, TPM_RETURNCMD_FLAGS, pt.x, pt.y, 0, self.hwnd, None)
            u32.PostMessageW(self.hwnd, 0, 0, 0)
            u32.DestroyMenu(menu)
            if cmd:
                self.on_event(ids[cmd], None)

        def _loop(self):
            created = u32.RegisterWindowMessageW("TaskbarCreated")

            def proc(hwnd, msg, wp, lp):
                try:
                    if msg == WM_USER_TRAY:
                        low = lp & 0xFFFF
                        if low == WM_LBUTTONUP:
                            pt = w.POINT()
                            u32.GetCursorPos(ctypes.byref(pt))
                            self.on_event("mini", (pt.x, pt.y))
                        elif low == WM_LBUTTONDBLCLK:
                            self.on_event("show", None)
                        elif low == WM_RBUTTONUP:
                            self._menu()
                        return 0
                    if msg == created:  # проводник перезапустился — вернуть значок
                        s32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(self._nid(NIF_ICON | NIF_TIP | NIF_MESSAGE)))
                        return 0
                    if msg == WM_CLOSE:
                        s32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self._nid(0)))
                        u32.DestroyWindow(hwnd)
                        return 0
                    if msg == WM_DESTROY:
                        u32.PostMessageW(None, 0x0012, 0, 0)  # WM_QUIT
                        return 0
                except Exception:
                    return 0
                return u32.DefWindowProcW(hwnd, msg, wp, lp)

            self._proc = WNDPROC(proc)  # держим ссылку, иначе соберёт сборщик мусора
            wc = WNDCLASS()
            wc.lpfnWndProc = self._proc
            wc.hInstance = k32.GetModuleHandleW(None)
            wc.lpszClassName = "DNetTrayWindow"
            u32.RegisterClassW(ctypes.byref(wc))
            self.hwnd = u32.CreateWindowExW(0, wc.lpszClassName, "DNet", 0, 0, 0, 0, 0, None, None, wc.hInstance, None)
            if not self.hwnd:
                self.ready.set()
                return
            self.ok = bool(s32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(self._nid(NIF_ICON | NIF_TIP | NIF_MESSAGE))))
            self.ready.set()
            msg = w.MSG()
            while u32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                u32.TranslateMessage(ctypes.byref(msg))
                u32.DispatchMessageW(ctypes.byref(msg))

else:
    class Tray:
        """Linux/BSD: нужен пакет pystray (pip install pystray pillow); иначе значка нет, окно просто сворачивается."""
        available = False

        def __init__(self, on_event, menu_cb, home):
            self.on_event, self.menu_cb = on_event, menu_cb
            self.icon = None
            self.images = {}
            self.state = "off"

        def start(self):
            try:
                import io

                import pystray
                from PIL import Image
            except Exception:
                return False
            for st in STATES:
                self.images[st] = Image.open(io.BytesIO(icon.png(64, st)))

            def build():
                items = []
                for it in self.menu_cb():
                    if it is None:
                        items.append(pystray.Menu.SEPARATOR)
                    else:
                        ev, label, checked = it
                        items.append(pystray.MenuItem(label, lambda i, e, ev=ev: self.on_event(ev, None),
                                                      checked=(lambda i, c=checked: c) if checked else None,
                                                      default=(ev == "show")))
                return items

            self.icon = pystray.Icon("dnet", self.images["off"], "DNet", pystray.Menu(build))
            self.icon.run_detached()
            self.available = True
            return True

        def set_state(self, state, tip):
            if self.icon and state in self.images:
                self.icon.icon = self.images[state]
                self.icon.title = tip

        def stop(self):
            if self.icon:
                self.icon.stop()
