import re
import socket
import threading
import time

import dlog
from p2p import BT

MAC = re.compile(r"([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}")


class Bluetooth:
    def __init__(self, cfg, p2p):
        self.cfg = cfg["bluetooth"]
        self.p2p = p2p
        self.status = "выкл"

    def start(self):
        if not self.cfg["enabled"]:
            return
        if BT is None:
            self.status = "нет поддержки в этом Python"
            return
        self.status = "запуск"
        threading.Thread(target=self._serve, daemon=True).start()
        threading.Thread(target=self._scan, daemon=True).start()

    def _serve(self):
        ch = int(self.cfg["channel"])
        try:
            s = socket.socket(BT, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM)
            try:
                s.bind(("00:00:00:00:00:00", ch))
            except OSError:
                s.bind(("", ch))
            s.listen(5)
            self.status = f"слушаю канал {ch}"
        except Exception as e:
            self.status = f"ошибка: {e}"
            dlog.exc("bluetooth serve", e)
            return
        while True:
            try:
                c, _ = s.accept()
                threading.Thread(target=self._client, args=(c,), daemon=True).start()
            except OSError:
                time.sleep(1)

    def _client(self, c):
        try:
            with c:
                c.settimeout(10)
                self.p2p.handle(c.makefile("rb"), c.sendall)
        except Exception:
            pass

    def _scan(self):
        while True:
            addrs = set(self.cfg.get("peers", []))
            try:
                import bluetooth
                addrs.update(bluetooth.discover_devices(duration=8, lookup_names=False))
            except Exception:
                pass
            for a in addrs:
                if not isinstance(a, str) or not MAC.fullmatch(a):
                    continue
                p = {"bt": True, "ip": a, "port": int(self.cfg["channel"])}
                try:
                    r = self.p2p.rpc(p, {"op": "hello"})
                    h = r[0] if r else None
                    if h and self.p2p.valid_hello(h) and h["id"] != self.p2p.id:
                        self.p2p.add_peer(h["id"], a, p["port"], h["nick"], h["sup"], "bt", 180, True)
                except Exception as e:
                    dlog.exc(f"bluetooth peer {a}", e)
            time.sleep(60)
