"""Сеть через интернет: реестр супернод и «растущие корни».

Один сервер-реестр (server/dnet_registry.py) знает только супернод. Узел с белым адресом и режимом супер-узла раз в 5 минут
объявляет себя реестру. Любой клиент, пока интернет есть, спрашивает реестр, подключается к самой крупной суперноде,
а та отдаёт ему ближайших супернод и обычных узлов (op "near"). Дальше реестр не нужен: сеть растёт от суперноды к суперноде,
а страницы и ретрансляция идут по обычному протоколу DNet.

config.json -> "registry": {"urls": ["http://реестр:48560"], "announce": "auto", "target": 3}
  announce: "auto" — объявляться, если мы супер-узел и до нас можно достучаться; true/false — принудительно.
"""
import json
import os
import random
import threading
import time
import urllib.request

import dlog
from nat import is_public

MAX_BYTES = 64 * 1024


class Overlay:
    def __init__(self, cfg, p2p, monitor, super_node):
        self.cfg, self.p2p, self.monitor, self.super = cfg, p2p, monitor, super_node
        self.last_announce = 0.0
        self.last_join = 0.0
        self.state = {"url": "", "listed": 0, "joined": [], "announced": None, "error": ""}

    def conf(self):
        return self.cfg.get("registry") or {}

    def urls(self):
        return [u for u in self.conf().get("urls", []) if isinstance(u, str) and u.startswith(("http://", "https://"))][:3]

    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="overlay").start()

    def _loop(self):
        time.sleep(20)
        while True:
            try:
                if self.urls() and self.monitor.state["levels"].get("world"):
                    if self.announcing() and time.time() - self.last_announce > 300:
                        self.announce()
                    if time.time() - self.last_join > 60:
                        self.join()
            except Exception as e:
                dlog.exc("overlay", e)
            time.sleep(15)

    def ok_addr(self, ip):
        return is_public(ip) or bool(os.environ.get("DNET_REGISTRY_PRIVATE"))

    def announcing(self):
        mode = self.conf().get("announce", "auto")
        if mode == "auto":
            return self.super.on() and self.p2p.nat.reachable is True
        return bool(mode)

    def _http(self, url, data=None):
        req = urllib.request.Request(url, data=json.dumps(data).encode() if data is not None else None,
                                     headers={"User-Agent": "DNet", "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read(MAX_BYTES))

    def announce(self):
        self.last_announce = time.time()
        n, _ = self.p2p.store.stats()
        body = {"id": self.p2p.id, "port": self.p2p_port(), "nick": self.cfg.get("nick", ""), "peers": len(self.p2p.alive()),
                "pages": n, "relay_clients": len(self.p2p.relay_srv.clients), "relay": self.p2p.relay_srv.serving(), "v": 1}
        for url in self.urls():
            try:
                r = self._http(url.rstrip("/") + "/announce", body)
                self.state["announced"] = (url, bool(r.get("ok")), r.get("why"))
                if r.get("ok"):
                    dlog.log(f"overlay: объявились в реестре {url}")
                    return
            except Exception as e:
                self.state["announced"] = (url, False, str(e)[:80])

    @staticmethod
    def p2p_port():
        from p2p import TCP_PORT
        return TCP_PORT

    def internet_peers(self):
        return [p for p in self.p2p.alive() if not p.get("relay") and not p["bt"] and p["kind"] != "router" and is_public(p["ip"])]

    def join(self):
        """Если интернет-соседей мало: берём список у реестра, цепляемся к самым крупным и спрашиваем у них ближних."""
        self.last_join = time.time()
        target = int(self.conf().get("target", 5 if self.super.on() else 3))
        have = {p["id"] for p in self.internet_peers()}
        if len(have) >= target:
            return
        lst = None
        for url in self.urls():
            try:
                lst = self._http(url.rstrip("/") + "/supers?n=10").get("supers")
                self.state.update(url=url, error="")
                break
            except Exception as e:
                self.state["error"] = f"{url}: {str(e)[:80]}"
        if not isinstance(lst, list):
            return
        mine = set(self.p2p.cfg.get("static_peers", []))
        cands = []
        for e in lst[:10]:
            try:
                ip, port = str(e["ip"]), int(e["port"])
                if self.ok_addr(ip) and e.get("id") != self.p2p.id and e.get("id") not in have:
                    cands.append((ip, port, e.get("id"), float(e.get("score", 0))))
            except (KeyError, TypeError, ValueError):
                pass
        self.state["listed"] = len(cands)
        if len(cands) > 1 and random.random() < 0.25:  # изредка берём вторую по размеру, чтобы не грузить только самую большую
            cands[0], cands[1] = cands[1], cands[0]
        joined = []
        for ip, port, pid, _ in cands:
            if len(joined) >= 2 or len(have) + len(joined) >= target:
                break
            if self.p2p.hello(ip, 600, port) is True:
                joined.append(pid)
                self.learn_near(ip, port)
        self.state["joined"] = joined
        if joined:
            dlog.log(f"overlay: подключились к суперодам {joined}")

    def learn_near(self, ip, port):
        """Спрашиваем у суперноды её ближних: другие суперноды и обычные узлы."""
        peer = next((p for p in self.p2p.alive() if p["ip"] == ip and p["port"] == port), None)
        if not peer:
            return
        r = self.p2p.rpc(peer, {"op": "near"})
        if not r:
            return
        n = 0
        for kind in ("supers", "nodes"):
            for it in (r[0].get(kind) or [])[:10]:
                try:
                    nip, nport = str(it[0]), int(it[1])
                    if self.ok_addr(nip) and (nip, nport) != (self.p2p.cfg.get("_self"), 0) and self.p2p.hello(nip, 600, nport) is True:
                        n += 1
                except (IndexError, TypeError, ValueError):
                    pass
        dlog.log(f"overlay: от {ip}:{port} получили {n} новых соседей")

    def status(self):
        return {"urls": self.urls(), "announcing": bool(self.urls()) and self.announcing(), **self.state,
                "internet_peers": len(self.internet_peers())}
