import hashlib
import os
import re
import sqlite3
import threading
import time
import zlib
from urllib.parse import urldefrag


def norm(url):
    return urldefrag(url.strip())[0]


def key_of(url):
    return hashlib.sha256(norm(url).encode()).hexdigest()


class Store:
    def __init__(self, folder, ttl_days, max_mb):
        self.db = sqlite3.connect(os.path.join(folder, "pages.db"), check_same_thread=False)
        self.lock = threading.Lock()
        self.ttl = ttl_days * 86400
        self.max = max_mb * 1048576
        with self.lock:
            self.db.execute("CREATE TABLE IF NOT EXISTS pages(key TEXT PRIMARY KEY, url TEXT, ctype TEXT, body BLOB, saved REAL)")
            self.db.execute("CREATE INDEX IF NOT EXISTS ix_saved ON pages(saved)")
            cols = {r[1] for r in self.db.execute("PRAGMA table_info(pages)")}
            if "hits" not in cols:  # сколько раз страницу открывали (у нас и у соседей)
                self.db.execute("ALTER TABLE pages ADD COLUMN hits INTEGER NOT NULL DEFAULT 0")
            if "rep" not in cols:  # 1 — копия «про запас», взятая у соседей, а не нашей собственной загрузки
                self.db.execute("ALTER TABLE pages ADD COLUMN rep INTEGER NOT NULL DEFAULT 0")
            self.db.execute("CREATE TABLE IF NOT EXISTS wants(key TEXT PRIMARY KEY, url TEXT, ts REAL, tries INTEGER)")
            self.db.commit()
        self.cleanup()

    def put(self, url, ctype, body, saved=None, rep=False):
        """Сохраняет страницу. Счётчик открытий не сбрасывается; собственная копия не становится «запасной»."""
        url = norm(url)
        now = time.time()
        saved = min(saved or now, now)
        k = key_of(url)
        with self.lock:
            self.db.execute(
                "INSERT OR REPLACE INTO pages(key,url,ctype,body,saved,hits,rep) VALUES(?,?,?,?,?,"
                "COALESCE((SELECT hits FROM pages WHERE key=?),0), MIN(?, COALESCE((SELECT rep FROM pages WHERE key=?),1)))",
                (k, url, ctype, zlib.compress(body), saved, k, 1 if rep else 0, k))
            self.db.execute("DELETE FROM wants WHERE key=?", (k,))
            self.db.commit()

    def touch(self, key, n=1):
        """Страницу открыли (мы сами или сосед): растёт «популярность»."""
        with self.lock:
            self.db.execute("UPDATE pages SET hits=hits+? WHERE key=?", (n, key))
            self.db.commit()

    def hot(self, n, min_hits=1):
        """Самые часто открываемые страницы: [key, url, saved, hits]."""
        with self.lock:
            rows = self.db.execute("SELECT key, url, saved, hits FROM pages WHERE hits>=? AND saved>=? "
                                   "ORDER BY hits DESC, saved DESC LIMIT ?", (min_hits, time.time() - self.ttl, n)).fetchall()
        return [list(r) for r in rows]

    def rep_stats(self):
        """(число, байт) запасных копий."""
        with self.lock:
            return self.db.execute("SELECT COUNT(*), COALESCE(SUM(LENGTH(body)),0) FROM pages WHERE rep=1").fetchone()

    def get(self, key):
        with self.lock:
            r = self.db.execute("SELECT url, ctype, body, saved FROM pages WHERE key=?", (key,)).fetchone()
        if not r or r[3] < time.time() - self.ttl:
            return None
        return {"url": r[0], "ctype": r[1], "body": zlib.decompress(r[2]), "saved": r[3]}

    def saved(self, url):
        with self.lock:
            r = self.db.execute("SELECT saved FROM pages WHERE key=?", (key_of(url),)).fetchone()
        return r[0] if r else None

    def saved_key(self, key):
        with self.lock:
            r = self.db.execute("SELECT saved FROM pages WHERE key=?", (key,)).fetchone()
        return r[0] if r else None

    def items(self, n):
        with self.lock:
            rows = self.db.execute("SELECT key, url, saved, LENGTH(body) FROM pages WHERE saved>=? ORDER BY saved DESC LIMIT ?",
                                   (time.time() - self.ttl, n)).fetchall()
        return [list(r) for r in rows]

    def add_want(self, url):
        url = norm(url)
        if not re.fullmatch(r"https?://[^\s\x00-\x1f\x7f]{1,2000}", url):
            return
        with self.lock:
            if self.db.execute("SELECT COUNT(*) FROM wants").fetchone()[0] < 5000:
                self.db.execute("INSERT OR IGNORE INTO wants VALUES(?,?,?,0)", (key_of(url), url, time.time()))
                self.db.commit()

    def wants(self, n=50):
        with self.lock:
            return self.db.execute("SELECT key, url, tries FROM wants ORDER BY ts LIMIT ?", (n,)).fetchall()

    def count_wants(self):
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM wants").fetchone()[0]

    def bump_want(self, key):
        with self.lock:
            self.db.execute("UPDATE wants SET tries=tries+1 WHERE key=?", (key,))
            self.db.execute("DELETE FROM wants WHERE tries>=3")
            self.db.commit()

    def purge(self, pred):
        """Удаляет страницы, адрес которых подходит под pred. Возвращает их число."""
        with self.lock:
            bad = [(k,) for k, u in self.db.execute("SELECT key, url FROM pages").fetchall() if pred(u)]
            self.db.executemany("DELETE FROM pages WHERE key=?", bad)
            self.db.commit()
        return len(bad)

    def clear(self):
        with self.lock:
            self.db.execute("DELETE FROM pages")
            self.db.execute("DELETE FROM wants")
            self.db.commit()

    def stats(self):
        with self.lock:
            return self.db.execute("SELECT COUNT(*), COALESCE(SUM(LENGTH(body)),0) FROM pages").fetchone()

    def cleanup(self):
        with self.lock:
            self.db.execute("DELETE FROM pages WHERE saved < ?", (time.time() - self.ttl,))
            while self.db.execute("SELECT COALESCE(SUM(LENGTH(body)),0) FROM pages").fetchone()[0] > self.max:
                self.db.execute("DELETE FROM pages WHERE key IN (SELECT key FROM pages ORDER BY rep DESC, hits, saved LIMIT 20)")
            self.db.commit()
