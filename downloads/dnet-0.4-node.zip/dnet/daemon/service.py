"""Автозапуск узла DNet. Без прав администратора по умолчанию (режим «user»).

  Windows : ключ Run в HKCU (запуск при входе в систему, без UAC). Режим system — задача планировщика
            от имени SYSTEM при загрузке компьютера (нужен администратор).
  Linux   : systemd --user (без root; чтобы работало без входа в систему: loginctl enable-linger).
            Режим system — /etc/systemd/system/dnet.service (нужен root).
            Нет systemd — файл автозапуска XDG (~/.config/autostart).
  macOS   : LaunchAgent в ~/Library/LaunchAgents.

CLI:  python daemon/main.py --autostart on|off|status [--system]
"""
import os
import subprocess
import sys

NAME = "DNet"
FROZEN = bool(getattr(sys, "frozen", False))
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))


def command(headless=False):
    """Командная строка запуска узла (список аргументов)."""
    flag = ["--no-ui"] if headless else ["--tray"]
    if FROZEN:
        return [sys.executable] + flag
    py = sys.executable
    if os.name == "nt" and not headless and py.lower().endswith("python.exe"):
        pyw = py[:-10] + "pythonw.exe"  # без чёрного окна консоли
        py = pyw if os.path.exists(pyw) else py
    script = os.path.join(HERE, "main.py")
    if not os.path.isfile(script):  # запуск из .pyz
        script = os.path.abspath(sys.argv[0])
    return [py, script] + flag


def _q(args):
    return subprocess.list2cmdline(args)


def _run(cmd, **kw):
    kw.setdefault("capture_output", True)
    if os.name == "nt":
        kw.setdefault("creationflags", 0x08000000)
    return subprocess.run(cmd, **kw)


# ---------- Windows ----------
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def _win_status():
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, NAME)
        return "user"
    except OSError:
        pass
    if _run(["schtasks", "/Query", "/TN", NAME]).returncode == 0:
        return "system"
    return None


def _win_on(system):
    import winreg
    if system:
        r = _run(["schtasks", "/Create", "/F", "/TN", NAME, "/SC", "ONSTART", "/RU", "SYSTEM", "/RL", "HIGHEST",
                  "/TR", _q(command(headless=True))])
        if r.returncode:
            raise RuntimeError("нужен запуск от администратора: " + r.stderr.decode("cp866", "ignore").strip())
        return
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
        winreg.SetValueEx(k, NAME, 0, winreg.REG_SZ, _q(command()))


def _win_off():
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            winreg.DeleteValue(k, NAME)
    except OSError:
        pass
    _run(["schtasks", "/Delete", "/F", "/TN", NAME])


# ---------- Linux ----------
UNIT = """[Unit]
Description=DNet node
After=network-online.target
Wants=network-online.target

[Service]
ExecStart={cmd}
Restart=on-failure
RestartSec=5
{extra}
[Install]
WantedBy={target}
"""


def _unit_path(system):
    if system:
        return "/etc/systemd/system/dnet.service"
    return os.path.join(os.path.expanduser("~"), ".config", "systemd", "user", "dnet.service")


def _xdg_path():
    return os.path.join(os.path.expanduser("~"), ".config", "autostart", "dnet.desktop")


def _has_systemd(system):
    if not os.path.isdir("/run/systemd/system"):
        return False
    return system or _run(["systemctl", "--user", "show-environment"]).returncode == 0


def _linux_status():
    if os.path.exists(_unit_path(False)):
        return "user"
    if os.path.exists(_unit_path(True)):
        return "system"
    return "user" if os.path.exists(_xdg_path()) else None


def _linux_on(system):
    if system and os.geteuid() != 0:
        raise RuntimeError("режим system требует root: sudo python3 daemon/main.py --autostart on --system")
    if _has_systemd(system):
        path = _unit_path(system)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        extra = "" if not system else "User=" + os.environ.get("SUDO_USER", "root") + "\n"
        with open(path, "w", encoding="utf-8") as f:
            f.write(UNIT.format(cmd=_q(command(headless=True)), extra=extra,
                                target="multi-user.target" if system else "default.target"))
        ctl = ["systemctl"] + ([] if system else ["--user"])
        _run(ctl + ["daemon-reload"])
        _run(ctl + ["enable", "--now", "dnet.service"])
        return
    path = _xdg_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"[Desktop Entry]\nType=Application\nName=DNet\nExec={_q(command())}\nX-GNOME-Autostart-enabled=true\n")


def _linux_off():
    for system in (False, True):
        path = _unit_path(system)
        if os.path.exists(path):
            ctl = ["systemctl"] + ([] if system else ["--user"])
            _run(ctl + ["disable", "--now", "dnet.service"])
            os.remove(path)
            _run(ctl + ["daemon-reload"])
    if os.path.exists(_xdg_path()):
        os.remove(_xdg_path())


# ---------- macOS ----------
def _plist():
    return os.path.join(os.path.expanduser("~"), "Library", "LaunchAgents", "local.dnet.node.plist")


def _mac_on(system):
    args = "".join(f"<string>{a}</string>" for a in command())
    os.makedirs(os.path.dirname(_plist()), exist_ok=True)
    with open(_plist(), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict>'
                '<key>Label</key><string>local.dnet.node</string>'
                f'<key>ProgramArguments</key><array>{args}</array>'
                '<key>RunAtLoad</key><true/><key>KeepAlive</key><true/></dict></plist>')
    _run(["launchctl", "load", "-w", _plist()])


def _mac_off():
    if os.path.exists(_plist()):
        _run(["launchctl", "unload", "-w", _plist()])
        os.remove(_plist())


# ---------- общий интерфейс ----------
def status():
    """None — автозапуск выключен, иначе 'user' или 'system'."""
    try:
        if os.name == "nt":
            return _win_status()
        if sys.platform == "darwin":
            return "user" if os.path.exists(_plist()) else None
        return _linux_status()
    except Exception:
        return None


def enable(system=False):
    if os.name == "nt":
        _win_off()
        _win_on(system)
    elif sys.platform == "darwin":
        _mac_on(system)
    else:
        _linux_off()
        _linux_on(system)


def disable():
    if os.name == "nt":
        _win_off()
    elif sys.platform == "darwin":
        _mac_off()
    else:
        _linux_off()


def cli(args):
    """--autostart on|off|status [--system]. Возвращает код выхода."""
    i = args.index("--autostart")
    act = args[i + 1] if i + 1 < len(args) else "status"
    try:
        if act == "on":
            enable("--system" in args)
            print("Автозапуск включён:", status() or "?")
        elif act == "off":
            disable()
            print("Автозапуск выключен")
        else:
            st = status()
            print("Автозапуск:", {"user": "включён (для текущего пользователя)", "system": "включён (служба, для всех)",
                                  None: "выключен"}[st])
    except Exception as e:
        print("Ошибка:", e)
        return 1
    return 0
