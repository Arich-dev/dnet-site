import ipaddress
import socket
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse

import dlog
import policy
from p2p import CT

HTTP_MAX = 5 * 1024 * 1024


def public(url):
    try:
        u = urlparse(url)
        if u.scheme not in ("http", "https") or not u.hostname:
            return False
        infos = socket.getaddrinfo(u.hostname, u.port or 80, type=socket.SOCK_STREAM)
        return all(ipaddress.ip_address(i[4][0]).is_global for i in infos)
    except Exception:
        return False


class Guard(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not public(newurl):
            raise urllib.error.URLError("blocked")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


OPENER = urllib.request.build_opener(Guard)


def download(url):
    if not public(url):
        return None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 DNet"})
        with OPENER.open(req, timeout=15) as r:
            ct = r.headers.get("Content-Type", "")
            if not CT.fullmatch(ct):
                return None
            body = r.read(HTTP_MAX + 1)
        return (ct, body) if len(body) <= HTTP_MAX else None
    except Exception:
        return None


class Super:
    def __init__(self, cfg, store, p2p, monitor, save):
        self.cfg = cfg
        self.store = store
        self.p2p = p2p
        self.monitor = monitor
        self.save = save
        self.apply()

    def on(self):
        return bool(self.cfg["super"]["enabled"])

    def apply(self):
        self.store.max = int(self.cfg["super"]["max_mb"] if self.on() else self.cfg["max_mb"]) * 1048576

    def set_enabled(self, v):
        self.cfg["super"]["enabled"] = bool(v)
        self.save()
        self.apply()

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try:
                self.apply()
                if self.on():
                    self._replicate()
                    self._download()
            except Exception as e:
                dlog.exc("super", e)
            time.sleep(30)

    def _replicate(self):
        n = 0
        for key, it in list(self.p2p.index.items()):
            if n >= self.cfg["super"]["batch"] or self.store.stats()[1] >= self.store.max * 0.95:
                break
            if policy.blocked(it["url"]):
                continue
            s = self.store.saved_key(key)
            if s is not None and s >= it["saved"]:
                continue
            if self.p2p.fetch_key(key, it["from"]):
                n += 1
                dlog.log(f"super: replicated {it['url']}")

    def _download(self):
        if not self.monitor.state["levels"].get("world"):
            return
        for key, url, _ in self.store.wants(5):
            r = download(url)
            if r:
                self.store.put(url, r[0], r[1])
                dlog.log(f"super: downloaded {url}")
            else:
                self.store.bump_want(key)
                dlog.log(f"super: could not download {url}")
