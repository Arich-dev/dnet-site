"""Рисует значок DNet без внешних библиотек: PNG (для расширений, окна) и ICO (для трея Windows).

Значок — скруглённый квадрат цвета состояния с тремя узлами сети, соединёнными линиями.
"""
import struct
import zlib

COLORS = {"ok": (23, 160, 93), "warn": (230, 160, 30), "bad": (217, 70, 70), "off": (120, 130, 145),
          "brand": (20, 130, 140)}


def _raster(size, rgb, ss=4):
    """Возвращает список строк RGBA (по 4 байта на пиксель), сглаживание суперсэмплингом."""
    big = size * ss
    r2 = (big * 0.22) ** 2
    nodes = [(0.30, 0.68), (0.70, 0.68), (0.50, 0.30)]
    nodes = [(x * big, y * big) for x, y in nodes]
    nr = big * 0.105
    lw = big * 0.04

    def seg(px, py, a, b):
        ax, ay = a
        bx, by = b
        dx, dy = bx - ax, by - ay
        t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
        return (px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2

    def inside(px, py):
        c = big * 0.22
        cx = min(max(px, c), big - c)
        cy = min(max(py, c), big - c)
        return (px - cx) ** 2 + (py - cy) ** 2 <= r2

    def white(px, py):
        for n in nodes:
            if (px - n[0]) ** 2 + (py - n[1]) ** 2 <= nr * nr:
                return True
        for i in range(3):
            if seg(px, py, nodes[i], nodes[(i + 1) % 3]) <= lw * lw:
                return True
        return False

    rows = []
    for y in range(size):
        row = bytearray()
        for x in range(size):
            a = w = 0
            for sy in range(ss):
                for sx in range(ss):
                    px, py = x * ss + sx + 0.5, y * ss + sy + 0.5
                    if inside(px, py):
                        a += 1
                        if white(px, py):
                            w += 1
            n = ss * ss
            if a == 0:
                row += b"\0\0\0\0"
                continue
            k = w / a
            col = [round(rgb[i] * (1 - k) + 255 * k) for i in range(3)]
            row += bytes(col) + bytes([round(255 * a / n)])
        rows.append(bytes(row))
    return rows


def png(size=32, state="brand"):
    rows = _raster(size, COLORS[state])
    raw = b"".join(b"\0" + r for r in rows)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def ico(sizes=(16, 32), state="brand"):
    """ICO с несколькими 32-битными изображениями (BMP внутри)."""
    if isinstance(sizes, int):
        sizes = (sizes,)
    images = []
    for size in sizes:
        rows = _raster(size, COLORS[state])
        pix = bytearray()
        for r in reversed(rows):  # BMP хранит строки снизу вверх, порядок BGRA
            for x in range(size):
                R, G, B, A = r[x * 4:x * 4 + 4]
                pix += bytes((B, G, R, A))
        mask = b"\0" * (((size + 31) // 32 * 4) * size)
        hdr = struct.pack("<IiiHHIIiiII", 40, size, size * 2, 1, 32, 0, len(pix) + len(mask), 0, 0, 0, 0)
        images.append((size, hdr + bytes(pix) + mask))
    out = struct.pack("<HHH", 0, 1, len(images))
    offset = 6 + 16 * len(images)
    for size, img in images:
        out += struct.pack("<BBBBHHII", size % 256, size % 256, 0, 0, 1, 32, len(img), offset)
        offset += len(img)
    return out + b"".join(img for _, img in images)
