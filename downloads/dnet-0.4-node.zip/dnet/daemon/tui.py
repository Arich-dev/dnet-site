"""Псевдо-GUI в консоли: вкладки, цвета, ASCII. Только стандартная библиотека (ANSI + чтение клавиш)."""
import os
import re
import shutil
import sys
import time
from urllib.parse import unquote

import dlog
import netcheck

COLOR = not (os.environ.get("NO_COLOR") or os.environ.get("DNET_NO_COLOR"))

# палитра (256 цветов)
TEAL, AMBER, RED, GREEN = "38;5;43", "38;5;214", "38;5;203", "38;5;78"
BLUE, GREY, DIM, WHITE = "38;5;75", "38;5;246", "38;5;240", "1;38;5;255"
TAB_ON = "1;48;5;30;38;5;255"
SEL = "48;5;237;38;5;255"
BAR_ON = "48;5;30;38;5;255"

LOGO = [r" ___  _  _     _   ",
        r"|   \| \| |___| |_ ",
        r"| |) | .` / -_)  _|",
        r"|___/|_|\_\___|\__|"]
TABS = ["Сеть", "Соседи", "Файлы", "Настройки", "Журнал"]
SCANNER = {"active": ("ищет часто — интернета нет", AMBER), "limited": ("раз в 30 минут — интернет есть", GREEN),
           "off": ("выключен", GREY), "wait": ("ждёт первой проверки сети", GREY)}

ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def c(code, text):
    return f"\x1b[{code}m{text}\x1b[0m" if COLOR else str(text)


def vlen(s):
    return len(ANSI.sub("", s))


def clip(s, w):
    """Обрезает строку до w видимых символов, не ломая цветовые последовательности."""
    out, n, i = [], 0, 0
    while i < len(s):
        m = ANSI.match(s, i)
        if m:
            out.append(m.group())
            i = m.end()
        elif n < w:
            out.append(s[i])
            n += 1
            i += 1
        else:
            break
    return "".join(out) + ("\x1b[0m" if COLOR else "")


def pad(s, w, right=False):
    gap = max(0, w - vlen(s))
    return (" " * gap + s) if right else (s + " " * gap)


def bar(frac, width, color=TEAL):
    frac = 0 if frac < 0 else 1 if frac > 1 else frac
    n = round(frac * width)
    return c(color, "█" * n) + c(DIM, "░" * (width - n))


def size(n):
    if n < 1024:
        return f"{n} Б"
    if n < 1 << 20:
        return f"{n / 1024:.0f} КБ"
    return f"{n / (1 << 20):.1f} МБ"


def ago(t):
    s = max(0, time.time() - t)
    if s < 60:
        return f"{int(s)} с"
    if s < 3600:
        return f"{int(s // 60)} мин"
    if s < 86400:
        return f"{int(s // 3600)} ч"
    return f"{int(s // 86400)} дн"


def dot(v):
    return c(GREEN, "●") if v is True else c(RED, "●") if v is False else c(DIM, "○")


# ---------- чтение клавиш ----------
if os.name == "nt":
    import msvcrt

    class Raw:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def read_key(timeout):
        end = time.time() + timeout
        while time.time() < end:
            if msvcrt.kbhit():
                ch = msvcrt.getwch()
                if ch in ("\x00", "\xe0"):
                    return {"H": "up", "P": "down", "K": "left", "M": "right", "I": "pgup", "Q": "pgdn",
                            "G": "home", "O": "end"}.get(msvcrt.getwch(), "")
                return {"\r": "enter", "\t": "tab", "\x1b": "esc", "\x03": "q"}.get(ch, ch)
            time.sleep(0.02)
        return None
else:
    import select
    import termios
    import tty

    class Raw:
        def __enter__(self):
            self.fd = sys.stdin.fileno()
            self.old = termios.tcgetattr(self.fd)
            tty.setcbreak(self.fd)
            return self

        def __exit__(self, *a):
            termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)
            return False

    SEQ = {"[A": "up", "[B": "down", "[C": "right", "[D": "left", "[5~": "pgup", "[6~": "pgdn",
           "[H": "home", "[F": "end", "[1~": "home", "[4~": "end"}

    def read_key(timeout):
        fd = sys.stdin.fileno()
        if not select.select([fd], [], [], timeout)[0]:
            return None
        ch = os.read(fd, 1).decode("utf-8", "ignore")
        if ch == "\x1b":
            if not select.select([fd], [], [], 0.03)[0]:
                return "esc"
            seq = os.read(fd, 8).decode("ascii", "ignore")
            return SEQ.get(seq, "")
        return {"\n": "enter", "\r": "enter", "\t": "tab", "\x03": "q"}.get(ch, ch)


# ---------- интерфейс ----------
class UI:
    def __init__(self, app, quit_ev):
        self.app = app
        self.quit = quit_ev
        self.tab = 0
        self.sel = [0] * len(TABS)
        self.back = 0  # прокрутка журнала назад
        self.confirm = None
        self.note = ("", 0.0)
        self.start = time.time()

    # --- данные ---
    def rows(self, tab):
        if tab == 1:
            return self.app.p2p.alive()
        if tab == 2:
            from api import pages_list
            return sorted(pages_list(self.app), key=lambda p: -p["saved"])
        if tab == 3:
            return self.settings()
        return []

    def settings(self):
        a, cfg = self.app, self.app.cfg
        yes = lambda v: "ВКЛ" if v else "выкл"
        return [("Сканер подсетей", yes(cfg["probe"]["enabled"]), "toggle", "probe"),
                ("Супер-узел", yes(a.super.on()), "toggle", "super"),
                ("Bluetooth", yes(cfg["bluetooth"]["enabled"]), "info", "нужен перезапуск"),
                ("Ник", cfg["nick"], "info", ""),
                ("Привязка API", f"{cfg.get('api_bind', '127.0.0.1')}:{os.environ.get('DNET_API_PORT', 8765)}", "info", "api_bind"),
                ("Срок хранения", f"{cfg['ttl_days']} дн.", "info", "ttl_days"),
                ("Кэш (обычный / супер)", f"{cfg['max_mb']} МБ / {cfg['super']['max_mb']} МБ", "info", "max_mb"),
                ("Соседи вручную", ", ".join(cfg["static_peers"]) or "—", "info", "static_peers"),
                ("Папка данных", os.environ.get("DNET_HOME") or os.path.join(os.path.expanduser("~"), ".dnet"), "info", "")]

    # --- ввод ---
    def handle(self, k):
        if self.confirm:
            if k in ("y", "н", "enter"):
                self.confirm()
            self.confirm = None
            return
        n = len(TABS)
        if k in ("q", "й"):
            self.quit.set()
        elif k in ("right", "tab"):
            self.tab = (self.tab + 1) % n
        elif k == "left":
            self.tab = (self.tab - 1) % n
        elif k in [str(i + 1) for i in range(n)]:
            self.tab = int(k) - 1
        elif k in ("up", "down", "pgup", "pgdn", "home", "end"):
            self.move(k)
        elif k in ("enter", " ") and self.tab == 3:
            self.toggle()
        elif k in ("x", "ч") and self.tab == 2:
            self.confirm = lambda: (self.app.store.clear(), self.say("Кэш очищен"))
            self.say("Очистить весь кэш? y — да, любая клавиша — нет", 6)

    def move(self, k):
        if self.tab == 4:
            step = {"up": 1, "down": -1, "pgup": 10, "pgdn": -10, "home": 10 ** 6, "end": -10 ** 6}[k]
            self.back = max(0, self.back + step)
            return
        total = len(self.rows(self.tab))
        step = {"up": -1, "down": 1, "pgup": -10, "pgdn": 10, "home": -10 ** 6, "end": 10 ** 6}[k]
        self.sel[self.tab] = max(0, min(max(0, total - 1), self.sel[self.tab] + step))

    def toggle(self):
        rows = self.settings()
        name, _, kind, key = rows[min(self.sel[3], len(rows) - 1)]
        if kind != "toggle":
            self.say("Это значение правится в config.json", 3)
            return
        a = self.app
        if key == "probe":
            a.cfg["probe"]["enabled"] = not a.cfg["probe"]["enabled"]
            a.save()
        elif key == "super":
            a.super.set_enabled(not a.super.on())
        self.say(f"{name}: {'включено' if (a.cfg['probe']['enabled'] if key == 'probe' else a.super.on()) else 'выключено'}")

    def say(self, text, secs=3.0):
        self.note = (text, time.time() + secs)

    # --- отрисовка ---
    def frame(self, w, h):
        if w < 64 or h < 18:
            return [c(AMBER, "Окно слишком маленькое: нужно хотя бы 64×18"), c(GREY, "q — выход")]
        big = h >= 30
        lines = self.header(w, big)
        lines.append(self.tabbar(w))
        lines.append(c(DIM, "─" * w))
        body_h = h - len(lines) - 2
        body = self.body(w, body_h)
        body = (body + [""] * body_h)[:body_h]
        lines += body
        lines.append(c(DIM, "─" * w))
        lines.append(self.footer(w))
        return [clip(l, w) for l in lines]

    def header(self, w, big):
        a = self.app
        st = a.monitor.state
        names = dict(netcheck.LEVELS)
        reach = names.get(st["reach"]) if st.get("reach") else None
        peers = a.p2p.alive()
        n, used = a.store.stats()
        up = int(time.time() - self.start)
        info = [c(WHITE, a.cfg["nick"]) + c(DIM, f"  id {a.id[:8]}…  работает {up // 3600}:{up % 3600 // 60:02d}:{up % 60:02d}"),
                (c(GREEN, "● ") + "связь есть, доходит до: " + c(WHITE, reach)) if reach else c(RED, "● нет связи"),
                f"соседей {c(WHITE, len(peers))}   страниц {c(WHITE, n)}   кэш {c(WHITE, size(used))}",
                (c(AMBER, "★ супер-узел   ") if a.super.on() else "") + c(GREY, f"сканер: {SCANNER.get(a.probe.mode, ('', GREY))[0]}")]
        if not big:
            return [c(TEAL, "DNet ") + info[0] + "  " + info[1]]
        return [" " + c(TEAL, LOGO[i]) + "   " + info[i] for i in range(4)]

    def tabbar(self, w):
        parts = []
        for i, t in enumerate(TABS):
            label = f" {i + 1} {t} "
            parts.append(c(TAB_ON, label) if i == self.tab else c(GREY, label))
        return " " + c(DIM, "│").join(parts)

    def footer(self, w):
        note, until = self.note
        if note and time.time() < until:
            return " " + c(AMBER, note)
        hints = {0: "←/→ вкладки   1-5 перейти   q выход",
                 1: "↑/↓ выбор   ←/→ вкладки   q выход",
                 2: "↑/↓ PgUp/PgDn прокрутка   x очистить кэш   q выход",
                 3: "↑/↓ выбор   Enter переключить   q выход",
                 4: "↑/↓ PgUp/PgDn назад по журналу   End к новым   q выход"}[self.tab]
        return " " + c(GREY, hints)

    def body(self, w, h):
        return [self.tab_net, self.tab_peers, self.tab_files, self.tab_settings, self.tab_log][self.tab](w, h)

    # --- вкладки ---
    def tab_net(self, w, h):
        a = self.app
        st = a.monitor.state
        levels, hosts = st.get("levels", {}), st.get("hosts", {})
        seg = max(8, min(15, (w - 24) // 5))
        xs = [6 + i * (seg + 1) for i in range(5)]
        chain = " " * xs[0]
        for i, (key, _) in enumerate(netcheck.LEVELS):
            chain += dot(levels.get(key))
            if i < 4:
                cur, nxt = levels.get(key), levels.get(netcheck.LEVELS[i + 1][0])
                col = GREEN if cur and nxt else RED if cur is False or nxt is False else DIM
                chain += c(col, "━" * seg)

        def place(items):
            row = [" "] * (xs[-1] + 16)
            for x, t in items:
                start = max(0, x - len(t) // 2)
                for j, ch in enumerate(t):
                    row[start + j] = ch
            return "".join(row).rstrip()

        labels = place([(xs[i], n) for i, (_, n) in enumerate(netcheck.LEVELS)])
        def short(t):
            return t if len(t) <= seg else "…" + t[-(seg - 1):]

        host_row = place([(xs[i], short(hosts.get(k) or "—")) for i, (k, _) in enumerate(netcheck.LEVELS)])
        reach, broken = st.get("reach"), st.get("broken")
        names = dict(netcheck.LEVELS)
        if reach is None:
            verdict = c(RED, "✖ ") + "нет связи даже с домашним шлюзом"
        elif broken:
            verdict = c(AMBER, "▲ ") + f"связь доходит до «{names[reach]}», дальше обрыв: «{names[broken]}»"
        else:
            verdict = c(GREEN, "✔ ") + f"всё в порядке, связь доходит до «{names[reach]}»"
        lines = ["", chain, c(WHITE, labels), c(DIM, host_row), "", " " + verdict, "", " " + c(TEAL, "СКАНЕР ПОДСЕТЕЙ")]
        mode_txt, col = SCANNER.get(a.probe.mode, ("", GREY))
        lines.append("   режим: " + c(col, mode_txt))
        nets = sorted(a.probe.nets.values(), key=lambda n: n["cidr"])
        if not nets:
            lines.append(c(GREY, "   подсети ещё не сканировались"))
        for n in nets[: max(1, h - len(lines) - 4)]:
            frac = n["dnet"] / max(1, n["alive"])
            lines.append(f"   {pad(n['cidr'], 18)} {pad(n['label'], 9)} живых {pad(str(n['alive']), 3, True)}"
                         f"  DNet {c(GREEN if n['dnet'] else GREY, pad(str(n['dnet']), 2, True))}  {bar(frac, 12)}")
        lines += ["", " " + c(TEAL, "УЗЕЛ"),
                  f"   Bluetooth: {c(GREY, a.bt.status)}   API: {c(GREY, a.cfg.get('api_bind', '127.0.0.1') + ':' + str(os.environ.get('DNET_API_PORT', 8765)))}"]
        return lines

    def tab_peers(self, w, h):
        peers = self.rows(1)
        cols = [("Ник", 18), ("Адрес", 18), ("Прыжки", 7), ("Тип", 11), ("Канал", 6), ("Виден", 7)]
        head = " " + c(TEAL, "".join(pad(t, wd) for t, wd in cols))
        if not peers:
            return ["", c(GREY, "   Соседей пока нет. Они найдутся сами: маяк шлётся каждые 15 секунд."),
                    c(GREY, "   Если не находятся — проверь файрвол (UDP 48555, TCP 48556) и static_peers.")]
        sel = min(self.sel[1], len(peers) - 1)
        room = h - 3
        top = max(0, min(sel - room + 1, len(peers) - room)) if sel >= room else 0
        lines = [head, c(DIM, " " + "─" * (w - 2))]
        for i, p in enumerate(peers[top: top + room], top):
            kind = ("РОУТЕР", AMBER) if p["kind"] == "router" else ("супер-узел", TEAL) if p["sup"] else ("узел", WHITE)
            hops = "—" if p["hops"] is None else str(p["hops"])
            cells = [pad(p["nick"][:17], 18), pad(p["ip"], 18), pad(hops, 7), c(kind[1], pad(kind[0], 11)),
                     pad("bt" if p["bt"] else "lan", 6), pad(ago(p["seen"]), 7)]
            row = " " + "".join(cells)
            lines.append(c(SEL, pad(row, w)) if i == sel else row)
        return lines

    def tab_files(self, w, h):
        a = self.app
        n, used = a.store.stats()
        limit = max(1, a.store.max)
        lines = ["", f" Кэш: {c(WHITE, n)} страниц, {c(WHITE, size(used))} из {size(limit)}   {bar(used / limit, 20, AMBER if used / limit > 0.8 else TEAL)}  {used * 100 // limit}%",
                 c(DIM, " " + "─" * (w - 2))]
        rows = self.rows(2)
        if not rows:
            return lines + ["", c(GREY, "   Пока пусто. Открой страницу в Chrome с установленным расширением.")]
        sel = min(self.sel[2], len(rows) - 1)
        room = h - len(lines)
        top = max(0, sel - room + 1) if sel >= room else 0
        for i, p in enumerate(rows[top: top + room], top):
            url = unquote(p["url"]).replace("https://", "").replace("http://", "")
            tag = "у соседа" if p["remote"] else size(p["size"])
            age, left = ago(p["saved"]), pad(url[: w - 26], w - 26)
            if i == sel:
                lines.append(c(SEL, pad(f" {left}  {pad(age, 6, True)}  {pad(tag, 8, True)}", w)))
            else:
                lines.append(f" {left}  {c(DIM, pad(age, 6, True))}  {c(BLUE if p['remote'] else GREY, pad(tag, 8, True))}")
        return lines

    def tab_settings(self, w, h):
        rows = self.settings()
        sel = min(self.sel[3], len(rows) - 1)
        lines = ["", c(GREY, "  Enter — переключить. Остальное правится в config.json, потом перезапуск."), ""]
        for i, (name, value, kind, key) in enumerate(rows):
            val = c(GREEN, value) if value == "ВКЛ" else c(GREY, value) if value == "выкл" else c(WHITE, value)
            mark = c(AMBER, "[ ]" if value == "выкл" else "[✔]") if kind == "toggle" else c(DIM, " · ")
            row = f"  {mark} {pad(name, 26)} {val}"
            lines.append(c(SEL, pad(ANSI.sub("", row), w)) if i == sel else row)
        return lines

    def tab_log(self, w, h):
        entries = list(dlog.ring)
        if not entries:
            return ["", c(GREY, "   Журнал пуст.")]
        total = len(entries)
        self.back = min(self.back, max(0, total - h))
        view = entries[max(0, total - h - self.back): total - self.back]
        out = []
        for line in view:
            ts, _, msg = line.partition(" ")
            col = (GREEN if msg.startswith(("peer+", "super:")) else RED if msg.startswith("peer-") else
                   AMBER if "timed out" in msg or "failed" in msg or "Error" in msg or "rejected" in msg else
                   TEAL if msg.startswith("net:") else BLUE if msg.startswith(("save", "page", "fetch")) else GREY)
            out.append(" " + c(DIM, ts) + " " + c(col, msg))
        if self.back:
            out[0] = c(AMBER, f" ▲ ещё {self.back} строк ниже — End вернёт к новым")
        return out


def run(app, quit_ev):
    ui = UI(app, quit_ev)
    out = sys.stdout
    out.write("\x1b[?1049h\x1b[?25l\x1b[2J")
    out.flush()
    last = 0.0
    try:
        with Raw():
            while not quit_ev.is_set():
                if time.time() - last >= 0.5:
                    w, h = shutil.get_terminal_size((100, 30))
                    try:
                        lines = ui.frame(w, h)
                    except Exception as e:  # интерфейс не должен ронять узел
                        lines = [c(RED, f"ошибка отрисовки: {type(e).__name__}: {e}")]
                    buf = ["\x1b[H"]
                    for i, ln in enumerate(lines[:h]):
                        buf.append(clip(ln, w) + "\x1b[K" + ("\r\n" if i < min(len(lines), h) - 1 else ""))
                    buf.append("\x1b[J")
                    out.write("".join(buf))
                    out.flush()
                    last = time.time()
                k = read_key(0.1)
                if k:
                    ui.handle(k)
                    last = 0.0
    finally:
        out.write("\x1b[?25h\x1b[?1049l")
        out.flush()
