import json
import os
import socket
import sys
import threading
import time
import uuid

import api
import bootstrap
import dlog
import netcheck
import policy
import service
from bt import Bluetooth
from kiwix import Kiwix
from p2p import P2P, TCP_PORT, UDP_PORT
from probe import Prober
from share import Share
from store import Store
from supernode import Super

VERSION = "0.4"
API_PORT = int(os.environ.get("DNET_API_PORT", 8765))
DEFAULT = {
    "id": "",
    "api_bind": "127.0.0.1",
    "nick": "",
    "ttl_days": 14,
    "max_mb": 200,
    "targets": {"provider": "", "city": "", "country": "ya.ru", "world": "1.1.1.1"},
    "static_peers": [],
    "probe": {"enabled": True, "max_hosts": 254},
    "super": {"enabled": False, "max_mb": 2000, "batch": 20},
    "bluetooth": {"enabled": False, "channel": 4, "peers": []},
    "replicate": {"enabled": True, "min_hits": 3, "batch": 5, "max_mb": 50},
    "kiwix": {"enabled": False, "url": "http://127.0.0.1:8080"},
    "share": {"enabled": False},
    "bootstrap": {"enabled": False, "urls": []},
}


def merge(base, over):
    out = dict(base)
    for k, v in over.items():
        out[k] = merge(base[k], v) if isinstance(v, dict) and isinstance(base.get(k), dict) else v
    return out


class App:
    pass


def build(home):
    """Создаёт и запускает все части узла. Возвращает app."""
    os.makedirs(home, exist_ok=True)
    path = os.path.join(home, "config.json")
    try:
        with open(path, encoding="utf-8") as f:
            cfg = merge(DEFAULT, json.load(f))
    except (OSError, ValueError):
        cfg = merge(DEFAULT, {})
    # для тестов нескольких узлов на одном компьютере
    for addr in filter(None, os.environ.get("DNET_STATIC_PEERS", "").split(",")):
        if addr.strip() not in cfg["static_peers"]:
            cfg["static_peers"].append(addr.strip())
    if os.environ.get("DNET_NO_PROBE"):
        cfg["probe"]["enabled"] = False
    if not cfg["id"]:
        cfg["id"] = uuid.uuid4().hex[:16]
    if not cfg["nick"]:
        cfg["nick"] = socket.gethostname() or "node"
    lock = threading.Lock()

    def save():
        with lock:
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)

    save()

    app = App()
    app.id = cfg["id"]
    app.cfg = cfg
    app.save = save
    app.store = Store(home, cfg["ttl_days"], cfg["max_mb"])
    dropped = app.store.purge(policy.blocked)
    if dropped:
        dlog.log(f"removed {dropped} private pages from cache")
    app.monitor = netcheck.Monitor(cfg, save)
    app.p2p = P2P(cfg, app.store, app.id, app.monitor)
    app.probe = Prober(cfg, app.monitor, app.p2p)
    app.super = Super(cfg, app.store, app.p2p, app.monitor, save)
    app.bt = Bluetooth(cfg, app.p2p)
    app.kiwix = app.p2p.kiwix = Kiwix(cfg)
    app.share = app.p2p.share = Share(cfg, lambda: cfg["nick"])
    app.bootstrap = bootstrap.Bootstrap(cfg, app.monitor, app.p2p)

    try:
        api.start(app, API_PORT)
        app.p2p.start()
    except OSError as e:
        sys.exit(f"Не удалось занять порт ({e}). Уже запущен другой узел?")
    for part in (app.monitor, app.probe, app.super, app.bt, app.bootstrap):
        part.start()
    app.share.start()
    dlog.log(f"node id={app.id} nick={cfg['nick']} home={home} super={cfg['super']['enabled']}")
    return app


def maintenance(app, ev):
    while not ev.wait(3600):
        app.store.cleanup()


def base_dir():
    return os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))


def home_dir():
    """Папка данных. Переносной режим: рядом с программой лежит файл portable.txt — тогда всё хранится в ./data."""
    if os.environ.get("DNET_HOME"):
        return os.environ["DNET_HOME"]
    root = base_dir()
    for cand in (root, os.path.dirname(root)):
        if os.path.exists(os.path.join(cand, "portable.txt")):
            return os.path.join(cand, "data")
    return os.path.join(os.path.expanduser("~"), ".dnet")


def already_running():
    """True, если на нашем API-порту уже отвечает узел DNet."""
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{API_PORT}/status", timeout=2) as r:
            return b'"nick"' in r.read(4096)
    except Exception:
        return False


def fatal(msg, gui):
    if gui:
        try:
            import tkinter
            from tkinter import messagebox
            r = tkinter.Tk()
            r.withdraw()
            messagebox.showerror("DNet", msg)
            r.destroy()
        except Exception:
            pass
    sys.exit(msg)


def main():
    args = sys.argv[1:]
    if "--autostart" in args:
        sys.exit(service.cli(args))
    if "--export" in args:  # python main.py --export <папка>: программа и расширения для флешки
        i = args.index("--export")
        dest = args[i + 1] if i + 1 < len(args) else "."
        print("Готово:", Share({}).export(dest))
        return
    if "--version" in args:
        print("DNet", VERSION)
        return
    frozen = getattr(sys, "frozen", False)
    tty = bool(sys.stdin and sys.stdout and sys.stdin.isatty() and sys.stdout.isatty())
    if sys.stdout is None:  # exe без консоли
        sys.stdout = sys.stderr = open(os.devnull, "w")
    want_gui = "--gui" in args or "--tray" in args or (frozen and not tty and "--no-ui" not in args)
    hidden = "--tray" in args
    home = home_dir()
    os.makedirs(home, exist_ok=True)
    if want_gui and already_running():
        import webbrowser
        webbrowser.open(f"http://127.0.0.1:{API_PORT}/")
        return
    if "--debug" in args:
        dlog.start(home)
    try:
        app = build(home)
    except SystemExit as e:
        fatal(str(e.code), want_gui)
    app.home = home
    app.api_port = API_PORT

    quit_ev = threading.Event()
    threading.Thread(target=maintenance, args=(app, quit_ev), daemon=True).start()
    use_tui = "--no-ui" not in args and not want_gui and tty
    try:
        if want_gui:
            try:
                import gui
            except ImportError as e:  # нет tkinter
                fatal(f"Нет графической библиотеки Tk ({e}). Запустите с --tui или --no-ui.", False)
            gui.run(app, quit_ev, hidden)
        elif use_tui:
            import tui
            tui.run(app, quit_ev)
        else:
            print(f"DNet запущен: id={app.id}, API {app.cfg.get('api_bind', '127.0.0.1')}:{API_PORT}, UDP {UDP_PORT}, TCP {TCP_PORT} (Ctrl+C — выход)")
            quit_ev.wait()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    os.system("")  # включает ANSI-последовательности в консоли Windows
    main()
