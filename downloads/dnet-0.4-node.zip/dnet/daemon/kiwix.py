"""Поддержка Kiwix (https://kiwix.org): Википедия и другие проекты Wikimedia из ZIM-файлов без интернета.

Узел не читает ZIM сам: он обращается к запущенному kiwix-serve (например `kiwix-serve --port 8080 книга.zim`)
и подставляет статью, когда настоящий адрес (https://ru.wikipedia.org/wiki/Москва) недоступен.
Соседи с включённым Kiwix отдают статьи по протоколу DNet (op "wiki"), так что ZIM достаточно иметь
на одном компьютере сети.
"""
import re
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import quote, unquote, urlparse

import dlog

MAX_BODY = 5 * 1024 * 1024
PROJECTS = {"wikipedia", "wiktionary", "wikibooks", "wikiquote", "wikisource", "wikinews", "wikiversity", "wikivoyage"}
HOST = re.compile(r"^(?P<lang>[a-z]{2,3}(?:-[a-z]+)?)\.(?:m\.)?(?P<proj>[a-z]+)\.org$")
CATALOG_TTL = 300


def parse(url):
    """(язык, проект, заголовок статьи) для адреса вида https://ru.wikipedia.org/wiki/Москва, иначе None."""
    try:
        u = urlparse(url)
    except ValueError:
        return None
    m = HOST.match((u.hostname or "").lower())
    if u.scheme not in ("http", "https") or not m or m["proj"] not in PROJECTS or not u.path.startswith("/wiki/"):
        return None
    title = u.path[len("/wiki/"):]
    if not title or unquote(title).split(":")[0] in ("Special", "Служебная"):
        return None
    return m["lang"], m["proj"], quote(unquote(title), safe="/:()'!*,;@~_-.")  # единый вид: %-кодирование UTF-8


class Kiwix:
    def __init__(self, cfg):
        self.cfg = cfg
        self.lock = threading.Lock()
        self.cache = ([], 0.0)

    def enabled(self):
        k = self.cfg.get("kiwix") or {}
        return bool(k.get("enabled") and str(k.get("url", "")).startswith(("http://", "https://")))

    def base(self):
        return str(self.cfg["kiwix"]["url"]).rstrip("/")

    def _get(self, path, limit=MAX_BODY):
        req = urllib.request.Request(self.base() + path, headers={"User-Agent": "DNet"})
        with urllib.request.urlopen(req, timeout=8) as r:
            body = r.read(limit + 1)
            if len(body) > limit:
                raise ValueError("слишком большой ответ")
            return r.geturl(), r.headers.get("Content-Type", ""), body

    def books(self):
        """Список книг kiwix-serve: [(имя, путь /content/…)]. Кэшируется на 5 минут."""
        with self.lock:
            lst, ts = self.cache
            if time.time() - ts < CATALOG_TTL:
                return lst
        out = []
        try:
            _, _, body = self._get("/catalog/v2/entries?count=200", 2 * 1024 * 1024)
            ns = {"a": "http://www.w3.org/2005/Atom"}
            for e in ET.fromstring(body).findall("a:entry", ns):
                for link in e.findall("a:link", ns):
                    href = link.get("href", "")
                    if link.get("type") == "text/html" and href.startswith("/content/"):
                        out.append((href.rsplit("/", 1)[-1], href))
        except Exception as e:
            dlog.exc("kiwix catalog", e)
        with self.lock:
            self.cache = (out, time.time())
        return out

    def check(self):
        """Число найденных книг или None, если kiwix-serve не отвечает."""
        self.cache = ([], 0.0)
        if not self.enabled():
            return None
        try:
            n = len(self.books())
            return n if n else None
        except Exception:
            return None

    def book_for(self, lang, proj):
        want = f"{proj}_{lang}"
        books = self.books()
        # предпочитаем полные сборки (all/maxi), потом любые подходящие
        best = [b for b in books if b[0].startswith(want + "_") or b[0] == want]
        best.sort(key=lambda b: ("maxi" not in b[0], "all" not in b[0], len(b[0])))
        return best[0] if best else None

    def get(self, url):
        """Статья из локального kiwix-serve в виде строки кэша или None."""
        p = parse(url)
        if not p or not self.enabled():
            return None
        book = self.book_for(p[0], p[1])
        if not book:
            return None
        for path in (f"{book[1]}/A/{p[2]}", f"{book[1]}/{p[2]}"):
            try:
                final, ct, body = self._get(path)
            except Exception:
                continue
            if ct.lower().startswith("text/html") and body:
                return {"url": url, "ctype": ct, "body": body, "saved": time.time(), "source": "kiwix", "base": final}
        return None
