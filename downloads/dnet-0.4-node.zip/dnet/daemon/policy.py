"""Что нельзя сохранять и отдавать соседям: поиск, страницы с запросами, почта, вход, кабинеты.
То же правило продублировано в extension/background.js."""
import re
from urllib.parse import urlparse

SEARCH_HOST = re.compile(r"(^|\.)(google\.[a-z.]+|bing\.com|yandex\.[a-z.]+|ya\.ru|duckduckgo\.com|"
                         r"yahoo\.[a-z.]+|ecosia\.org|baidu\.com|search\.brave\.com)$")
SENSITIVE_HOST = re.compile(r"^(mail|webmail|accounts?|login|signin|auth|id|passport|sso|oauth|bank|lk|my)\.")
SENSITIVE_PATH = re.compile(r"/(log-?in|sign-?in|log-?out|account|oauth|auth|password|checkout|cart|admin|"
                            r"wp-admin|profile|settings|messages)(/|$)")


def blocked(url):
    try:
        u = urlparse(url)
        host = (u.hostname or "").lower()
        if u.scheme not in ("http", "https") or not host:
            return True
        if u.query or u.username or u.password or u.port not in (None, 80, 443):
            return True
    except ValueError:
        return True
    return bool(SEARCH_HOST.search(host) or SENSITIVE_HOST.match(host) or SENSITIVE_PATH.search(u.path.lower()))
