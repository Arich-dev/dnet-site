"""Отладочный лог (python daemon/main.py --debug): пишет в debug.log и открывает окно, которое его показывает."""
import collections
import os
import shutil
import subprocess
import sys
import threading
import time

on = False
ring = collections.deque(maxlen=300)  # последние строки для вкладки «Журнал» (работает и без --debug)
path = None
_f = None
_lock = threading.Lock()
MAX = 2 * 1024 * 1024

TAIL = """
import os, sys, time
p = sys.argv[1]
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
print("DNet debug:", p, flush=True)
pos = 0


def parent_alive(pid):
    if os.name == "nt":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if not h:
            return False
        dead = ctypes.windll.kernel32.WaitForSingleObject(h, 0) == 0
        ctypes.windll.kernel32.CloseHandle(h)
        return not dead
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


node = int(sys.argv[2]) if len(sys.argv) > 2 else 0
while True:
    if node and not parent_alive(node):
        break  # узел остановлен — закрываем это окно, чтобы не висело
    try:
        size = os.path.getsize(p)
        if size < pos:
            pos = 0
            print("--- log truncated ---", flush=True)
        if size > pos:
            with open(p, "rb") as f:
                f.seek(pos)
                data = f.read()
            pos += len(data)
            sys.stdout.write(data.decode("utf-8", "replace"))
            sys.stdout.flush()
    except OSError:
        pass
    time.sleep(0.3)
"""


def log(msg):
    ring.append(time.strftime("%H:%M:%S ") + msg)
    if not on:
        return
    with _lock:
        try:
            if _f.tell() > MAX:
                _f.seek(0)
                _f.truncate()
            _f.write(time.strftime("%H:%M:%S ") + f"[{threading.current_thread().name[:12]}] {msg}\n")
            _f.flush()
        except (OSError, ValueError):
            pass


def exc(where, e):
    log(f"{where}: {type(e).__name__}: {e}")


def start(home):
    global on, path, _f
    path = os.path.join(home, "debug.log")
    _f = open(path, "w+", encoding="utf-8")
    on = True
    log("debug started")
    if not _window():
        print(f"Не удалось открыть окно логов. Смотри файл: {path}")


def _window():
    cmd = [sys.executable, "-u", "-c", TAIL, path, str(os.getpid())]
    try:
        if os.name == "nt":
            subprocess.Popen(cmd, creationflags=subprocess.CREATE_NEW_CONSOLE)
            return True
        if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            return False
        for term, sep in (("x-terminal-emulator", "-e"), ("gnome-terminal", "--"), ("konsole", "-e"), ("xterm", "-e")):
            if shutil.which(term):
                subprocess.Popen([term, sep] + cmd)
                return True
    except OSError:
        pass
    return False
