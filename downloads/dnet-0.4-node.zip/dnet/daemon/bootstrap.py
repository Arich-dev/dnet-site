"""Начальные адреса узлов из интернета (по желанию, выключено по умолчанию).

Широковещание не выходит за пределы подсети, а чтобы найти узлы «в городе», нужно знать хотя бы один адрес.
Пока интернет есть, узел может раз в час скачать короткий список адресов (JSON {"peers": ["203.0.113.5:48556"]})
и познакомиться с ними; дальше соседи рассказывают друг другу о своих соседях сами.
Включение: config.json -> "bootstrap": {"enabled": true, "urls": ["https://…/peers.json"]}. Источник видит ваш IP.
"""
import ipaddress
import json
import threading
import time
import urllib.request

import dlog

MAX_BYTES = 64 * 1024


class Bootstrap:
    def __init__(self, cfg, monitor, p2p):
        self.cfg, self.monitor, self.p2p = cfg, monitor, p2p

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            time.sleep(60)
            c = self.cfg.get("bootstrap") or {}
            try:
                if c.get("enabled") and self.monitor.state["levels"].get("world"):
                    for url in list(c.get("urls", []))[:3]:
                        self.fetch(url)
                    time.sleep(3600)
            except Exception as e:
                dlog.exc("bootstrap", e)

    def fetch(self, url):
        if not str(url).startswith("https://"):
            return 0
        req = urllib.request.Request(url, headers={"User-Agent": "DNet"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read(MAX_BYTES))
        n = 0
        for item in (data.get("peers") or [])[:50]:
            ip, _, port = str(item).partition(":")
            try:
                ipaddress.IPv4Address(ip)
            except ValueError:
                continue
            threading.Thread(target=self.p2p.hello, args=(ip, 120, int(port) if port.isdigit() else None), daemon=True).start()
            n += 1
        dlog.log(f"bootstrap {url}: {n} адресов")
        return n
