import ipaddress
import os
import re
import socket
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import dlog

WIN = os.name == "nt"
LEVELS = [("home", "Дом"), ("provider", "Провайдер"), ("city", "Город"), ("country", "Страна"), ("world", "Мир")]


def run(cmd, timeout):
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=0x08000000 if WIN else 0)
        return p.stdout.decode("cp866" if WIN else "utf-8", "ignore")
    except Exception:
        return ""


def ping(host, timeout=1.0, ttl=None):
    if not host or host.startswith("-"):
        return None
    t = ["-i" if WIN else "-t", str(ttl)] if ttl else []
    if WIN:
        cmd = ["ping", "-n", "1", "-w", str(int(timeout * 1000))] + t + [host]
    else:
        cmd = ["ping", "-c", "1", "-W", str(max(1, int(timeout + 0.5)))] + t + [host]
    m = re.search(r"ttl[=:]\s*(\d+)", run(cmd, timeout + 3), re.I)
    return int(m.group(1)) if m else None


def hops(host):
    t = ping(host)
    if t is None:
        return None
    init = next(x for x in (32, 64, 128, 255) if x >= t)
    return init - t + 1


def tcp_ok(host, ports=(443, 80, 53), timeout=1.5):
    for p in ports:
        try:
            socket.create_connection((host, p), timeout).close()
            return True
        except OSError as e:
            if getattr(e, "errno", None) in (111, 10061):
                return True
    return False


def reachable(host):
    return ping(host) is not None or tcp_ok(host)


def gateway():
    if WIN:
        best = None
        for line in run(["route", "print", "-4", "0.0.0.0"], 5).splitlines():
            p = line.split()
            if len(p) >= 5 and p[0] == "0.0.0.0" and p[1] == "0.0.0.0" and re.fullmatch(r"\d+\.\d+\.\d+\.\d+", p[2]):
                m = int(p[4]) if p[4].isdigit() else 9999
                if not best or m < best[0]:
                    best = (m, p[2])
        return best[1] if best else None
    try:
        for line in open("/proc/net/route").read().splitlines()[1:]:
            f = line.split()
            if f[1] == "00000000":
                return socket.inet_ntoa(bytes.fromhex(f[2])[::-1])
    except OSError:
        pass
    m = re.search(r"default via (\S+)", run(["ip", "route"], 3))
    return m.group(1) if m else None


def local_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for r in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(r[4][0])
    except OSError:
        pass
    return [i for i in ips if not i.startswith("127.")]


def trace_hops(target, maxh=12):
    if not target or target.startswith("-"):
        return []
    if WIN:
        cmd = ["tracert", "-d", "-h", str(maxh), "-w", "500", target]
    else:
        cmd = ["traceroute", "-n", "-q", "1", "-m", str(maxh), "-w", "1", target]
    out = []
    for line in run(cmd, 60).splitlines():
        m = re.match(r"\s*(\d+)\s", line)
        if m:
            ips = re.findall(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", line[m.end():])
            out.append(ips[0] if ips else None)
    return out


def trace_public(target, maxh=8):
    """Публичные (глобальные) адреса на пути до target по порядку, без самой цели.
    Первый — ближайший маршрутизатор провайдера, второй — следующий за ним (его «город»)."""
    out = []
    for ip in trace_hops(target, maxh):
        try:
            if ip and ip != target and ipaddress.ip_address(ip).is_global and ip not in out:
                out.append(ip)
        except ValueError:
            pass
    return out


def subnet_of(ip, bits=24):
    try:
        return str(ipaddress.ip_network(f"{ip}/{bits}", strict=False))
    except ValueError:
        return None


class Monitor:
    def __init__(self, cfg, save_cfg):
        self.cfg = cfg
        self.save_cfg = save_cfg
        self.state = {"levels": {k: None for k, _ in LEVELS}, "reach": None, "broken": None, "ts": 0, "hosts": {}}

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            try:
                self._check()
            except Exception as e:
                dlog.exc("monitor", e)
            time.sleep(10)

    def _check(self):
        t = self.cfg["targets"]
        gw = gateway()
        hosts = {"home": gw, "provider": t.get("provider") or self.cfg.get("auto_provider"),
                 "city": t.get("city") or self.cfg.get("auto_city"), "country": t.get("country"),
                 "world": t.get("world")}
        with ThreadPoolExecutor(5) as ex:
            res = dict(zip(hosts, ex.map(lambda h: reachable(h) if h else None, hosts.values())))
        if gw is None:
            res["home"] = False
        keys = [k for k, _ in LEVELS]
        top = max((i for i, k in enumerate(keys) if res[k]), default=-1)
        for i in range(top):
            res[keys[i]] = True
        reach = keys[top] if top >= 0 else None
        broken = next((k for k in keys[top + 1:] if res[k] is False), None)
        prev = self.state
        self.state = {"levels": res, "reach": reach, "broken": broken, "ts": time.time(),
                      "hosts": hosts}
        if prev["levels"] != res or prev["reach"] != reach:
            dlog.log(f"net: reach={reach} broken={broken} levels={res} hosts={hosts}")
        self._auto(gw, res, t)

    def _auto(self, gw, res, t):
        """Провайдер и город определяются сами по трассировке до «мира»: первые два публичных узла на пути.
        Пересчёт — при смене шлюза (другая сеть) и раз в сутки."""
        if not res["world"] or (t.get("provider") and t.get("city")):
            return
        c = self.cfg
        if c.get("auto_gw") == gw and time.time() - c.get("auto_ts", 0) < 86400 and c.get("auto_provider"):
            return
        path = trace_public(t.get("world") or "1.1.1.1")
        # берём только те узлы, что отвечают на ping: иначе уровень «город» вечно будет красным
        live = [ip for ip in path[:3] if reachable(ip)]
        c["auto_gw"], c["auto_ts"] = gw, time.time()
        c["auto_provider"] = live[0] if live else ""
        c["auto_city"] = live[1] if len(live) > 1 else ""
        dlog.log(f"auto: provider={c['auto_provider'] or '-'} city={c['auto_city'] or '-'} path={path}")
        self.save_cfg()
