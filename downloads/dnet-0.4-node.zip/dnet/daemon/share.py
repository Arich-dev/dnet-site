"""Раздача DNet соседям: маленькая страница в локальной сети, откуда можно скачать программу и расширения.

Выключено по умолчанию (config.json -> "share": {"enabled": true}). Отдаётся только публичное: сама программа
(exe или .pyz из исходников узла), папки расширений, инструкция. Настройки, кэш и страницы не отдаются никогда.
Порт: 48557 (DNET_SHARE_PORT). Для переноса без сети: share.export(папка) кладёт всё на флешку.
"""
import hashlib
import io
import os
import shutil
import socket
import sys
import threading
import zipfile
import zipapp
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import dlog
import netcheck

PORT = int(os.environ.get("DNET_SHARE_PORT", 48557))
FROZEN = bool(getattr(sys, "frozen", False))
HERE = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
ROOTS = [HERE, os.path.dirname(HERE)]  # рядом с программой или в корне проекта (daemon/..)
README = """DNet — сеть, которая работает без интернета
============================================

1. Установите программу:
   {app_hint}
2. Запустите DNet: окно и значок в трее. Права администратора не нужны.
3. Расширение для браузера:
   Chrome/Edge/Brave: распакуйте dnet-chrome.zip, откройте chrome://extensions, включите режим разработчика,
   «Загрузить распакованное» и выберите папку.
   Firefox: about:debugging -> Этот Firefox -> Загрузить временное дополнение -> manifest.json из распакованного dnet-firefox.xpi.
4. Разрешите в брандмауэре UDP 48555 и TCP 48556 для частной сети — тогда узлы найдут друг друга сами.

Подробнее: https://arich-dev.github.io/dnet-site/
"""
LANDING = """<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DNet — скачать у соседа</title>
<style>body{{font:16px/1.5 system-ui,sans-serif;max-width:640px;margin:30px auto;padding:0 16px;color:#1b2330}}
a.b{{display:block;margin:8px 0;padding:12px 16px;border-radius:8px;background:#14828c;color:#fff;text-decoration:none}}
a.b small{{opacity:.8}} code{{background:#eef2f7;padding:1px 5px;border-radius:4px}}</style>
<h1>DNet</h1>
<p>Сеть, которая работает без интернета: компьютеры находят друг друга сами и отдают сохранённые страницы.
Эту копию раздаёт <b>{nick}</b> — скачайте её прямо отсюда.</p>
{buttons}
<p><a href="/ПРОЧТИ-МЕНЯ.txt">Инструкция по установке</a></p>
<p style="color:#667286;font-size:13px">Раздаётся только сама программа и расширения. Сумма SHA-256 приложения:
<code>{sha}</code></p>
"""


def find_dir(name):
    for r in ROOTS:
        p = os.path.join(r, name)
        if os.path.isdir(p):
            return p
    return None


def zip_dir(folder, firefox=False):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(folder):
            for f in files:
                if f == "manifest.firefox.json" and not firefox:
                    continue
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, folder).replace(os.sep, "/"))
    return buf.getvalue()


def app_file():
    """(имя файла, байты) этой программы: сам exe или .pyz из исходников."""
    if FROZEN:
        with open(sys.executable, "rb") as f:
            return os.path.basename(sys.executable), f.read()
    src = os.path.dirname(os.path.abspath(__file__))
    buf = io.BytesIO()
    tmp = os.path.join(os.environ.get("TEMP", "/tmp"), f"dnet-pyz-{os.getpid()}")
    shutil.rmtree(tmp, ignore_errors=True)
    shutil.copytree(src, tmp, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    try:
        zipapp.create_archive(tmp, buf, interpreter="/usr/bin/env python3", main="main:main")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return "dnet.pyz", buf.getvalue()


class Share:
    def __init__(self, cfg, nick=lambda: "узел"):
        self.cfg = cfg
        self.nick = nick
        self.srv = None
        self.files = None

    def on(self):
        return bool((self.cfg.get("share") or {}).get("enabled"))

    def port(self):
        return PORT if self.srv else 0

    def url(self):
        ips = netcheck.local_ips()
        return f"http://{ips[0] if ips else '127.0.0.1'}:{PORT}/" if self.srv else ""

    def set_enabled(self, v):
        self.cfg.setdefault("share", {})["enabled"] = bool(v)
        self.start() if v else self.stop()

    def bundle(self):
        """Что раздаём: {путь: (байты, тип)}. Собирается один раз и кэшируется."""
        if self.files is not None:
            return self.files
        name, data = app_file()
        hint = (f"запустите {name}" if FROZEN else "python3 dnet.pyz --gui  (нужен Python 3.8+)")
        files = {"/" + name: (data, "application/octet-stream"),
                 "/ПРОЧТИ-МЕНЯ.txt": (README.format(app_hint=hint).encode(), "text/plain; charset=utf-8")}
        ch, ff = find_dir("extension"), find_dir("extension-firefox")
        if ch:
            files["/dnet-chrome.zip"] = (zip_dir(ch), "application/zip")
        if ff:
            files["/dnet-firefox.xpi"] = (zip_dir(ff), "application/x-xpinstall")
        files["_name"] = name
        files["_sha"] = hashlib.sha256(data).hexdigest()
        self.files = files
        return files

    def page(self):
        f = self.bundle()
        btn = [f'<a class="b" href="/{f["_name"]}">Программа DNet<br><small>{f["_name"]}, {len(f["/" + f["_name"]][0]) // 1024} КБ</small></a>']
        if "/dnet-chrome.zip" in f:
            btn.append('<a class="b" href="/dnet-chrome.zip">Расширение для Chrome / Edge / Brave<br><small>dnet-chrome.zip</small></a>')
        if "/dnet-firefox.xpi" in f:
            btn.append('<a class="b" href="/dnet-firefox.xpi">Расширение для Firefox<br><small>dnet-firefox.xpi</small></a>')
        return LANDING.format(nick=self.nick(), buttons="\n".join(btn), sha=f["_sha"]).encode()

    def start(self):
        if self.srv or not self.on():
            return
        share = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                path = self.path.split("?")[0]
                try:
                    if path in ("/", "/index.html"):
                        body, ct = share.page(), "text/html; charset=utf-8"
                    else:
                        from urllib.parse import unquote
                        item = share.bundle().get(unquote(path))
                        if not item or path.startswith("/_"):
                            self.send_error(404)
                            return
                        body, ct = item
                except Exception as e:
                    dlog.exc("share", e)
                    self.send_error(500)
                    return
                self.send_response(200)
                self.send_header("Content-Type", ct)
                self.send_header("Content-Length", str(len(body)))
                if not path.endswith(".txt") and path != "/":
                    self.send_header("Content-Disposition", "attachment")
                self.end_headers()
                self.wfile.write(body)

        class S(ThreadingHTTPServer):
            daemon_threads = True

        try:
            self.srv = S(("0.0.0.0", PORT), H)
        except OSError as e:
            dlog.log(f"share: порт {PORT} занят ({e})")
            return
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        dlog.log(f"share: раздаём DNet на порту {PORT}")

    def stop(self):
        if self.srv:
            self.srv.shutdown()
            self.srv.server_close()
            self.srv = None
            dlog.log("share: остановлено")

    def export(self, dest):
        """Кладёт программу, расширения и инструкцию в папку dest/DNet-share (для флешки). Возвращает путь."""
        out = os.path.join(dest, "DNet-share")
        os.makedirs(out, exist_ok=True)
        for path, item in self.bundle().items():
            if path.startswith("/"):
                with open(os.path.join(out, path.lstrip("/")), "wb") as f:
                    f.write(item[0])
        return out
