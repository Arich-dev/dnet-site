@echo off
rem DNet node launcher. Extra flags are passed to the node: run.bat --debug, run.bat --no-ui
rem (ASCII only on purpose: UTF-8 text in .bat files breaks cmd parsing)
title DNet
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.8+ from python.org and tick "Add to PATH".
    pause
    exit /b 1
)

python daemon\main.py %*
if errorlevel 1 pause
