"""Рисует значки расширений: python tools/make_icons.py -> extension/icons/*.png, site_src/static/favicon.png"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "daemon"))
import icon  # noqa: E402

out = ROOT / "extension" / "icons"
out.mkdir(parents=True, exist_ok=True)
for s in (16, 32, 48, 128):
    (out / f"icon{s}.png").write_bytes(icon.png(s, "brand"))
(ROOT / "site_src" / "static" / "icon.png").write_bytes(icon.png(128, "brand"))
print("значки готовы:", out)
