"""Собирает расширения: python tools/build_extensions.py

  extension-firefox/        — папка для «Временное дополнение» (about:debugging) в Firefox
  extension/ (Chrome)       — грузится как есть через chrome://extensions
Общий код (background.js, popup.*, icons/) живёт в extension/, у Firefox отличается только манифест.
Архивы для скачивания (dnet-chrome.zip, dnet-firefox.xpi) собирает site_src/build.py через pack().
"""
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHROME = ROOT / "extension"
FIREFOX = ROOT / "extension-firefox"
SHARED = ["background.js", "popup.html", "popup.js"]


def build_firefox():
    if FIREFOX.exists():
        shutil.rmtree(FIREFOX)
    FIREFOX.mkdir()
    for n in SHARED:
        shutil.copyfile(CHROME / n, FIREFOX / n)
    shutil.copytree(CHROME / "icons", FIREFOX / "icons")
    shutil.copyfile(CHROME / "manifest.firefox.json", FIREFOX / "manifest.json")


def pack(folder, dest):
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file() and p.name != "manifest.firefox.json":
                z.write(p, p.relative_to(folder).as_posix())


if __name__ == "__main__":
    build_firefox()
    print("extension-firefox/ собрана")
