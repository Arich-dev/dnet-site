"""Сборка для Linux и macOS (собирает для той системы, на которой запущена): python3 packaging/build_unix.py

  dist/dnet-<os>-<arch>.tar.gz   — программа (одним файлом), расширения, скрипт установки
  dist/dnet-<ver>.pyz            — переносимая версия на чистом Python (любая система с python3.8+, любой процессор)
Нужно для бинарников: pip install pyinstaller (Tk — для окна; без него работает консоль и --no-ui).
"""
import sys as _s
if hasattr(_s.stdout, "reconfigure"):
    _s.stdout.reconfigure(encoding="utf-8", errors="replace")
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import zipapp
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "daemon"))
sys.path.insert(0, str(ROOT / "tools"))
import build_extensions  # noqa: E402
import icon  # noqa: E402

VERSION = "0.4"
DIST, WORK = ROOT / "dist", ROOT / "build"
OS = {"linux": "linux", "darwin": "macos"}.get(sys.platform, sys.platform)
ARCH = {"x86_64": "x64", "amd64": "x64", "aarch64": "arm64", "arm64": "arm64"}.get(platform.machine().lower(), platform.machine().lower())


def pyz():
    app = WORK / "pyz"
    if app.exists():
        shutil.rmtree(app)
    shutil.copytree(ROOT / "daemon", app, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    out = DIST / f"dnet-{VERSION}.pyz"
    zipapp.create_archive(app, out, interpreter="/usr/bin/env python3", main="main:main")
    print("pyz:", out)


def binary():
    WORK.mkdir(exist_ok=True)
    DIST.mkdir(exist_ok=True)
    build_extensions.build_firefox()
    png = WORK / "dnet.png"
    png.write_bytes(icon.png(256, "brand"))
    args = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--log-level", "WARN", "--onefile",
            "--distpath", str(WORK / "out"), "--workpath", str(WORK / "tmp"), "--specpath", str(WORK / "spec"),
            "--paths", str(ROOT / "daemon"), "--add-data", f"{ROOT / 'daemon' / 'dashboard.html'}:.",
            "--name", "dnet", "--exclude-module", "numpy", "--exclude-module", "PIL"]
    for m in ("gui", "tui", "tray", "service", "icon", "bt"):
        args += ["--hidden-import", m]
    subprocess.run(args + [str(ROOT / "daemon" / "main.py")], check=True)
    exe = WORK / "out" / "dnet"
    name = f"dnet-{VERSION}-{OS}-{ARCH}"
    tgz = DIST / f"{name}.tar.gz"
    with tarfile.open(tgz, "w:gz") as t:
        t.add(exe, f"{name}/dnet", filter=lambda i: (setattr(i, "mode", 0o755), i)[1])
        for folder in ("extension", "extension-firefox"):
            for p in sorted((ROOT / folder).rglob("*")):
                if p.is_file() and p.name != "manifest.firefox.json":
                    t.add(p, f"{name}/{p.relative_to(ROOT).as_posix()}")
        inst = ROOT / "packaging" / ("linux/install.sh" if OS == "linux" else "macos/install.sh")
        if inst.exists():
            t.add(inst, f"{name}/install.sh", filter=lambda i: (setattr(i, "mode", 0o755), i)[1])
    print("binary:", tgz)


if __name__ == "__main__":
    DIST.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True)
    pyz()
    if "--pyz-only" not in sys.argv:
        binary()
