@echo off
rem Demo: two DNet nodes on one PC (use when other PCs are not reachable).
rem   Node A: the Chrome extension talks to it   -> panel http://127.0.0.1:8765/
rem   Node B: a second "computer"                -> panel http://127.0.0.1:8766/
rem Open pages in Chrome (saved to A), then open http://127.0.0.1:8766/ - they appear as "u soseda".
rem ASCII only on purpose: UTF-8 text in .bat files breaks cmd parsing.
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.8+ from python.org and tick "Add to PATH".
    pause
    exit /b 1
)

start "DNet A (8765)" cmd /k "set DNET_STATIC_PEERS=127.0.0.1:48656&& set DNET_NO_PROBE=1&& python daemon\main.py"
start "DNet B (8766)" cmd /k "set DNET_HOME=%USERPROFILE%\.dnet_B&& set DNET_UDP_PORT=48655&& set DNET_TCP_PORT=48656&& set DNET_API_PORT=8766&& set DNET_STATIC_PEERS=127.0.0.1:48556&& set DNET_NO_PROBE=1&& python daemon\main.py"
echo Started. Panels: http://127.0.0.1:8765/  and  http://127.0.0.1:8766/
timeout /t 4 >nul
start "" http://127.0.0.1:8766/
