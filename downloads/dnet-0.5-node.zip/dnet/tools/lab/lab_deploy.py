"""Копирует DNet на лабораторные VM и запускает узлы. python lab_deploy.py [start|stop|logs]"""
import json
import subprocess
import sys
import time

SSH = ["ssh", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL", "-o", "LogLevel=ERROR", "-o", "ConnectTimeout=8"]
PYZ = r"C:\Users\sema\Desktop\proekt10klass\dist\dnet-0.5.pyz"
REG = r"C:\Users\sema\Desktop\proekt10klass\server\dnet_registry.py"
BASE = {"api_bind": "0.0.0.0", "targets": {"world": "11.99.0.1", "country": "11.99.0.1"}, "probe": {"enabled": False}}
NODES = {
    "R": (2201, {**BASE, "nick": "R", "super": {"enabled": True, "max_mb": 50, "batch": 5},
                 "relay": {"serve": True}, "registry": {"urls": ["http://11.99.0.1:48560"], "announce": True}}),
    "NA": (2204, {**BASE, "nick": "NA", "registry": {"urls": ["http://11.99.0.1:48560"]}}),
    "NB": (2205, {**BASE, "nick": "NB", "registry": {"urls": ["http://11.99.0.1:48560"]}}),
}
KILL = "for p in $(ps | grep -E 'dnet.pyz|dnet_registry' | grep -v grep | awk '{print $1}'); do kill -9 $p; done"
ENV = "DNET_HOME=/root/dnet-home"


def ssh(port, cmd, data=None, timeout=60):
    r = subprocess.run(SSH + ["-p", str(port), "root@127.0.0.1", cmd], input=data, capture_output=True, timeout=timeout)
    return r.returncode, (r.stdout + r.stderr).decode("utf-8", "replace")


def deploy():
    pyz = open(PYZ, "rb").read()
    for name, (port, cfg) in NODES.items():
        ssh(port, KILL + "; rm -rf /root/reg; mkdir -p /root/dnet-home; rm -f /root/dnet-home/pages.db")
        ssh(port, "cat > /root/dnet.pyz", pyz)
        ssh(port, "cat > /root/dnet-home/config.json", json.dumps(cfg).encode())
        if name == "R":
            ssh(port, "cat > /root/dnet_registry.py", open(REG, "rb").read())
        print(name, "развёрнут")


def start(names=None):
    for name, (port, cfg) in NODES.items():
        if names and name not in names:
            continue
        if name == "R":
            ssh(port, "(python3 /root/dnet_registry.py --port 48560 --data /root/reg --allow-private > /root/reg.log 2>&1 < /dev/null &)", timeout=20)
        ssh(port, f"cd /root; ({ENV} python3 /root/dnet.pyz --no-ui --debug > /root/node.log 2>&1 < /dev/null &)", timeout=20)
        print(name, "запущен")


def stop(names=None):
    for name, (port, cfg) in NODES.items():
        if not names or name in names:
            ssh(port, KILL)


def status():
    for name, (port, cfg) in NODES.items():
        code, out = ssh(port, "wget -q -O - http://127.0.0.1:8765/status")
        try:
            st = json.loads(out)
            print(f"[{name}] peers:", [(p["nick"], p["via"], p["ip"]) for p in st["peers"]], "| nat:", st["nat"]["reachable"], st["nat"]["note"],
                  "| relay:", st["relay"], "| overlay:", {k: st["overlay"][k] for k in ("joined", "internet_peers", "error")})
        except ValueError:
            print(f"[{name}] нет ответа: {out.strip()[-200:]}")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "deploy"
    if cmd == "deploy":
        deploy()
    elif cmd == "start":
        start(sys.argv[2:])
    elif cmd == "stop":
        stop(sys.argv[2:])
    elif cmd == "status":
        status()
    elif cmd == "logs":
        for name, (port, _) in NODES.items():
            print("=====", name, ssh(port, "tail -n 25 /root/dnet-home/debug.log 2>/dev/null; tail -n 5 /root/node.log")[1][-2500:])
