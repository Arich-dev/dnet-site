"""Создаёт лабораторию: R (публичный узел), RA/RB (роутеры с NAT), NA/NB (компьютеры за роутерами)."""
import subprocess
import sys
import time

VB = r"E:\Program Files\Oracle\VirtualBox\VBoxManage.exe"
BASE = r"E:\dnet-lab\vms"
# имя: (ssh-порт хоста, [сети для NIC2, NIC3], порт API узла на хосте)
VMS = {
    "lab-R": (2201, ["dnet-inet"]),
    "lab-RA": (2202, ["dnet-inet", "dnet-lana"]),
    "lab-RB": (2203, ["dnet-inet", "dnet-lanb"]),
    "lab-NA": (2204, ["dnet-lana"]),
    "lab-NB": (2205, ["dnet-lanb"]),
}


def vb(*a, check=True):
    r = subprocess.run([VB, *a], capture_output=True, text=True)
    if check and r.returncode:
        raise SystemExit(f"VBoxManage {' '.join(a)}\n{r.stderr}")
    return r.stdout


def main():
    if "--stop-tpl" in sys.argv:
        vb("controlvm", "lab-tpl", "poweroff", check=False)
        time.sleep(3)
    existing = vb("list", "vms")
    for i, (name, (port, nets)) in enumerate(VMS.items()):
        if f'"{name}"' in existing:
            print(name, "уже есть")
            continue
        vb("clonevm", "lab-tpl", "--name", name, "--basefolder", BASE, "--register")
        args = ["modifyvm", name, "--nic1", "nat", "--nictype1", "virtio", "--natpf1", f"ssh,tcp,127.0.0.1,{port},,22",
                "--natpf1", f"api,tcp,127.0.0.1,{port + 6000},,8765",
                "--uart1", "0x3F8", "4", "--uartmode1", "server", r"\\.\pipe\%s" % name, "--memory", "256"]
        for n, net in enumerate(nets, start=2):
            args += [f"--nic{n}", "intnet", f"--nictype{n}", "virtio", f"--intnet{n}", net]
        vb(*args)
        print("создана", name)
    for name in VMS:
        vb("startvm", name, "--type", "headless")
        print("запущена", name)


if __name__ == "__main__":
    main()
