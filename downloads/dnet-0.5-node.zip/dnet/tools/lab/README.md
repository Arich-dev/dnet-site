# Лаборатория NAT на VirtualBox + OpenWrt

Пять виртуальных машин OpenWrt 23.05 (x86-64) имитируют интернет и два домашних NAT:

```
 lab-NA 192.168.10.2 ── lab-RA (NAT, miniupnpd) ──┐
                                                   ├── сеть «интернет» 11.99.0.0/24 ── lab-R 11.99.0.1 (публичный узел + реестр)
 lab-NB 192.168.20.2 ── lab-RB (NAT) ─────────────┘
```

Скрипты (пути внутри — под `E:\dnet-lab`, поправьте под себя):

| Файл | Что делает |
|---|---|
| `labctl.py` | управление гостем через последовательный порт VirtualBox (именованный канал), без сети |
| `lab_build.py` | клонирует шаблон `lab-tpl` (OpenWrt + `python3 python3-sqlite3`) в 5 машин, настраивает NIC и пробросы ssh |
| `lab_config.py` | задаёт сети машин командами `uci` |
| `lab_deploy.py` | копирует `dnet.pyz` и `dnet_registry.py`, запускает узлы, `status` / `logs` |

Шаблон: образ `openwrt-23.05.5-x86-64-generic-ext4-combined.img.gz` → `VBoxManage convertfromraw`, первая сетевая карта NAT с DHCP на `br-lan`, `opkg install python3 python3-sqlite3`.
Симметричный NAT на роутере: `nft add rule inet fw4 srcnat_wan oifname eth1 masquerade random`.
Результаты проверок — в [docs/NAT.md](../../docs/NAT.md).
