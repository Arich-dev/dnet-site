"""Управление лабораторными VM OpenWrt через последовательный порт (именованный канал VirtualBox)."""
import re
import sys
import threading
import time


class Serial:
    def __init__(self, name):
        self.f = open(r"\\.\pipe\%s" % name, "r+b", buffering=0)
        self.buf = b""
        self.lock = threading.Lock()
        threading.Thread(target=self._rd, daemon=True).start()

    def _rd(self):
        # блокирующее чтение держит синхронный дескриптор канала и мешает записи, поэтому сначала спрашиваем, есть ли данные
        import ctypes
        import msvcrt
        from ctypes import wintypes
        h = msvcrt.get_osfhandle(self.f.fileno())
        avail = wintypes.DWORD()
        while True:
            if not ctypes.windll.kernel32.PeekNamedPipe(wintypes.HANDLE(h), None, 0, None, ctypes.byref(avail), None):
                return
            if avail.value:
                d = self.f.read(avail.value)
                with self.lock:
                    self.buf += d
            else:
                time.sleep(0.02)

    def take(self):
        with self.lock:
            b, self.buf = self.buf, b""
        return b.decode("utf-8", "replace")

    def send(self, text):
        self.f.write(text.encode())

    def wait(self, pat, timeout=60):
        end, got = time.time() + timeout, ""
        while time.time() < end:
            got += self.take()
            if re.search(pat, got):
                return got
            time.sleep(0.2)
        raise TimeoutError("не дождались %r; получено: %r" % (pat, got[-300:]))

    def run(self, cmd, timeout=60):
        """Выполняет команду в оболочке гостя, возвращает (код, вывод)."""
        tag = "__D%d__" % (int(time.time() * 1000) % 100000)
        self.take()
        self.send("%s\n echo %s$?%s\n" % (cmd, tag, tag))
        out = self.wait(r"%s(\d+)%s\s*[\r\n]" % (tag, tag), timeout)
        m = re.search(r"%s(\d+)%s" % (tag, tag), out)
        return int(m.group(1)), re.sub(r"%s\d*%s" % (tag, tag), "", out)


if __name__ == "__main__":
    s = Serial(sys.argv[1])
    s.send("\n")
    print(repr(s.wait(r"#|login|OpenWrt", 90)[-200:]))
