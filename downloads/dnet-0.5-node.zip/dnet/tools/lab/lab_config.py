"""Настройка сетей лабораторных VM по последовательному порту."""
import sys
import time

sys.path.insert(0, r"E:\dnet-lab\tools")
from labctl import Serial

COMMON = [
    "uci set network.lan.metric='900'",
    "uci -q delete network.wan6",
    "uci -q delete network.globals.ula_prefix",
]
ROLES = {
    "lab-R": COMMON + [
        "uci -q delete network.wan",
        "uci set network.inet=interface", "uci set network.inet.device='eth1'", "uci set network.inet.proto='static'",
        "uci set network.inet.ipaddr='10.99.0.1'", "uci set network.inet.netmask='255.255.255.0'",
    ],
    "lab-RA": COMMON + [
        "uci set network.wan=interface", "uci set network.wan.proto='static'", "uci set network.wan.device='eth1'", "uci set network.wan.ipaddr='10.99.0.2'",
        "uci set network.wan.netmask='255.255.255.0'", "uci set network.wan.metric='10'",
        "uci set network.lana=interface", "uci set network.lana.device='eth2'", "uci set network.lana.proto='static'",
        "uci set network.lana.ipaddr='192.168.10.1'", "uci set network.lana.netmask='255.255.255.0'",
        "uci add_list firewall.@zone[0].network='lana'",
    ],
    "lab-RB": COMMON + [
        "uci set network.wan=interface", "uci set network.wan.proto='static'", "uci set network.wan.device='eth1'", "uci set network.wan.ipaddr='10.99.0.3'",
        "uci set network.wan.netmask='255.255.255.0'", "uci set network.wan.metric='10'",
        "uci set network.lanb=interface", "uci set network.lanb.device='eth2'", "uci set network.lanb.proto='static'",
        "uci set network.lanb.ipaddr='192.168.20.1'", "uci set network.lanb.netmask='255.255.255.0'",
        "uci add_list firewall.@zone[0].network='lanb'",
    ],
    "lab-NA": COMMON + [
        "uci -q delete network.wan",
        "uci set network.up=interface", "uci set network.up.device='eth1'", "uci set network.up.proto='static'",
        "uci set network.up.ipaddr='192.168.10.2'", "uci set network.up.netmask='255.255.255.0'",
        "uci set network.up.gateway='192.168.10.1'", "uci set network.up.metric='10'",
    ],
    "lab-NB": COMMON + [
        "uci -q delete network.wan",
        "uci set network.up=interface", "uci set network.up.device='eth1'", "uci set network.up.proto='static'",
        "uci set network.up.ipaddr='192.168.20.2'", "uci set network.up.netmask='255.255.255.0'",
        "uci set network.up.gateway='192.168.20.1'", "uci set network.up.metric='10'",
    ],
}
NOFW = {"lab-R", "lab-NA", "lab-NB"}


def configure(name):
    s = Serial(name)
    s.send("\n")
    time.sleep(1)
    s.send("\n")
    s.wait(r"root@OpenWrt|root@", 120)
    for c in ROLES[name]:
        s.run(c, 30)
    s.run("uci set system.@system[0].hostname='%s'" % name, 30)
    s.run("uci commit", 30)
    s.run("/etc/init.d/network restart", 60)
    time.sleep(6)
    if name in NOFW:
        s.run("/etc/init.d/firewall stop; /etc/init.d/firewall disable; /etc/init.d/dnsmasq stop; /etc/init.d/dnsmasq disable", 30)
    else:
        s.run("/etc/init.d/firewall restart", 60)
    s.run("echo 1 > /proc/sys/net/ipv4/ip_forward", 10)
    code, out = s.run("ip -4 -br addr; ip route", 20)
    print("=====", name, "\n", out.strip()[-700:], flush=True)


if __name__ == "__main__":
    for n in sys.argv[1:] or ROLES:
        configure(n)
