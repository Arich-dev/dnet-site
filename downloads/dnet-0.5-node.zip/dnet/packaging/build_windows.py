"""Сборка Windows-версий: python packaging/build_windows.py  ->  dist/

  dist/DNet.exe, dnet-cli.exe          — сам узел (окно+трей / консоль)
  dist/DNet-0.5-portable.zip           — переносная версия: распаковал и запустил, данные в папке data рядом
  dist/DNet-0.5-Setup.exe              — установщик без прав администратора (%LOCALAPPDATA%\\Programs\\DNet)
Нужно: pip install pyinstaller
"""
import sys as _s
if hasattr(_s.stdout, "reconfigure"):
    _s.stdout.reconfigure(encoding="utf-8", errors="replace")
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "daemon"))
sys.path.insert(0, str(ROOT / "tools"))
import icon  # noqa: E402
import build_extensions  # noqa: E402

VERSION = "0.5"
WORK = ROOT / "build"
DIST = ROOT / "dist"


def pyi(*args):
    cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--log-level", "WARN",
           "--distpath", str(WORK / "out"), "--workpath", str(WORK / "tmp"), "--specpath", str(WORK / "spec")] + list(args)
    subprocess.run(cmd, check=True)


def main():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir()
    DIST.mkdir(exist_ok=True)
    ico = WORK / "dnet.ico"
    ico.write_bytes(icon.ico((16, 24, 32, 48, 64, 128), "brand"))
    build_extensions.build_firefox()
    common = ["--onefile", "--icon", str(ico), "--paths", str(ROOT / "daemon"),
              "--add-data", f"{ROOT / 'daemon' / 'dashboard.html'};.",
              "--hidden-import", "gui", "--hidden-import", "tui", "--hidden-import", "tray",
              "--hidden-import", "service", "--hidden-import", "icon", "--hidden-import", "bt",
              "--exclude-module", "numpy", "--exclude-module", "PIL"]
    pyi("--windowed", "--name", "DNet", *common, str(ROOT / "daemon" / "main.py"))
    pyi("--console", "--name", "dnet-cli", *common, str(ROOT / "daemon" / "main.py"))
    out = WORK / "out"
    for n in ("DNet.exe", "dnet-cli.exe"):
        shutil.copyfile(out / n, DIST / n)

    def add_common(z, prefix=""):
        z.write(out / "DNet.exe", prefix + "DNet.exe")
        z.write(out / "dnet-cli.exe", prefix + "dnet-cli.exe")
        for folder in ("extension", "extension-firefox"):
            for p in sorted((ROOT / folder).rglob("*")):
                if p.is_file() and p.name != "manifest.firefox.json":
                    z.write(p, prefix + p.relative_to(ROOT).as_posix())

    portable = DIST / f"DNet-{VERSION}-portable.zip"
    with zipfile.ZipFile(portable, "w", zipfile.ZIP_DEFLATED) as z:
        add_common(z, "DNet/")
        z.writestr("DNet/portable.txt", "Пока этот файл лежит рядом с DNet.exe, все данные хранятся в папке data рядом с программой.\r\n"
                   "Удалите файл, чтобы использовать обычную папку пользователя (~/.dnet).\r\n")
        z.write(ROOT / "docs" / "PORTABLE.txt", "DNet/ПРОЧТИ-МЕНЯ.txt") if (ROOT / "docs" / "PORTABLE.txt").exists() else None
    payload = WORK / "payload.zip"
    with zipfile.ZipFile(payload, "w", zipfile.ZIP_DEFLATED) as z:
        add_common(z)
    pyi("--windowed", "--name", f"DNet-{VERSION}-Setup", "--onefile", "--icon", str(ico),
        "--add-data", f"{payload};.", str(ROOT / "packaging" / "installer.py"))
    shutil.copyfile(out / f"DNet-{VERSION}-Setup.exe", DIST / f"DNet-{VERSION}-Setup.exe")
    for p in sorted(DIST.iterdir()):
        print(f"{p.name:32} {p.stat().st_size / 1048576:6.1f} МБ")


if __name__ == "__main__":
    main()
