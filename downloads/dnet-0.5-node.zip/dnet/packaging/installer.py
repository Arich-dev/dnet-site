"""Установщик DNet для Windows. Права администратора НЕ нужны: ставит в %LOCALAPPDATA%\\Programs\\DNet.

DNet-Setup.exe            — окно установки (папка, ярлыки, автозапуск)
DNet-Setup.exe /S         — тихая установка, без окон (параметры по умолчанию)
DNet-Setup.exe --uninstall — удаление (эта же программа копируется в папку установки как uninstall.exe)
"""
import ctypes
import os
import shutil
import subprocess
import sys
import tkinter as tk
import winreg
import zipfile
from tkinter import filedialog, messagebox, ttk

NAME = "DNet"
VERSION = "0.5"
UNINST = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\DNet"
RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
ACC, BG = "#14828c", "#f4f6f9"
NOWIN = 0x08000000
CRLF = chr(13) + chr(10)


def resource(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


def default_dir():
    return os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), "Programs", NAME)


def run(cmd):
    return subprocess.run(cmd, capture_output=True, creationflags=NOWIN)


def stop_running():
    run(["taskkill", "/F", "/IM", "DNet.exe"])
    run(["taskkill", "/F", "/IM", "dnet-cli.exe"])


def shortcut(path, target, args="", workdir=""):
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';$s.Arguments='%s';"
          "$s.WorkingDirectory='%s';$s.IconLocation='%s,0';$s.Save()" % (path, target, args, workdir or os.path.dirname(target), target))
    run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps])


def start_menu():
    return os.path.join(os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu", "Programs", NAME)


def desktop():
    return os.path.join(os.path.expanduser("~"), "Desktop")


def install(folder, desk=True, auto=True, start=True, progress=lambda f: None):
    stop_running()
    os.makedirs(folder, exist_ok=True)
    with zipfile.ZipFile(resource("payload.zip")) as z:
        names = z.namelist()
        for i, n in enumerate(names):
            z.extract(n, folder)
            progress((i + 1) / len(names) * 0.8)
    exe = os.path.join(folder, "DNet.exe")
    # деинсталлятор — копия самого установщика
    un = os.path.join(folder, "uninstall.exe")
    shutil.copyfile(sys.executable, un)
    os.makedirs(start_menu(), exist_ok=True)
    shortcut(os.path.join(start_menu(), "DNet.lnk"), exe)
    shortcut(os.path.join(start_menu(), "DNet (консоль).lnk"), os.path.join(folder, "dnet-cli.exe"))
    shortcut(os.path.join(start_menu(), "Удалить DNet.lnk"), un, "--uninstall")
    if desk:
        shortcut(os.path.join(desktop(), "DNet.lnk"), exe)
    progress(0.9)
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINST) as k:
        for key, val in (("DisplayName", "DNet"), ("DisplayVersion", VERSION), ("Publisher", "DNet"),
                         ("InstallLocation", folder), ("DisplayIcon", exe),
                         ("UninstallString", f'"{un}" --uninstall'), ("QuietUninstallString", f'"{un}" --uninstall /S')):
            winreg.SetValueEx(k, key, 0, winreg.REG_SZ, val)
        winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)
    if auto:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN) as k:
            winreg.SetValueEx(k, NAME, 0, winreg.REG_SZ, f'"{exe}" --tray')
    progress(1.0)
    if start:
        subprocess.Popen([exe, "--tray"], cwd=folder, creationflags=NOWIN | 0x00000008, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return exe


def uninstall(purge=False):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, UNINST) as k:
            folder = winreg.QueryValueEx(k, "InstallLocation")[0]
    except OSError:
        folder = default_dir()
    stop_running()
    for root, sub in ((winreg.HKEY_CURRENT_USER, RUN),):
        try:
            with winreg.OpenKey(root, sub, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, NAME)
        except OSError:
            pass
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, UNINST)
    except OSError:
        pass
    shutil.rmtree(start_menu(), ignore_errors=True)
    try:
        os.remove(os.path.join(desktop(), "DNet.lnk"))
    except OSError:
        pass
    if purge:
        shutil.rmtree(os.path.join(os.path.expanduser("~"), ".dnet"), ignore_errors=True)
    # сам uninstall.exe занят — удаляем папку отдельным процессом после выхода
    import tempfile
    bat = os.path.join(tempfile.gettempdir(), 'dnet-uninstall.bat')
    lines = ['@echo off', 'for /l %%i in (1,1,20) do (',
             '  rmdir /s /q "%s" 2>nul' % folder,
             '  if not exist "%s" goto done' % folder,
             '  ping 127.0.0.1 -n 2 >nul', ')', ':done', '(goto) 2>nul & del "%~f0"']
    with open(bat, 'w', encoding='mbcs', errors='replace', newline='') as f:
        f.write(CRLF.join(lines) + CRLF)
    subprocess.Popen(['cmd', '/c', bat], creationflags=NOWIN, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


class Wizard:
    def __init__(self, uninst=False):
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
        self.un = uninst
        r = self.root = tk.Tk()
        r.title("Удаление DNet" if uninst else "Установка DNet")
        r.configure(bg=BG)
        r.resizable(False, False)
        s = ttk.Style(r)
        s.theme_use("clam")
        s.configure(".", background=BG, font=("Segoe UI", 10))
        s.configure("Accent.TButton", background=ACC, foreground="#fff", padding=(16, 7))
        s.map("Accent.TButton", background=[("active", "#0f6b73")])
        s.configure("TButton", padding=(14, 7))
        s.configure("TProgressbar", background=ACC)
        head = tk.Frame(r, bg=ACC)
        head.pack(fill="x")
        tk.Label(head, text="DNet " + VERSION, bg=ACC, fg="#fff", font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=20, pady=(14, 0))
        tk.Label(head, text="Сеть, которая работает без интернета", bg=ACC, fg="#cfeff1").pack(anchor="w", padx=20, pady=(0, 14))
        self.body = ttk.Frame(r, padding=20)
        self.body.pack(fill="both")
        (self.page_uninstall if uninst else self.page_install)()
        r.update_idletasks()
        w, h = r.winfo_reqwidth(), r.winfo_reqheight()
        r.geometry(f"+{(r.winfo_screenwidth() - w) // 2}+{(r.winfo_screenheight() - h) // 3}")

    def clear(self):
        for c in self.body.winfo_children():
            c.destroy()

    def page_install(self):
        b = self.body
        ttk.Label(b, text="Установка для текущего пользователя.\nПрава администратора не нужны.").pack(anchor="w")
        ttk.Label(b, text="Папка установки:").pack(anchor="w", pady=(14, 2))
        row = ttk.Frame(b)
        row.pack(fill="x")
        self.dir = tk.StringVar(value=default_dir())
        ttk.Entry(row, textvariable=self.dir, width=48).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Обзор…", command=lambda: self.dir.set(os.path.normpath(filedialog.askdirectory(initialdir=self.dir.get()) or self.dir.get()))).pack(side="left", padx=(8, 0))
        self.v_desk, self.v_auto, self.v_start = tk.BooleanVar(value=True), tk.BooleanVar(value=True), tk.BooleanVar(value=True)
        for var, text in ((self.v_desk, "Ярлык на рабочем столе"), (self.v_auto, "Запускать при входе в Windows (значок в трее)"),
                          (self.v_start, "Запустить DNet после установки")):
            ttk.Checkbutton(b, text=text, variable=var).pack(anchor="w", pady=2)
        self.bar = ttk.Progressbar(b, length=400)
        self.bar.pack(fill="x", pady=(14, 0))
        row = ttk.Frame(b)
        row.pack(fill="x", pady=(14, 0))
        self.go = ttk.Button(row, text="Установить", style="Accent.TButton", command=self.do_install)
        self.go.pack(side="right")
        ttk.Button(row, text="Отмена", command=self.root.destroy).pack(side="right", padx=8)

    def do_install(self):
        self.go.state(["disabled"])
        folder = os.path.normpath(self.dir.get())
        try:
            def prog(f):
                self.bar["value"] = f * 100
                self.root.update()
            install(folder, self.v_desk.get(), self.v_auto.get(), self.v_start.get(), prog)
        except Exception as e:
            messagebox.showerror("Установка DNet", f"Не удалось установить:\n{e}")
            self.go.state(["!disabled"])
            return
        self.clear()
        ttk.Label(self.body, text="Готово! DNet установлен.", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Label(self.body, text=f"Папка: {folder}\nЗначок DNet — в области уведомлений (трее).\n"
                  f"Расширения для браузеров лежат в папке:\n{os.path.join(folder, 'extension')}  (Chrome)\n"
                  f"{os.path.join(folder, 'extension-firefox')}  (Firefox)", justify="left").pack(anchor="w", pady=10)
        ttk.Button(self.body, text="Закрыть", style="Accent.TButton", command=self.root.destroy).pack(anchor="e")

    def page_uninstall(self):
        b = self.body
        ttk.Label(b, text="Удалить DNet с этого компьютера?").pack(anchor="w")
        self.purge = tk.BooleanVar(value=False)
        ttk.Checkbutton(b, text="Удалить также сохранённые страницы и настройки (~/.dnet)", variable=self.purge).pack(anchor="w", pady=10)
        row = ttk.Frame(b)
        row.pack(fill="x", pady=(10, 0))
        ttk.Button(row, text="Удалить", style="Accent.TButton", command=self.do_uninstall).pack(side="right")
        ttk.Button(row, text="Отмена", command=self.root.destroy).pack(side="right", padx=8)

    def do_uninstall(self):
        uninstall(self.purge.get())
        messagebox.showinfo("DNet", "DNet удалён.")
        self.root.destroy()


def main():
    args = [a.lower() for a in sys.argv[1:]]
    silent = "/s" in args or "--silent" in args
    if "--uninstall" in args:
        if silent:
            uninstall("--purge" in args)
        else:
            Wizard(True).root.mainloop()
        return
    if silent:
        folder = default_dir()
        for a in sys.argv[1:]:
            if a.upper().startswith("/D="):
                folder = a[3:]
        install(folder)
        return
    Wizard().root.mainloop()


if __name__ == "__main__":
    main()
