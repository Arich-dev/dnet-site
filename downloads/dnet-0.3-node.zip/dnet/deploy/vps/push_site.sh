#!/bin/sh
# Обновить сайт на VPS с компьютера (нужен вход по ключу):
#   sh deploy/vps/push_site.sh root@IP_СЕРВЕРА [путь_к_ключу] ["домен1 домен2"]
set -eu
HOST=${1:?"usage: sh deploy/vps/push_site.sh user@host [key] [server_name]"}
KEY=${2:-$HOME/.ssh/id_dnet_vps}
NAME=${3:-_}
cd "$(dirname "$0")/../.."
python site_src/build.py
tar -czf /tmp/dnet-site.tar.gz -C site .
scp -i "$KEY" -o IdentitiesOnly=yes /tmp/dnet-site.tar.gz deploy/vps/setup.sh deploy/vps/nginx-dnet.conf "$HOST":/tmp/
ssh -i "$KEY" -o IdentitiesOnly=yes "$HOST" "sh /tmp/setup.sh /tmp/dnet-site.tar.gz '$NAME'"
