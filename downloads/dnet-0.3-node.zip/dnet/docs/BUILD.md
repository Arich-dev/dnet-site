# Сборка из исходников

Нужен Python 3.8+ (для окна — с Tk; в Windows он есть по умолчанию). Сам узел собирать не нужно, он запускается как `python daemon/main.py`. Сборка нужна для готовых программ.

## Всё, что собирается

| Что | Команда | Результат |
|---|---|---|
| Windows: exe, установщик, портативная версия | `pip install pyinstaller` и `python packaging/build_windows.py` | `dist/DNet.exe`, `dnet-cli.exe`, `DNet-0.3-Setup.exe`, `DNet-0.3-portable.zip` |
| Linux / macOS: бинарник | `pip install pyinstaller` и `python3 packaging/build_unix.py` | `dist/dnet-0.3-<ос>-<арх>.tar.gz` |
| Любая система: один файл на Python | `python packaging/build_unix.py --pyz-only` | `dist/dnet-0.3.pyz` |
| Роутеры (6 архитектур) | `pip install ziglang` и `python router/build.py` | `dist/router/dnetd-<арх>` + `SHA256SUMS` |
| Расширение Firefox | `python tools/build_extensions.py` | папка `extension-firefox/` |
| Значки | `python tools/make_icons.py` | `extension/icons/*.png` |
| Сайт | `python site_src/build.py` | `site/` и архивы в `site/downloads/` |

PyInstaller собирает только под ту систему, на которой запущен. Поэтому в репозитории настроена **автосборка на GitHub Actions** (`.github/workflows/build.yml`): Windows, Linux (x64 и arm64), macOS (Intel и Apple Silicon) и роутеры собираются на чистых серверах.

| Событие | Что происходит |
|---|---|
| `git push` в `main` (не только правки документации и сайта) | Сборка всего, результат обновляет пререлиз **latest** на странице Releases |
| Там же | Сайт собирается со свежими программами и выкладывается в публичный репозиторий [dnet-site](https://github.com/Arich-dev/dnet-site) (GitHub Pages: https://arich-dev.github.io/dnet-site/); доступ — deploy-ключ в секрете `SITE_DEPLOY_KEY` |
| Тег `v*` (`git tag v0.3 && git push --tags`) | Сборка и обычный релиз с файлами и `SHA256SUMS.txt` |
| Actions → build → Run workflow | Ручная сборка, файлы доступны как артефакты запуска |

macOS на «хакинтоше» или обычном маке соберёт сам: `python3 packaging/build_unix.py`.

## Единственный экземпляр, портативный режим

- Повторный запуск `DNet.exe` не создаёт второй узел: он видит, что на порту 8765 уже отвечает DNet, и просто открывает панель.
- Файл `portable.txt` рядом с программой переключает хранение данных в `./data`. В исходниках, чтобы попробовать, положите его рядом с `daemon/` или в корень проекта.

## Расширения

`extension/` — исходники для Chrome (Manifest V3, фоновый service worker). Код общий для двух браузеров: используется `browser.*` (Firefox) или `chrome.*`. Единственное отличие — манифест: `extension/manifest.firefox.json` (Manifest V2, `browser_action`, фоновая страница, `browser_specific_settings`). Скрипт `tools/build_extensions.py` собирает из них готовую папку `extension-firefox/`, **не правьте её руками**: изменения делайте в `extension/` и пересобирайте.

## Сайт

`site_src/pages/*.html` — страницы (две первые строки `title:` и `desc:`), `layout.html` — шаблон, `static/` — стили и скрипты. `python site_src/build.py` собирает `site/` и считает контрольные суммы всех файлов для скачивания. Если в `dist/` лежат готовые exe, установщики и бинарники роутеров, сборщик положит их на страницу «Скачать». Выкладка на VPS: `deploy/vps/` (`push_site.sh`).

## Тесты

Автоматических тестов в репозитории нет; для проверки используйте:

```sh
python daemon/main.py --version
# два узла на одном компьютере (разные порты и папки):
demo_two_nodes.bat
```

Для проверки окна и трея запустите `python daemon/main.py --gui`.
