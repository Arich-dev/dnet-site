# Маяк для роутеров (`dnetd`)

`dnetd` — крошечная программа на C (только libc, без потоков и динамической памяти). Она делает роутер заметным для сети DNet:

- отвечает соседям на `hello` и `peers` (TCP 48556);
- запоминает, кто к нему заходил (таблица только в RAM, до 64 записей);
- рассылает UDP-маяк (порт 48555) в подсети роутера;
- страниц **не хранит**. В списке соседей отображается как `РОУТЕР`.

Нужна она, когда компьютеры дома не всегда включены одновременно: роутер включён всегда и подсказывает новым узлам, кто есть рядом. Бинарник весит 40–85 КБ, так что подходит даже для устройств с 4 МБ флеша.

## Быстрая установка

Готовые статические бинарники лежат в `dist/router/` (или в архиве `dnet-0.3-router.zip` на странице «Скачать»):

| Файл | Процессоры |
|---|---|
| `dnetd-mipsel` | MediaTek/Ralink/Atheros little-endian (MT7620/21/28, TP-Link WR741N и многие другие) |
| `dnetd-mips` | Atheros/QCA big-endian (AR71xx, ath79) |
| `dnetd-arm` | ARMv5–v7 (IPQ40xx, Marvell, Keenetic на ARM) |
| `dnetd-aarch64` | 64-бит ARM (MT7622/7981, RPi, Filogic) |
| `dnetd-x86`, `dnetd-x86_64` | x86-роутеры, мини-ПК, виртуалки |

Скопируйте папку `router/` на роутер и запустите скрипт — он сам определит архитектуру и систему:

```sh
scp -r router root@192.168.1.1:/tmp/dnet      # бинарники dnetd-* положите в эту же папку
ssh root@192.168.1.1 'sh /tmp/dnet/install.sh'
```

Удаление: `sh install.sh --remove`. Не знаете архитектуру: `ssh root@роутер uname -m` (для OpenWrt точнее `cat /etc/openwrt_release`; mips / mipsel различает сам скрипт).

## По системам

### OpenWrt

`install.sh` кладёт бинарник в `/usr/bin/dnetd`, службу procd — в `/etc/init.d/dnetd`, настройки — в `/etc/config/dnetd`:

```
config dnetd 'main'
	option enabled '1'
	option log '/tmp/dnetd.log'    # лог в RAM; пусто — без лога
```

Управление: `/etc/init.d/dnetd start|stop|restart|enable|disable`. Корень OpenWrt доступен только для чтения, поэтому лог по умолчанию пишется в `/tmp`.

Вручную (если скрипт не нужен): `scp dnetd-mipsel root@192.168.1.1:/usr/bin/dnetd`, скопировать `router/openwrt/dnetd.init` в `/etc/init.d/dnetd`, `chmod +x`, `/etc/init.d/dnetd enable && /etc/init.d/dnetd start`.

**Собственный пакет.** В `router/openwrt/package/dnetd` лежит описание пакета для SDK или buildroot (`make package/dnetd/compile`, подробности — в начале его `Makefile`). Тогда `dnetd` ставится как обычный `opkg`-пакет и попадает в прошивку.

**Фаервол.** Порты лежат в зоне `lan`, а она по умолчанию принимает входящие, так что ничего открывать не нужно. Не открывайте 48555/48556 в сторону WAN.

### Keenetic (Entware), Padavan

Нужен Entware (`/opt`). `install.sh` положит бинарник в `/opt/bin/dnetd` и скрипт `S99dnetd` в `/opt/etc/init.d`. Управление: `/opt/etc/init.d/S99dnetd start|stop|restart|status`.

### DD-WRT

1. Включите JFFS (Administration → Management → JFFS2) или подключите USB-флешку.
2. Скопируйте нужный `dnetd-<арх>` как `/jffs/dnetd` и `chmod +x`.
3. Содержимое `router/ddwrt/startup.sh` вставьте в Administration → Commands → «Save Startup». Скрипт перезапускает маяк, если тот упал.

### NetBSD, FreeBSD и другие

Соберите `dnetd` на самой системе (`cd router && make`), положите в `/usr/local/sbin/dnetd`, скрипт `router/netbsd/dnetd.rc` — в `/etc/rc.d/dnetd`, в `/etc/rc.conf` добавьте `dnetd=YES`.

### Обычный Linux, Raspberry Pi

`install.sh` создаст службу systemd `dnetd`. Но на плате с Linux лучше ставить полноценный узел, а не маяк (см. [INSTALL.md](INSTALL.md)).

## Параметры

```
dnetd [-l файл_лога] [-n]
  -l  путь к логу (по умолчанию dnetd.log рядом с бинарником)
  -n  без лога
```

Лог не больше 4 КБ (при переполнении начинается заново), сбрасывается при каждом запуске, пишется не чаще 30 строк в минуту — флеш не изнашивается.

## Сборка

```sh
pip install ziglang            # один кросс-компилятор на все архитектуры, SDK не нужен
python router/build.py         # -> dist/router/dnetd-<арх> и SHA256SUMS

cd router && make              # или обычным компилятором на этой машине
make CC=mipsel-openwrt-linux-musl-gcc     # тулчейном OpenWrt SDK
```

Сборка статическая (musl), поэтому один бинарник работает на любой прошивке с этой архитектурой, независимо от версии libc.

## Как проверить

1. На роутере: `ps | grep dnetd`, `cat /tmp/dnetd.log`.
2. На компьютере с DNet: вкладка «Соседи» — роутер появится в течение полуминуты с типом «роутер».
3. Вручную: `nc -w 2 192.168.1.1 48556` и введите `{"op":"hello"}` — вернётся JSON с `"kind":"router"`.
