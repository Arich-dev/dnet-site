import hashlib
import os
import re
import sqlite3
import threading
import time
import zlib
from urllib.parse import urldefrag


def norm(url):
    return urldefrag(url.strip())[0]


def key_of(url):
    return hashlib.sha256(norm(url).encode()).hexdigest()


class Store:
    def __init__(self, folder, ttl_days, max_mb):
        self.db = sqlite3.connect(os.path.join(folder, "pages.db"), check_same_thread=False)
        self.lock = threading.Lock()
        self.ttl = ttl_days * 86400
        self.max = max_mb * 1048576
        with self.lock:
            self.db.execute("CREATE TABLE IF NOT EXISTS pages(key TEXT PRIMARY KEY, url TEXT, ctype TEXT, body BLOB, saved REAL)")
            self.db.execute("CREATE INDEX IF NOT EXISTS ix_saved ON pages(saved)")
            self.db.execute("CREATE TABLE IF NOT EXISTS wants(key TEXT PRIMARY KEY, url TEXT, ts REAL, tries INTEGER)")
            self.db.commit()
        self.cleanup()

    def put(self, url, ctype, body, saved=None):
        url = norm(url)
        now = time.time()
        saved = min(saved or now, now)
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO pages VALUES(?,?,?,?,?)",
                            (key_of(url), url, ctype, zlib.compress(body), saved))
            self.db.execute("DELETE FROM wants WHERE key=?", (key_of(url),))
            self.db.commit()

    def get(self, key):
        with self.lock:
            r = self.db.execute("SELECT url, ctype, body, saved FROM pages WHERE key=?", (key,)).fetchone()
        if not r or r[3] < time.time() - self.ttl:
            return None
        return {"url": r[0], "ctype": r[1], "body": zlib.decompress(r[2]), "saved": r[3]}

    def saved(self, url):
        with self.lock:
            r = self.db.execute("SELECT saved FROM pages WHERE key=?", (key_of(url),)).fetchone()
        return r[0] if r else None

    def saved_key(self, key):
        with self.lock:
            r = self.db.execute("SELECT saved FROM pages WHERE key=?", (key,)).fetchone()
        return r[0] if r else None

    def items(self, n):
        with self.lock:
            rows = self.db.execute("SELECT key, url, saved, LENGTH(body) FROM pages WHERE saved>=? ORDER BY saved DESC LIMIT ?",
                                   (time.time() - self.ttl, n)).fetchall()
        return [list(r) for r in rows]

    def add_want(self, url):
        url = norm(url)
        if not re.fullmatch(r"https?://[^\s\x00-\x1f\x7f]{1,2000}", url):
            return
        with self.lock:
            if self.db.execute("SELECT COUNT(*) FROM wants").fetchone()[0] < 5000:
                self.db.execute("INSERT OR IGNORE INTO wants VALUES(?,?,?,0)", (key_of(url), url, time.time()))
                self.db.commit()

    def wants(self, n=50):
        with self.lock:
            return self.db.execute("SELECT key, url, tries FROM wants ORDER BY ts LIMIT ?", (n,)).fetchall()

    def count_wants(self):
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM wants").fetchone()[0]

    def bump_want(self, key):
        with self.lock:
            self.db.execute("UPDATE wants SET tries=tries+1 WHERE key=?", (key,))
            self.db.execute("DELETE FROM wants WHERE tries>=3")
            self.db.commit()

    def purge(self, pred):
        """Удаляет страницы, адрес которых подходит под pred. Возвращает их число."""
        with self.lock:
            bad = [(k,) for k, u in self.db.execute("SELECT key, url FROM pages").fetchall() if pred(u)]
            self.db.executemany("DELETE FROM pages WHERE key=?", bad)
            self.db.commit()
        return len(bad)

    def clear(self):
        with self.lock:
            self.db.execute("DELETE FROM pages")
            self.db.execute("DELETE FROM wants")
            self.db.commit()

    def stats(self):
        with self.lock:
            return self.db.execute("SELECT COUNT(*), COALESCE(SUM(LENGTH(body)),0) FROM pages").fetchone()

    def cleanup(self):
        with self.lock:
            self.db.execute("DELETE FROM pages WHERE saved < ?", (time.time() - self.ttl,))
            while self.db.execute("SELECT COALESCE(SUM(LENGTH(body)),0) FROM pages").fetchone()[0] > self.max:
                self.db.execute("DELETE FROM pages WHERE key IN (SELECT key FROM pages ORDER BY saved LIMIT 20)")
            self.db.commit()
