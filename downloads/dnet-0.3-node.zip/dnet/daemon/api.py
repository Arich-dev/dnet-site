import html
import json
import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import dlog
import policy
from store import key_of

MAX_BODY = 20 * 1024 * 1024
LOCAL = ("127.0.0.1", "::1", "::ffff:127.0.0.1")
def _read_dashboard():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard.html")
    try:
        with open(path, "rb") as f:
            return f.read()
    except OSError:  # запуск из .pyz (zipapp): файл лежит внутри архива
        return __loader__.get_data(path)


DASHBOARD = _read_dashboard()
DASH_CSP = ("default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
            "connect-src 'self'; img-src data:")


def decorate(row):
    body, ctype = row["body"], row["ctype"]
    if not ctype.lower().startswith("text/html"):
        return body
    url = html.escape(row["url"], quote=True)
    date = time.strftime("%Y-%m-%d %H:%M", time.localtime(row["saved"]))
    base = f'<base href="{url}">'.encode()
    bar = (f'<div style="background:#fe0;color:#000;padding:4px;font:12px sans-serif">'
           f'Копия из сети DNet от {date}</div>').encode("ascii", "xmlcharrefreplace")
    body = re.sub(rb"(<head[^>]*>)", lambda m: m.group(1) + base, body, count=1, flags=re.I)
    return re.sub(rb"(<body[^>]*>)", lambda m: m.group(1) + bar, body, count=1, flags=re.I)


def status(app, local):
    n, size = app.store.stats()
    return {"id": app.id, "nick": app.cfg["nick"], "pages": n, "bytes": size, "net": app.monitor.state,
            "super": app.super.on(), "scanner": app.probe.mode, "bluetooth": app.bt.status, "local": local,
            "nets": sorted(app.probe.nets.values(), key=lambda c: c["cidr"]),
            "peers": [{"ip": p["ip"], "hops": p["hops"], "nick": p["nick"], "kind": p["kind"], "super": p["sup"],
                       "via": p["via"]} for p in app.p2p.alive()]}


def pages_list(app):
    """Свои страницы + те, что есть только у соседей (по их индексу): такие открываются через P2P."""
    mine = app.store.items(500)
    have = {r[0] for r in mine}
    out = [{"url": r[1], "saved": r[2], "size": r[3], "remote": False} for r in mine]
    for k, v in list(app.p2p.index.items()):
        if k not in have:
            out.append({"url": v["url"], "saved": v["saved"], "size": 0, "remote": True})
    return out


def make_server(app, port):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def local(self):
            return self.client_address[0] in LOCAL

        def send(self, code, body, ctype="application/json", sandbox=False, csp=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            if sandbox:
                self.send_header("Content-Security-Policy", "sandbox")
            elif csp:
                self.send_header("Content-Security-Policy", csp)
            self.end_headers()
            self.wfile.write(body)

        def js(self, obj, code=200):
            self.send(code, json.dumps(obj).encode())

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            url = q.get("url", [""])[0]
            if u.path == "/":
                return self.send(200, DASHBOARD, "text/html; charset=utf-8", csp=DASH_CSP)
            if u.path == "/status":
                return self.js(status(app, self.local()))
            if u.path == "/pages":
                return self.js(pages_list(app))
            if not re.match(r"https?://", url):
                return self.js({"error": "bad url"}, 400)
            if u.path == "/has":
                return self.js({"saved": app.store.saved(url)})
            if u.path == "/page":
                local = app.store.get(key_of(url))
                row = local or app.p2p.fetch(url)
                dlog.log(f"page {url}: {'local' if local else 'from peer' if row else 'MISS'}")
                if row:
                    return self.send(200, decorate(row), row["ctype"], True)
                msg = "Страница не найдена ни у вас, ни у соседей.".encode("ascii", "xmlcharrefreplace")
                return self.send(404, b"<!doctype html><meta charset=utf-8><p>" + msg, "text/html; charset=utf-8", True)
            self.js({"error": "not found"}, 404)

        def do_POST(self):
            path = urlparse(self.path).path
            origin = self.headers.get("Origin", "")
            if not self.local():
                return self.js({"error": "forbidden"}, 403)
            if path == "/clear":
                if origin not in (f"http://127.0.0.1:{port}", f"http://localhost:{port}"):
                    return self.js({"error": "forbidden"}, 403)
                app.store.clear()
                dlog.log("cache cleared from dashboard")
                return self.js({"ok": True})
            if path != "/save" or not origin.startswith(("chrome-extension://", "moz-extension://")):
                return self.js({"error": "forbidden"}, 403)
            url = self.headers.get("X-Url", "")
            ctype = self.headers.get("X-Ctype", "")
            n = int(self.headers.get("Content-Length") or 0)
            if not re.match(r"https?://", url) or not ctype.lower().startswith("text/html") or not 0 < n <= MAX_BODY:
                return self.js({"error": "bad request"}, 400)
            if policy.blocked(url):
                dlog.log(f"save {url}: skipped (private)")
                return self.js({"ok": False, "skipped": "private"})
            app.store.put(url, ctype, self.rfile.read(n))
            dlog.log(f"save {url} ({n} bytes)")
            self.js({"ok": True})

    class S(ThreadingHTTPServer):
        daemon_threads = True

    return S((app.cfg.get("api_bind") or "127.0.0.1", port), H)


def start(app, port):
    srv = make_server(app, port)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
