import json
import os
import re
import socket
import threading
import time

import dlog
import netcheck
import policy
from store import key_of

# порты можно сменить переменными окружения (нужно для тестов нескольких узлов на одном компе)
UDP_PORT = int(os.environ.get("DNET_UDP_PORT", 48555))
TCP_PORT = int(os.environ.get("DNET_TCP_PORT", 48556))
MAX_LINE = 1024 * 1024
MAX_PAGE = 20 * 1024 * 1024
CT = re.compile(r"text/html\s*(;.*)?", re.I)
BT = socket.AF_BLUETOOTH if hasattr(socket, "AF_BLUETOOTH") and hasattr(socket, "BTPROTO_RFCOMM") else None
REFUSED = (111, 10061)


def bt_sock():
    return socket.socket(BT, socket.SOCK_STREAM, socket.BTPROTO_RFCOMM)


class P2P:
    def __init__(self, cfg, store, my_id, monitor=None):
        self.cfg = cfg
        self.store = store
        self.id = my_id
        self.monitor = monitor
        self.lock = threading.Lock()
        self.peers = {}
        self.index = {}
        self.hop_jobs = set()

    # ---------- таблица соседей ----------
    def hello_msg(self):
        return {"op": "hello", "id": self.id, "nick": str(self.cfg.get("nick", ""))[:32],
                "sup": bool(self.cfg["super"]["enabled"]), "port": TCP_PORT, "v": 1}

    def valid_hello(self, h):
        return (isinstance(h, dict) and h.get("op") == "hello" and isinstance(h.get("id"), str)
                and re.fullmatch(r"[0-9a-f]{8,64}", h["id"]) is not None
                and isinstance(h.get("nick"), str) and isinstance(h.get("sup"), bool)
                and isinstance(h.get("port"), int) and 0 < h["port"] < 65536)

    def add_peer(self, pid, ip, port, nick, sup, via, ttl, bt=False, kind="node"):
        if pid == self.id:
            return
        now = time.time()
        with self.lock:
            old = self.peers.get(pid)
            self.peers[pid] = {"id": pid, "ip": ip, "port": port, "nick": nick[:32], "sup": sup, "via": via,
                               "bt": bt, "kind": kind, "seen": now, "ttl": ttl, "hops": old["hops"] if old else None}
            need = not bt and (not old or old["hops"] is None or old["ip"] != ip) and ip not in self.hop_jobs
            if need:
                self.hop_jobs.add(ip)
        if old is None:
            dlog.log(f"peer+ {pid} {ip}:{port} {via} {kind}")
        if need:
            threading.Thread(target=self._hops, args=(pid, ip), daemon=True).start()

    def _hops(self, pid, ip):
        try:
            h = netcheck.hops(ip)
            with self.lock:
                if pid in self.peers and self.peers[pid]["ip"] == ip:
                    self.peers[pid]["hops"] = h
        finally:
            with self.lock:
                self.hop_jobs.discard(ip)

    def alive(self):
        now = time.time()
        with self.lock:
            for pid in [k for k, p in self.peers.items() if p["seen"] + p["ttl"] < now]:
                dlog.log(f"peer- {pid} {self.peers[pid]['ip']} (timeout)")
                del self.peers[pid]
            return sorted((dict(p) for p in self.peers.values()), key=lambda p: (p["hops"] is None, p["hops"] or 0))

    # ---------- сеть ----------
    def rpc(self, p, msg, timeout=5):
        try:
            if p.get("bt"):
                s = bt_sock()
                s.settimeout(timeout)
                s.connect((p["ip"], p["port"]))
            else:
                s = socket.create_connection((p["ip"], p["port"]), timeout)
            with s:
                s.settimeout(timeout)
                s.sendall(json.dumps(msg).encode() + b"\n")
                f = s.makefile("rb")
                head = json.loads(f.readline(MAX_LINE))
                n = head.pop("len", 0) if isinstance(head, dict) else 0
                if not isinstance(n, int) or not 0 <= n <= MAX_PAGE:
                    return None
                body = f.read(n) if n else b""
                return (head, body) if len(body) == n else None
        except Exception as e:
            dlog.exc(f"rpc {p.get('ip')}:{p.get('port')} {msg.get('op')}", e)
            return None

    def handle(self, rfile, send):
        """Один запрос на соединение. Возвращает разобранный запрос."""
        try:
            msg = json.loads(rfile.readline(MAX_LINE))
            op = msg.get("op")
            body = b""
            if op == "hello":
                head = self.hello_msg()
            elif op == "index":
                head = {"items": [[k, u, s, n] for k, u, s, n in self.store.items(150)
                                  if len(u) <= 2000 and not policy.blocked(u)]}
            elif op == "peers":
                head = {"peers": [[p["ip"], p["port"]] for p in self.alive() if not p["bt"]][:20]}
            elif op == "get":
                row = self.store.get(str(msg.get("key")))
                if row:
                    head = {"ok": True, "url": row["url"], "ctype": row["ctype"], "saved": row["saved"]}
                    body = row["body"]
                else:
                    head = {"ok": False}
            elif op == "want":
                if self.cfg["super"]["enabled"] and isinstance(msg.get("url"), str):
                    self.store.add_want(msg["url"])
                head = {"ok": True}
            else:
                head = {"error": "bad op"}
            if body:
                head["len"] = len(body)
            send(json.dumps(head).encode() + b"\n" + body)
            return msg
        except Exception as e:
            dlog.exc("handle", e)
            return None

    def hello(self, host, ttl=300, port=None):
        """None — хост не отвечает, False — жив, но не DNet, True — сосед добавлен."""
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        try:
            err = s.connect_ex((host, port or TCP_PORT))
        except OSError:
            s.close()
            return None
        if err != 0:
            s.close()
            return False if err in REFUSED else None
        try:
            with s:
                s.settimeout(4)
                s.sendall(json.dumps(self.hello_msg()).encode() + b"\n")
                h = json.loads(s.makefile("rb").readline(MAX_LINE))
        except Exception as e:
            dlog.exc(f"hello {host}: connected, no valid reply", e)
            return False
        if isinstance(h, dict) and h.get("id") == self.id:
            return False
        if not self.valid_hello(h):
            dlog.log(f"hello {host}: not a DNet node (bad reply)")
            return False
        self.add_peer(h["id"], host, h["port"], h["nick"], h["sup"], "lan", ttl,
                      kind="router" if h.get("kind") == "router" else "node")
        return True

    # ---------- обмен страницами ----------
    def fetch_key(self, key, pid):
        with self.lock:
            p = self.peers.get(pid)
            p = dict(p) if p else None
        if not p:
            return None
        r = self.rpc(p, {"op": "get", "key": key})
        if not r or not r[0].get("ok") or not isinstance(r[0].get("url"), str):
            dlog.log(f"fetch_key {key[:8]} from {p['ip']}: no page")
            return None
        h, body = r
        ct, url, saved = h.get("ctype", ""), h["url"], h.get("saved")
        if (not isinstance(ct, str) or not CT.fullmatch(ct) or not body or key_of(url) != key
                or not isinstance(saved, (int, float)) or policy.blocked(url)):
            dlog.log(f"fetch_key {key[:8]} from {p['ip']}: rejected (bad type, empty or url mismatch)")
            return None
        self.store.put(url, ct, body, saved)
        return self.store.get(key)

    def fetch(self, url):
        key = key_of(url)
        order = []
        hit = self.index.get(key)
        if hit:
            order.append(hit["from"])
        order += [p["id"] for p in self.alive() if p["id"] not in order and p["kind"] != "router"]
        for pid in order[:6]:
            row = self.fetch_key(key, pid)
            if row:
                dlog.log(f"fetch {url}: got from {pid}")
                return row
        dlog.log(f"fetch {url}: not found among {len(order)} peers")
        if self.cfg["super"]["enabled"]:
            self.store.add_want(url)
        for p in self.alive():
            if p["sup"]:
                threading.Thread(target=self.rpc, args=(p, {"op": "want", "url": url}), daemon=True).start()
        return None

    # ---------- фоновые потоки ----------
    def start(self):
        for f in (self._tcp, self._udp_listen, self._udp_beacon, self._sync):
            threading.Thread(target=f, daemon=True).start()

    def _tcp(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", TCP_PORT))
        srv.listen(64)
        while True:
            try:
                c, addr = srv.accept()
                threading.Thread(target=self._client, args=(c, addr[0]), daemon=True).start()
            except OSError:
                time.sleep(1)

    def _client(self, c, ip):
        try:
            with c:
                c.settimeout(10)
                msg = self.handle(c.makefile("rb"), c.sendall)
            if msg and self.valid_hello(msg) and msg["id"] != self.id:
                self.add_peer(msg["id"], ip, msg["port"], msg["nick"], msg["sup"], "lan", 300)
        except Exception:
            pass

    def _udp_listen(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", UDP_PORT))
        while True:
            try:
                data, addr = s.recvfrom(512)
                m = json.loads(data)
                if m.get("dnet") != 1 or m.get("id") == self.id:
                    continue
                with self.lock:
                    known = self.peers.get(m.get("id"))
                if known and time.time() - known["seen"] < 20:
                    continue
                dlog.log(f"beacon from {addr[0]} id={m.get('id')}, saying hello")
                threading.Thread(target=self.hello, args=(addr[0], 120), daemon=True).start()
            except Exception:
                time.sleep(0.2)

    def _udp_beacon(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while True:
            pkt = json.dumps({"dnet": 1, "id": self.id}).encode()
            targets = {"255.255.255.255"}
            for ip in netcheck.local_ips():
                targets.add(ip.rsplit(".", 1)[0] + ".255")
            for t in targets:
                try:
                    s.sendto(pkt, (t, UDP_PORT))
                except OSError:
                    pass
            time.sleep(15)

    def _sync(self):
        while True:
            try:
                self._sync_once()
            except Exception as e:
                dlog.exc("sync", e)
            time.sleep(20)

    def _sync_once(self):
        known = {(p["ip"], p["port"]) for p in self.alive()}
        mine = set(netcheck.local_ips())
        for addr in self.cfg.get("static_peers", []):
            if not isinstance(addr, str):
                continue
            ip, _, port = addr.partition(":")
            port = int(port) if port.isdigit() else TCP_PORT
            if (ip, port) not in known:
                self.hello(ip, 120, port)
        new = {}
        for p in self.alive():
            if p["bt"]:
                r = self.rpc(p, {"op": "hello"})
                if r and self.valid_hello(r[0]) and r[0]["id"] == p["id"]:
                    self.add_peer(p["id"], p["ip"], p["port"], r[0]["nick"], r[0]["sup"], p["via"], p["ttl"], True)
            else:
                self.hello(p["ip"], 120, p["port"])
            r = self.rpc(p, {"op": "index"}) if p["kind"] != "router" else None
            if r and isinstance(r[0].get("items"), list):
                for it in r[0]["items"]:
                    try:
                        k, u, s, n = it
                        if re.fullmatch(r"[0-9a-f]{64}", k) and key_of(u) == k and not policy.blocked(u):
                            if k not in new or s > new[k]["saved"]:
                                new[k] = {"url": u, "saved": float(s), "from": p["id"], "ts": time.time()}
                    except Exception:
                        pass
            if not p["bt"]:
                r = self.rpc(p, {"op": "peers"})
                if r and isinstance(r[0].get("peers"), list):
                    for item in r[0]["peers"][:5]:
                        try:
                            ip, port = str(item[0]), int(item[1])
                            socket.inet_aton(ip)
                            if ip not in mine and (ip, port) not in known:
                                known.add((ip, port))
                                self.hello(ip, 120, port)
                        except Exception:
                            pass
        now = time.time()
        old = {k: v for k, v in self.index.items() if now - v["ts"] < 600 and k not in new}
        old.update(new)
        self.index = old
        dlog.log(f"sync: peers={len(known)} index={len(old)}")
