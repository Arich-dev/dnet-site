import ipaddress
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import dlog
import netcheck

KEYS = [k for k, _ in netcheck.LEVELS]
GLOBAL_PAUSE = 1800


def resolve(h):
    try:
        ipaddress.ip_address(h)
        return h
    except ValueError:
        pass
    try:
        return socket.gethostbyname(h)
    except OSError:
        return None


class Prober:
    def __init__(self, cfg, monitor, p2p):
        self.cfg = cfg
        self.monitor = monitor
        self.p2p = p2p
        self.nets = {}
        self.path = []
        self.path_target = None
        self.resolved = {}
        self.last = {}
        self.mode = "wait"

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def limited(self):
        return self.monitor.state["reach"] in ("country", "world")

    def _loop(self):
        last = 0
        while True:
            time.sleep(5)
            try:
                if not self.monitor.state["ts"]:
                    continue
                if not self.cfg["probe"]["enabled"]:
                    self.mode = "off"
                    continue
                lim = self.limited()
                self.mode = "limited" if lim else "active"
                if time.time() - last >= (1800 if lim else 120):
                    self._cycle(lim)
                    last = time.time()
            except Exception as e:
                dlog.exc("probe", e)

    def _candidates(self, lim):
        st = self.monitor.state
        hosts = st["hosts"]
        out = []
        if not lim and st["reach"]:
            top = KEYS.index(st["reach"])
            levels = [(KEYS[i], hosts.get(KEYS[i])) for i in range(top, -1, -1)]
            far = levels[0][1]
            if far:
                self.path_target = far
                self.path = netcheck.trace_hops(far)
                out.append((st["reach"], far))
                out += [("hop", h) for h in reversed(self.path) if h]
            out += [(k, h) for k, h in levels[1:] if h]
        gw = hosts.get("home")
        if gw:
            out.append(("home", gw))
        out += [("home", ip) for ip in netcheck.local_ips()]
        return out

    def _cycle(self, lim):
        budget = self.cfg["probe"]["max_hosts"]
        seen = set()
        for label, h in self._candidates(lim):
            ip = resolve(h)
            self.resolved[h] = ip
            cidr = netcheck.subnet_of(ip) if ip else None
            if not cidr or cidr in seen:
                continue
            seen.add(cidr)
            a = ipaddress.ip_address(ip)
            if a.is_loopback or a.is_multicast or a.is_link_local or a.is_unspecified or a.is_reserved:
                continue
            if a.is_global:
                if lim or budget < 254 or time.time() - self.last.get(cidr, 0) < GLOBAL_PAUSE:
                    continue
                budget -= 254
            self.last[cidr] = time.time()
            self._sweep(cidr, label, 2400 if lim else 400)

    def _sweep(self, cidr, label, ttl):
        hosts = [str(h) for h in ipaddress.ip_network(cidr).hosts()]
        with ThreadPoolExecutor(64) as ex:
            res = list(ex.map(lambda h: self.p2p.hello(h, ttl), hosts))
        self.nets[cidr] = {"cidr": cidr, "label": label, "ts": time.time(),
                           "alive": sum(r is not None for r in res), "dnet": sum(bool(r) for r in res)}
        dlog.log(f"sweep {cidr} ({label}): {self.nets[cidr]['alive']} alive, {self.nets[cidr]['dnet']} DNet")
