"""Окно DNet (Tkinter) + значок в трее и мини-окно состояния. Только стандартная библиотека.

Запуск: python daemon/main.py --gui   (в окне)
        python daemon/main.py --tray  (сразу в трей, окно по клику)
"""
import os
import queue
import re
import sys
import time
import tkinter as tk
import webbrowser
from tkinter import messagebox, ttk

import dlog
import icon
import service
from api import pages_list
from tray import NullTray, Tray

APP = "DNet"
LV = [("home", "Дом"), ("provider", "Провайдер"), ("city", "Город"), ("country", "Страна"), ("world", "Мир")]
SCANNER = {"active": "ищет часто — интернета нет", "limited": "раз в 30 минут — интернет есть",
           "off": "выключен", "wait": "ждёт первой проверки сети"}
KIND = {"node": "узел", "router": "роутер"}
# палитра
BG, CARD, FG, MUT, LINE = "#f4f6f9", "#ffffff", "#1b2330", "#667286", "#dfe5ee"
OK, BAD, WARN, OFF, ACC = "#17a05d", "#d94646", "#e6a01e", "#aab4c2", "#14828c"
PEER = re.compile(r"^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?$")


def size(n):
    if n < 1024:
        return f"{n} Б"
    return f"{n / 1024:.0f} КБ" if n < 1 << 20 else f"{n / (1 << 20):.1f} МБ"


def ago(t):
    s = max(0, time.time() - t)
    if s < 60:
        return "только что"
    if s < 3600:
        return f"{int(s // 60)} мин назад"
    if s < 86400:
        return f"{int(s // 3600)} ч назад"
    return f"{int(s // 86400)} дн назад"


def net_state(app):
    """('ok'|'warn'|'bad'|'off', текст) по уровням сети."""
    st = app.monitor.state
    if not st["ts"]:
        return "off", "проверяю сеть…"
    lv = st["levels"]
    if lv.get("world"):
        return "ok", "интернет есть"
    if st["reach"] is None:
        return "bad", "нет связи даже с роутером"
    broken = dict(LV).get(st["broken"], "")
    return "warn", f"обрыв: нет связи дальше уровня «{dict(LV)[st['reach']]}»" + (f" ({broken})" if broken else "")


class GUI:
    def __init__(self, app, quit_ev, start_hidden=False):
        self.app, self.quit_ev = app, quit_ev
        self.port = getattr(app, "api_port", 8765)
        self.q = queue.Queue()
        self.mini = None
        self.mini_closed_at = 0.0
        self.last_log = 0
        self.dirty = {}
        self.root = tk.Tk()
        self.root.withdraw()
        self.root.title(APP)
        self.root.geometry("860x560")
        self.root.minsize(720, 480)
        self.root.configure(bg=BG)
        self.fonts()
        self.styles()
        self.set_icon()
        self.build()
        self.tray = self.make_tray()
        self.has_tray = self.tray.start()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.bind("<Escape>", lambda e: self.on_close())
        if not (start_hidden and self.has_tray):
            self.show()
        self.root.after(100, self.pump)
        self.refresh()

    # ---------- оформление ----------
    def fonts(self):
        fam = "Segoe UI" if os.name == "nt" else "TkDefaultFont"
        self.f = {"n": (fam, 10), "b": (fam, 10, "bold"), "h": (fam, 17, "bold"), "s": (fam, 9), "big": (fam, 26, "bold")}
        if fam == "TkDefaultFont":
            import tkinter.font as tkf
            base = tkf.nametofont("TkDefaultFont").actual()["family"]
            self.f = {k: (base,) + v[1:] for k, v in self.f.items()}

    def styles(self):
        s = ttk.Style(self.root)
        s.theme_use("clam")
        s.configure(".", background=BG, foreground=FG, font=self.f["n"], bordercolor=LINE)
        s.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
        s.configure("TNotebook.Tab", padding=(18, 8), background="#e6ebf2", foreground=MUT, font=self.f["b"], borderwidth=0)
        s.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", ACC)])
        s.configure("Card.TFrame", background=CARD)
        s.configure("TFrame", background=BG)
        s.configure("TLabel", background=BG)
        s.configure("Card.TLabel", background=CARD)
        s.configure("Mut.TLabel", background=CARD, foreground=MUT, font=self.f["s"])
        s.configure("TCheckbutton", background=CARD)
        s.configure("TButton", padding=(12, 6), background="#e6ebf2", borderwidth=0)
        s.map("TButton", background=[("active", "#d6dee9")])
        s.configure("Accent.TButton", background=ACC, foreground="#fff")
        s.map("Accent.TButton", background=[("active", "#0f6b73")])
        s.configure("Danger.TButton", foreground=BAD)
        s.configure("Treeview", background=CARD, fieldbackground=CARD, rowheight=26, borderwidth=0)
        s.configure("Treeview.Heading", background="#eef2f7", foreground=MUT, font=self.f["b"], relief="flat", padding=6)
        s.map("Treeview", background=[("selected", "#d9eef0")], foreground=[("selected", FG)])
        s.configure("TEntry", padding=5, fieldbackground="#fff")

    def set_icon(self):
        try:
            self.img = tk.PhotoImage(data=__import__("base64").b64encode(icon.png(64, "brand")))
            self.root.iconphoto(True, self.img)
        except tk.TclError:
            pass

    # ---------- построение окна ----------
    def build(self):
        r = self.root
        head = tk.Frame(r, bg=ACC)
        head.pack(fill="x")
        self.logo = tk.Label(head, image=self.img, bg=ACC)
        self.logo.pack(side="left", padx=(16, 10), pady=10)
        box = tk.Frame(head, bg=ACC)
        box.pack(side="left", pady=8)
        tk.Label(box, text="DNet", bg=ACC, fg="#fff", font=self.f["h"]).pack(anchor="w")
        self.who = tk.Label(box, text="", bg=ACC, fg="#cfeff1", font=self.f["s"])
        self.who.pack(anchor="w")
        self.badge = tk.Label(head, text="", bg=ACC, fg="#fff", font=self.f["b"])
        self.badge.pack(side="right", padx=18)

        foot = ttk.Frame(r, padding=(12, 8))
        foot.pack(side="bottom", fill="x")
        self.nb = ttk.Notebook(r)
        self.nb.pack(fill="both", expand=True, padx=12, pady=(10, 0))
        self.tabs = {}
        for key, title in (("net", "Сеть"), ("peers", "Соседи"), ("files", "Файлы"), ("set", "Настройки"), ("log", "Журнал")):
            fr = ttk.Frame(self.nb, style="Card.TFrame", padding=14)
            self.nb.add(fr, text=title)
            self.tabs[key] = fr
        self.build_net(self.tabs["net"])
        self.build_peers(self.tabs["peers"])
        self.build_files(self.tabs["files"])
        self.build_settings(self.tabs["set"])
        self.build_log(self.tabs["log"])

        ttk.Button(foot, text="Открыть панель в браузере", command=self.open_panel).pack(side="left")
        self.status = ttk.Label(foot, text="", foreground=MUT)
        self.status.pack(side="left", padx=14)
        ttk.Button(foot, text="Выход", style="Danger.TButton", command=self.quit).pack(side="right")
        ttk.Button(foot, text="В трей" if self.tray_possible() else "Свернуть", command=self.on_close).pack(side="right", padx=8)

    def tray_possible(self):
        return os.name == "nt" or "pystray" in sys.modules or self.has_tray_cached()

    def has_tray_cached(self):
        try:
            import pystray  # noqa: F401
            return True
        except Exception:
            return False

    def build_net(self, p):
        self.chain = tk.Canvas(p, height=92, bg=CARD, highlightthickness=0)
        self.chain.pack(fill="x")
        self.net_text = ttk.Label(p, text="", style="Card.TLabel", font=self.f["b"])
        self.net_text.pack(anchor="w", pady=(2, 0))
        self.scan_text = ttk.Label(p, text="", style="Mut.TLabel")
        self.scan_text.pack(anchor="w", pady=(2, 10))
        stats = ttk.Frame(p, style="Card.TFrame")
        stats.pack(fill="x", pady=(0, 10))
        self.stat = {}
        for key, cap in (("peers", "соседей"), ("pages", "страниц в кэше"), ("bytes", "занято (сжато)")):
            f = ttk.Frame(stats, style="Card.TFrame")
            f.pack(side="left", padx=(0, 36))
            self.stat[key] = ttk.Label(f, text="0", style="Card.TLabel", font=self.f["big"])
            self.stat[key].pack(anchor="w")
            ttk.Label(f, text=cap, style="Mut.TLabel").pack(anchor="w")
        ttk.Label(p, text="Найденные подсети", style="Mut.TLabel").pack(anchor="w")
        self.nets = self.tree(p, (("cidr", "Подсеть", 200), ("alive", "Живых хостов", 120), ("dnet", "С DNet", 100)), 5)

    def tree(self, parent, cols, height=10):
        fr = ttk.Frame(parent, style="Card.TFrame")
        fr.pack(fill="both", expand=True)
        t = ttk.Treeview(fr, columns=[c[0] for c in cols], show="headings", height=height, selectmode="browse")
        for key, title, wd in cols:
            t.heading(key, text=title)
            t.column(key, width=wd, anchor="w", stretch=True)
        sb = ttk.Scrollbar(fr, orient="vertical", command=t.yview)
        t.configure(yscrollcommand=sb.set)
        t.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        t.tag_configure("odd", background="#f8fafc")
        return t

    def fill(self, tree, rows):
        """Обновляет таблицу, сохраняя выделение и прокрутку."""
        sel = tree.selection()
        keep = tree.item(sel[0], "values")[0] if sel else None
        y = tree.yview()[0]
        tree.delete(*tree.get_children())
        pick = None
        for i, vals in enumerate(rows):
            iid = tree.insert("", "end", values=vals, tags=("odd",) if i % 2 else ())
            if keep is not None and vals[0] == keep:
                pick = iid
        if pick:
            tree.selection_set(pick)
        tree.yview_moveto(y)

    def build_peers(self, p):
        self.peers = self.tree(p, (("nick", "Имя", 180), ("ip", "Адрес", 140), ("hops", "Прыжков", 80),
                                   ("kind", "Тип", 110), ("via", "Канал", 80), ("seen", "Виден", 110)))
        self.peer_empty = ttk.Label(p, text="Соседей пока нет — они найдутся сами.", style="Mut.TLabel")

    def build_files(self, p):
        top = ttk.Frame(p, style="Card.TFrame")
        top.pack(fill="x", pady=(0, 8))
        self.q_var = tk.StringVar()
        e = ttk.Entry(top, textvariable=self.q_var)
        e.pack(side="left", fill="x", expand=True)
        self.q_var.trace_add("write", lambda *a: self.fill_files())
        ttk.Button(top, text="Открыть", command=self.open_page).pack(side="left", padx=8)
        ttk.Button(top, text="Очистить кэш…", style="Danger.TButton", command=self.clear_cache).pack(side="left")
        self.files = self.tree(p, (("url", "Адрес", 480), ("saved", "Сохранена", 120), ("size", "Размер", 80), ("where", "Где", 90)))
        self.files.bind("<Double-1>", lambda e: self.open_page())
        self.files.bind("<Return>", lambda e: self.open_page())
        self.pages = []

    def build_settings(self, p):
        cfg = self.app.cfg
        canvas = tk.Canvas(p, bg=CARD, highlightthickness=0, height=300)
        sbar = ttk.Scrollbar(p, command=canvas.yview)
        canvas.configure(yscrollcommand=sbar.set)
        sbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(-1 if e.delta > 0 else 1, "units") if self.nb.index(self.nb.select()) == 3 else None)
        inner = ttk.Frame(canvas, style="Card.TFrame")
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.pack(fill="both", expand=True)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self.v = {}

        def text(label, key, val, hint=""):
            row = ttk.Frame(inner, style="Card.TFrame")
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=label, style="Card.TLabel", width=26).pack(side="left")
            var = tk.StringVar(value=str(val))
            self.v[key] = var
            ttk.Entry(row, textvariable=var, width=34).pack(side="left")
            if hint:
                ttk.Label(row, text=hint, style="Mut.TLabel").pack(side="left", padx=10)

        def check(label, key, val, hint=""):
            row = ttk.Frame(inner, style="Card.TFrame")
            row.pack(fill="x", pady=3)
            var = tk.BooleanVar(value=bool(val))
            self.v[key] = var
            ttk.Checkbutton(row, text=label, variable=var).pack(side="left")
            if hint:
                ttk.Label(row, text=hint, style="Mut.TLabel").pack(side="left", padx=10)

        def head(t):
            ttk.Label(inner, text=t, style="Card.TLabel", font=self.f["b"], foreground=ACC).pack(anchor="w", pady=(12, 2))

        head("Узел")
        text("Имя в списках соседей", "nick", cfg["nick"])
        text("Хранить страницы, дней", "ttl_days", cfg["ttl_days"])
        text("Лимит кэша, МБ", "max_mb", cfg["max_mb"])
        head("Поиск соседей")
        check("Сканер подсетей", "probe", cfg["probe"]["enabled"], "при обрыве ищет узлы часто, при живом интернете — редко")
        check("Супер-узел", "super", cfg["super"]["enabled"], "большой кэш, докачивает страницы за других")
        text("Лимит кэша супер-узла, МБ", "super_mb", cfg["super"]["max_mb"])
        text("Соседи вручную", "peers", ", ".join(cfg["static_peers"]), "IP или IP:порт через запятую")
        check("Bluetooth", "bt", cfg["bluetooth"]["enabled"], "нужен перезапуск")
        head("Проверка сети")
        text("Страна (хост)", "t_country", cfg["targets"].get("country", ""))
        text("Мир (хост)", "t_world", cfg["targets"].get("world", ""))
        text("Город (хост, можно пусто)", "t_city", cfg["targets"].get("city", ""))
        head("Система")
        check("Запускать вместе с Windows" if os.name == "nt" else "Запускать при входе в систему",
              "autostart", service.status() is not None, "без прав администратора, только для вас")
        check("Показывать панель другим компьютерам сети", "lan", cfg.get("api_bind") == "0.0.0.0", "нужен перезапуск; запись и очистка — только с этого компьютера")
        row = ttk.Frame(inner, style="Card.TFrame")
        row.pack(fill="x", pady=(16, 0))
        ttk.Button(row, text="Сохранить", style="Accent.TButton", command=self.apply).pack(side="left")
        ttk.Button(row, text="Папка с данными", command=self.open_home).pack(side="left", padx=8)
        self.set_msg = ttk.Label(row, text="", style="Mut.TLabel")
        self.set_msg.pack(side="left", padx=10)

    def build_log(self, p):
        fr = ttk.Frame(p, style="Card.TFrame")
        fr.pack(fill="both", expand=True)
        self.log = tk.Text(fr, bg="#101820", fg="#c9d6e2", insertbackground="#fff", relief="flat", wrap="none",
                           font=("Consolas" if os.name == "nt" else "monospace", 9), state="disabled", padx=8, pady=6)
        sb = ttk.Scrollbar(fr, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        self.log.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    # ---------- трей и мини-окно ----------
    def make_tray(self):
        try:
            return Tray(lambda ev, data: self.q.put((ev, data)), self.menu, self.app.home)
        except Exception as e:
            dlog.exc("tray", e)
            return NullTray()

    def menu(self):
        return [("show", "Открыть окно DNet", False), ("panel", "Панель в браузере", False), None,
                ("autostart", "Запускать при входе в систему", service.status() is not None), None,
                ("quit", "Выход", False)]

    def pump(self):
        try:
            while True:
                ev, data = self.q.get_nowait()
                if ev == "show":
                    self.show()
                elif ev == "mini":
                    self.toggle_mini(data)
                elif ev == "panel":
                    self.open_panel()
                elif ev == "autostart":
                    self.toggle_autostart()
                elif ev == "quit":
                    self.quit()
                    return
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def toggle_autostart(self):
        try:
            if service.status():
                service.disable()
            else:
                service.enable()
            if "autostart" in self.v:
                self.v["autostart"].set(service.status() is not None)
        except Exception as e:
            messagebox.showerror(APP, f"Не удалось изменить автозапуск:\n{e}")

    def toggle_mini(self, pos):
        if self.mini and self.mini.winfo_exists():
            self.close_mini()
            return
        if time.time() - self.mini_closed_at < 0.3:  # клик по значку сам снял фокус и закрыл окно
            return
        self.open_mini(pos)

    def open_mini(self, pos):
        m = tk.Toplevel(self.root)
        self.mini = m
        m.overrideredirect(True)
        m.attributes("-topmost", True)
        m.configure(bg=LINE)
        body = tk.Frame(m, bg=CARD, padx=14, pady=12)
        body.pack(padx=1, pady=1, fill="both")
        top = tk.Frame(body, bg=CARD)
        top.pack(fill="x")
        self.m_dot = tk.Canvas(top, width=14, height=14, bg=CARD, highlightthickness=0)
        self.m_dot.pack(side="left")
        tk.Label(top, text="DNet", bg=CARD, fg=FG, font=self.f["h"]).pack(side="left", padx=8)
        self.m_state = tk.Label(body, text="", bg=CARD, fg=MUT, font=self.f["s"], anchor="w", justify="left", wraplength=250)
        self.m_state.pack(fill="x", pady=(2, 8))
        self.m_levels = tk.Canvas(body, width=252, height=40, bg=CARD, highlightthickness=0)
        self.m_levels.pack()
        self.m_info = tk.Label(body, text="", bg=CARD, fg=FG, font=self.f["n"], anchor="w", justify="left")
        self.m_info.pack(fill="x", pady=(6, 10))
        for text, cmd, style in (("Открыть окно", self.show, "Accent.TButton"), ("Панель в браузере", self.open_panel, "TButton")):
            ttk.Button(body, text=text, style=style, command=lambda c=cmd: (self.close_mini(), c())).pack(fill="x", pady=2)
        sup = ttk.Checkbutton(body, text="Супер-узел", command=self.toggle_super)
        self.m_super = tk.BooleanVar(value=self.app.super.on())
        sup.configure(variable=self.m_super)
        sup.pack(anchor="w", pady=(6, 0))
        ttk.Button(body, text="Выход", style="Danger.TButton", command=self.quit).pack(fill="x", pady=(6, 0))
        self.paint_mini()
        m.update_idletasks()
        w, h = m.winfo_reqwidth(), m.winfo_reqheight()
        sw, sh = m.winfo_screenwidth(), m.winfo_screenheight()
        x, y = pos if pos else (sw - w - 12, sh - h - 60)
        m.geometry(f"+{max(0, min(x - w // 2, sw - w - 8))}+{max(0, min(y - h - 16, sh - h - 48))}")
        m.bind("<Escape>", lambda e: self.close_mini())
        m.bind("<FocusOut>", lambda e: self.root.after(120, self.mini_focus_check))
        m.after(50, lambda: (m.focus_force(), m.lift()))

    def mini_focus_check(self):
        m = self.mini
        if m and m.winfo_exists():
            f = m.focus_get()
            if f is None or str(f).split(".")[1:2] != str(m).split(".")[1:2]:
                self.close_mini()

    def close_mini(self):
        if self.mini and self.mini.winfo_exists():
            self.mini.destroy()
            self.mini_closed_at = time.time()
        self.mini = None

    def toggle_super(self):
        self.app.super.set_enabled(self.m_super.get())
        if "super" in self.v:
            self.v["super"].set(self.app.super.on())

    def paint_mini(self):
        if not (self.mini and self.mini.winfo_exists()):
            return
        st, txt = net_state(self.app)
        col = {"ok": OK, "warn": WARN, "bad": BAD, "off": OFF}[st]
        self.m_dot.delete("all")
        self.m_dot.create_oval(2, 2, 13, 13, fill=col, outline="")
        self.m_state.configure(text=txt[:1].upper() + txt[1:])
        self.draw_levels(self.m_levels, 252, 40, compact=True)
        n, b = self.app.store.stats()
        self.m_info.configure(text=f"Соседей: {len(self.app.p2p.alive())}\nСтраниц в кэше: {n} ({size(b)})")

    # ---------- рисование цепочки ----------
    def draw_levels(self, c, wd, ht, compact=False):
        c.delete("all")
        lv = self.app.monitor.state["levels"]
        step = wd / len(LV)
        cy = ht * (0.32 if not compact else 0.4)
        r = 9 if not compact else 6
        for i, (k, name) in enumerate(LV):
            x = step * i + step / 2
            v = lv.get(k)
            col = OK if v is True else BAD if v is False else OFF
            if i:
                pv = lv.get(LV[i - 1][0])
                c.create_line(x - step + r + 2, cy, x - r - 2, cy, fill=OK if (pv and v) else "#ccd4df", width=3)
            c.create_oval(x - r, cy - r, x + r, cy + r, fill=col, outline="")
            c.create_text(x, cy + r + 12, text=name, fill=MUT if compact else FG, font=self.f["s"])

    # ---------- обновление данных ----------
    def refresh(self):
        try:
            self.update_all()
        except Exception as e:
            dlog.exc("gui", e)
        self.root.after(2000, self.refresh)

    def update_all(self):
        a = self.app
        st, txt = net_state(a)
        peers = a.p2p.alive()
        col = {"ok": OK, "warn": WARN, "bad": BAD, "off": OFF}[st]
        self.who.configure(text=f"{a.cfg['nick']} · {a.id}")
        self.badge.configure(text=("● " + txt[:1].upper() + txt[1:]))
        self.tray.set_state(st, f"DNet — {txt}\nСоседей: {len(peers)}")
        self.paint_mini()
        tab = self.nb.index(self.nb.select())
        if tab == 0:
            self.draw_levels(self.chain, max(self.chain.winfo_width(), 400), 92)
            self.net_text.configure(text=txt[:1].upper() + txt[1:], foreground=col)
            self.scan_text.configure(text="Сканер подсетей: " + SCANNER.get(a.probe.mode, a.probe.mode)
                                     + ("  ·  супер-узел" if a.super.on() else ""))
            n, b = a.store.stats()
            self.stat["peers"].configure(text=str(len(peers)))
            self.stat["pages"].configure(text=str(n))
            self.stat["bytes"].configure(text=size(b))
            self.fill(self.nets, [(c["cidr"], c["alive"], c["dnet"]) for c in sorted(a.probe.nets.values(), key=lambda c: c["cidr"])])
        elif tab == 1:
            now = time.time()
            self.fill(self.peers, [(p["nick"], f"{p['ip']}:{p['port']}" if p["port"] != 48556 else p["ip"],
                                    "—" if p["hops"] is None else p["hops"],
                                    "супер-узел" if p["sup"] else KIND.get(p["kind"], p["kind"]),
                                    "bluetooth" if p["bt"] else "сеть", f"{int(now - p['seen'])} с назад") for p in peers])
        elif tab == 2:
            self.pages = sorted(pages_list(a), key=lambda p: -p["saved"])
            self.fill_files()
        elif tab == 4:
            self.update_log()
        self.status.configure(text=f"Порт панели: {self.port}")

    def fill_files(self):
        f = self.q_var.get().strip().lower()
        rows = [(p["url"], ago(p["saved"]) if p["saved"] else "—", size(p["size"]) if p["size"] else "—",
                 "у соседа" if p["remote"] else "здесь") for p in self.pages if not f or f in p["url"].lower()]
        self.fill(self.files, rows[:500])

    def update_log(self):
        lines = list(dlog.ring)
        if len(lines) == self.last_log and self.last_log:
            return
        self.last_log = len(lines)
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.insert("end", "\n".join(lines) or "Пока пусто.")
        self.log.see("end")
        self.log.configure(state="disabled")

    # ---------- действия ----------
    def show(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()
        self.refresh_now()

    def refresh_now(self):
        try:
            self.update_all()
        except Exception as e:
            dlog.exc("gui", e)

    def on_close(self):
        if self.has_tray:
            self.root.withdraw()
        else:
            self.root.iconify()

    def quit(self):
        self.close_mini()
        self.tray.stop()
        self.quit_ev.set()
        self.root.destroy()

    def open_panel(self):
        webbrowser.open(f"http://127.0.0.1:{self.port}/")

    def open_page(self):
        sel = self.files.selection()
        if sel:
            url = self.files.item(sel[0], "values")[0]
            from urllib.parse import quote
            webbrowser.open(f"http://127.0.0.1:{self.port}/page?url={quote(url, safe='')}")

    def open_home(self):
        path = self.app.home
        if os.name == "nt":
            os.startfile(path)
        elif sys.platform == "darwin":
            import subprocess
            subprocess.Popen(["open", path])
        else:
            webbrowser.open("file://" + path)

    def clear_cache(self):
        n, _ = self.app.store.stats()
        if messagebox.askyesno(APP, f"Удалить все сохранённые страницы на этом узле ({n} шт.)?", parent=self.root):
            self.app.store.clear()
            dlog.log("cache cleared from gui")
            self.refresh_now()

    def apply(self):
        a, v = self.app, self.v
        cfg = a.cfg
        try:
            nick = v["nick"].get().strip()[:32]
            ttl = int(v["ttl_days"].get())
            mx = int(v["max_mb"].get())
            smx = int(v["super_mb"].get())
            if not nick or not 1 <= ttl <= 3650 or not 10 <= mx <= 100000 or not 10 <= smx <= 1000000:
                raise ValueError("проверьте имя, срок (1–3650 дней) и лимиты кэша (от 10 МБ)")
            peers = [x.strip() for x in v["peers"].get().replace(";", ",").split(",") if x.strip()]
            bad = [x for x in peers if not PEER.match(x)]
            if bad:
                raise ValueError("не похоже на адрес соседа: " + bad[0])
        except ValueError as e:
            messagebox.showwarning(APP, str(e), parent=self.root)
            return
        cfg["nick"], cfg["ttl_days"], cfg["max_mb"] = nick, ttl, mx
        cfg["super"]["max_mb"] = smx
        cfg["static_peers"] = peers
        cfg["probe"]["enabled"] = v["probe"].get()
        cfg["bluetooth"]["enabled"] = v["bt"].get()
        cfg["targets"].update(country=v["t_country"].get().strip(), world=v["t_world"].get().strip(),
                              city=v["t_city"].get().strip())
        cfg["api_bind"] = "0.0.0.0" if v["lan"].get() else "127.0.0.1"
        a.store.ttl, a.store.max = ttl * 86400, mx * 1048576
        a.super.set_enabled(v["super"].get())  # сохраняет конфиг
        a.save()
        note = "Сохранено."
        if v["autostart"].get() != (service.status() is not None):
            try:
                service.enable() if v["autostart"].get() else service.disable()
            except Exception as e:
                note = f"Сохранено, но автозапуск не изменился: {e}"
        self.set_msg.configure(text=note)
        self.root.after(5000, lambda: self.set_msg.configure(text=""))


def run(app, quit_ev, hidden=False):
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    g = GUI(app, quit_ev, start_hidden=hidden)
    quit_ev_poll(g)
    g.root.mainloop()


def quit_ev_poll(g):
    """Если узел остановили снаружи (Ctrl+C, сигнал), закрыть окно."""
    def check():
        if g.quit_ev.is_set():
            try:
                g.tray.stop()
                g.root.destroy()
            except tk.TclError:
                pass
            return
        g.root.after(500, check)
    g.root.after(500, check)
