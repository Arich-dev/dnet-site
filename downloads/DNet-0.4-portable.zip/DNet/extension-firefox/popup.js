const ext = globalThis.browser || globalThis.chrome;
const DEFAULT_API = "http://127.0.0.1:8765";
let api = DEFAULT_API;

function row(label, value, cls) {
  const d = document.createElement("div");
  d.className = "row";
  const a = document.createElement("span");
  a.className = "mut";
  a.textContent = label;
  const b = document.createElement("span");
  b.textContent = value;
  if (cls) b.className = cls;
  d.append(a, b);
  return d;
}

// Общий выключатель: хранится в storage.local, его читает background.js.
async function initPower() {
  const box = document.getElementById("power");
  const text = document.getElementById("power-text");
  const note = document.getElementById("off-note");
  const show = (on) => {
    box.checked = on;
    text.textContent = on ? "Включено" : "Выключено";
    note.hidden = on;
  };
  const s = await ext.storage.local.get({ enabled: true, api: DEFAULT_API });
  api = s.api || DEFAULT_API;
  show(s.enabled !== false);
  box.addEventListener("change", () => {
    ext.storage.local.set({ enabled: box.checked });
    show(box.checked);
  });
  const input = document.getElementById("addr");
  input.value = api;
  document.getElementById("addr-save").addEventListener("click", async () => {
    let v = input.value.trim().replace(/\/+$/, "");
    try {
      const x = new URL(v);
      if (x.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(x.hostname)) throw 0;
      v = x.origin;
    } catch {
      input.setCustomValidity("Нужен адрес вида http://127.0.0.1:8765");
      input.reportValidity();
      return;
    }
    input.setCustomValidity("");
    await ext.storage.local.set({ api: v });
    api = v;
    load();
  });
}

async function load() {
  const state = document.getElementById("state");
  const info = document.getElementById("info");
  state.replaceChildren();
  info.replaceChildren();
  try {
    const s = await (await fetch(`${api}/status`)).json();
    state.append(row("Узел", "работает", "ok"));
    const levels = s.net.levels || {};
    const down = Object.keys(levels).filter((k) => levels[k] === false);
    info.append(row("Ник", s.nick), row("Соседей", s.peers.length), row("Страниц в кэше", s.pages),
      row("Интернет", down.length ? "есть проблемы" : "в порядке", down.length ? "bad" : "ok"));
  } catch (e) {
    state.append(row("Узел", "не запущен", "bad"));
    info.append(row("Как запустить", "DNet из меню Пуск или run.bat"));
  }
}

(async () => {
  try {
    await initPower();
  } catch (e) {}
  await load();
  document.getElementById("open").addEventListener("click", () => {
    ext.tabs.create({ url: `${api}/` });
    window.close();
  });
})();
