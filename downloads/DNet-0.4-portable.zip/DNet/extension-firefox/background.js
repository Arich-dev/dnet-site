// DNet: общий код для Chrome (MV3, service worker) и Firefox (MV2, фоновая страница).
const ext = globalThis.browser || globalThis.chrome;
const action = ext.action || ext.browserAction;

const DEFAULT_API = "http://127.0.0.1:8765";
const MAX_AGE = 12 * 3600;
const MAX_BODY = 20 * 1024 * 1024;
const OFFLINE = new RegExp(
  "ERR_(INTERNET_DISCONNECTED|NAME_NOT_RESOLVED|NAME_RESOLUTION_FAILED|CONNECTION_(TIMED_OUT|RESET|REFUSED|CLOSED|ABORTED)|" +
  "TIMED_OUT|ADDRESS_UNREACHABLE|NETWORK_CHANGED|PROXY_CONNECTION_FAILED|SOCKET_NOT_CONNECTED)|" +
  "NS_ERROR_(UNKNOWN_HOST|UNKNOWN_PROXY_HOST|NET_TIMEOUT|NET_RESET|NET_INTERRUPT|NET_ON_CONNECTED|OFFLINE|" +
  "CONNECTION_REFUSED|PROXY_CONNECTION_REFUSED)"
);

// То же правило, что в daemon/policy.py: поиск, запросы, почта, вход и кабинеты не сохраняем.
const SEARCH_HOST = /(^|\.)(google\.[a-z.]+|bing\.com|yandex\.[a-z.]+|ya\.ru|duckduckgo\.com|yahoo\.[a-z.]+|ecosia\.org|baidu\.com|search\.brave\.com)$/;
const SENSITIVE_HOST = /^(mail|webmail|accounts?|login|signin|auth|id|passport|sso|oauth|bank|lk|my)\./;
const SENSITIVE_PATH = /\/(log-?in|sign-?in|log-?out|account|oauth|auth|password|checkout|cart|admin|wp-admin|profile|settings|messages)(\/|$)/;
const LOCAL_HOST = /^(localhost|0\.0\.0\.0|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.)|\.(local|lan|internal|home|localdomain)$/;

function isPublic(u) {
  try {
    const x = new URL(u);
    const h = x.hostname.toLowerCase();
    return /^https?:$/.test(x.protocol) && !h.startsWith("[") && !LOCAL_HOST.test(h) && h.includes(".");
  } catch {
    return false;
  }
}

function isPrivate(u) {
  try {
    const x = new URL(u);
    const h = x.hostname.toLowerCase();
    return !!(x.search || x.username || x.password || (x.port && x.port !== "80" && x.port !== "443") ||
      SEARCH_HOST.test(h) || SENSITIVE_HOST.test(h) || SENSITIVE_PATH.test(x.pathname.toLowerCase()));
  } catch {
    return true;
  }
}

function shareable(u) {
  return isPublic(u) && !isPrivate(u);
}

// ---------- настройки ----------
let enabled = true;
let api = DEFAULT_API;

function cleanApi(v) {
  try {
    const x = new URL(v);
    if (x.protocol === "http:" && ["127.0.0.1", "localhost"].includes(x.hostname)) return x.origin;
  } catch {}
  return DEFAULT_API;
}

function paint() {
  action.setBadgeText({ text: enabled ? "" : "OFF" });
  if (action.setBadgeBackgroundColor) action.setBadgeBackgroundColor({ color: "#777777" });
}

const ready = ext.storage.local.get({ enabled: true, api: DEFAULT_API }).then((s) => {
  enabled = s.enabled !== false;
  api = cleanApi(s.api);
  paint();
});

ext.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.enabled) enabled = changes.enabled.newValue !== false;
  if (changes.api) api = cleanApi(changes.api.newValue);
  paint();
});

// ---------- сохранение ----------
const busy = new Set();

async function save(url) {
  if (busy.has(url)) return;
  busy.add(url);
  try {
    const has = await (await fetch(`${api}/has?url=${encodeURIComponent(url)}`)).json();
    if (has.saved && Date.now() / 1000 - has.saved < MAX_AGE) return;
    const r = await fetch(url, { credentials: "omit", cache: "no-store" });
    const ct = r.headers.get("content-type") || "";
    if (!r.ok || r.redirected || !ct.toLowerCase().startsWith("text/html")) return;
    const body = await r.arrayBuffer();
    if (body.byteLength > MAX_BODY) return;
    await fetch(`${api}/save`, { method: "POST", headers: { "X-Url": url, "X-Ctype": ct }, body });
  } catch (e) {
    // узел не запущен или страница недоступна — молча пропускаем
  } finally {
    busy.delete(url);
  }
}

ext.webNavigation.onCompleted.addListener(async (d) => {
  await ready;
  if (!enabled || d.frameId !== 0 || !shareable(d.url)) return;
  try {
    const tab = await ext.tabs.get(d.tabId);
    if (tab.incognito) return;
  } catch {
    return;
  }
  save(d.url.split("#")[0]);
});

// Ошибка сети: если копия есть у нас или у соседей — открываем её, иначе оставляем обычную страницу ошибки.
ext.webNavigation.onErrorOccurred.addListener(async (d) => {
  await ready;
  if (!enabled || d.frameId !== 0 || !OFFLINE.test(d.error) || !shareable(d.url)) return;
  const copy = `${api}/page?url=${encodeURIComponent(d.url)}`;
  try {
    const r = await fetch(copy);
    if (!r.ok) return;
  } catch {
    return;
  }
  ext.tabs.update(d.tabId, { url: copy });
});
