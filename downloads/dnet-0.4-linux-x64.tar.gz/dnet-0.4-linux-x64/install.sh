#!/bin/sh
# Установка DNet для текущего пользователя, БЕЗ root. Запускать из распакованной папки:  sh install.sh
# Ставит в ~/.local/opt/dnet, команда `dnet` в ~/.local/bin, ярлык в меню, автозапуск по желанию.
# Удаление: sh install.sh --remove
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
DEST="$HOME/.local/opt/dnet"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"

if [ "$1" = "--remove" ]; then
	"$DEST/dnet" --autostart off 2>/dev/null || true
	rm -rf "$DEST" "$BIN/dnet" "$APPS/dnet.desktop"
	echo "DNet удалён (данные в ~/.dnet остались)"
	exit 0
fi

mkdir -p "$DEST" "$BIN" "$APPS"
cp "$HERE/dnet" "$DEST/dnet"; chmod 755 "$DEST/dnet"
for d in extension extension-firefox; do [ -d "$HERE/$d" ] && { rm -rf "$DEST/$d"; cp -r "$HERE/$d" "$DEST/$d"; }; done
ln -sf "$DEST/dnet" "$BIN/dnet"
cat > "$APPS/dnet.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=DNet
Comment=Сеть, которая работает без интернета
Exec=$DEST/dnet --gui
Terminal=false
Categories=Network;
DESK
echo "Установлено в $DEST. Запуск: dnet --gui (окно), dnet --tray (в трей), dnet (консоль)."
printf "Запускать DNet при входе в систему? [y/N] "
read -r ans || ans=n
case "$ans" in y|Y|д|Д) "$DEST/dnet" --autostart on ;; esac
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Добавьте $BIN в PATH, чтобы команда dnet работала везде." ;; esac
