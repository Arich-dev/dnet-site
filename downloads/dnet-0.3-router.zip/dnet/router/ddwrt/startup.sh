#!/bin/sh
# Вставить в Administration → Commands → «Save Startup».
# Бинарник dnetd лежит на /jffs (включить JFFS) или на USB, например /mnt/dnetd.
BIN=/jffs/dnetd
[ -x "$BIN" ] || exit 0
# лог — в RAM, перезапуск каждые 5 секунд, если демон упал
(while true; do "$BIN" -l /tmp/dnetd.log; sleep 5; done) &
