# dnetd — маяк DNet для роутеров

Крошечный демон на C (только libc): отвечает соседям на `hello`/`peers`, рассылает UDP-маяк, страниц не хранит.

```sh
python router/build.py                 # бинарники под 6 архитектур -> dist/router/ (нужен pip install ziglang)
sh router/install.sh                   # НА РОУТЕРЕ: определяет архитектуру и систему, ставит и запускает
```

| Каталог / файл | Назначение |
|---|---|
| `dnetd.c` | Исходник |
| `build.py`, `Makefile` | Кросс-сборка через zig; обычная сборка `make` |
| `install.sh` | Установка/удаление на роутере (`--remove`) |
| `openwrt/` | Служба procd, настройки `/etc/config/dnetd`, пакет для SDK (`package/dnetd`) |
| `keenetic/`, `ddwrt/`, `netbsd/` | Автозапуск для Keenetic/Entware, DD-WRT, NetBSD/FreeBSD |

Полная инструкция: [../docs/ROUTERS.md](../docs/ROUTERS.md).
