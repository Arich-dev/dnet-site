#!/bin/sh
# Установка маяка dnetd на роутер. Запускать НА РОУТЕРЕ (по ssh) из папки, где лежат бинарники dnetd-<арх>:
#   scp -r router/ root@192.168.1.1:/tmp/dnet && ssh root@192.168.1.1 'sh /tmp/dnet/install.sh'
# Определяет архитектуру и систему сам. Ключи: --remove (удалить), --no-start.
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ACTION=install; START=1
for a in "$@"; do
	case "$a" in
		--remove|--uninstall) ACTION=remove ;;
		--no-start) START=0 ;;
	esac
done

arch() {
	if [ -f /etc/openwrt_release ]; then
		. /etc/openwrt_release
		case "$DISTRIB_ARCH" in
			mipsel*) echo mipsel; return ;;
			mips64el*) echo mipsel; return ;;
			mips*) echo mips; return ;;
			aarch64*) echo aarch64; return ;;
			arm*) echo arm; return ;;
			x86_64) echo x86_64; return ;;
			i386*) echo x86; return ;;
		esac
	fi
	m=$(uname -m)
	case "$m" in
		mips*)
			# порядок байтов: little-endian даёт «1» в первом слове
			if [ "$(printf 'I' | od -to2 | head -n1 | awk '{print substr($2,6,1)}')" = 1 ]; then echo mipsel; else echo mips; fi ;;
		aarch64|arm64) echo aarch64 ;;
		arm*) echo arm ;;
		x86_64|amd64) echo x86_64 ;;
		i?86) echo x86 ;;
		*) echo "unknown:$m" ;;
	esac
}

if [ -f /etc/openwrt_release ]; then SYS=openwrt
elif [ -d /opt/etc/init.d ]; then SYS=entware
elif [ -x /usr/sbin/nvram ] && nvram get DD_BOARD >/dev/null 2>&1 && [ -n "$(nvram get DD_BOARD)" ]; then SYS=ddwrt
elif command -v systemctl >/dev/null 2>&1; then SYS=systemd
else SYS=generic; fi

if [ "$ACTION" = remove ]; then
	case "$SYS" in
		openwrt) /etc/init.d/dnetd stop 2>/dev/null || true; /etc/init.d/dnetd disable 2>/dev/null || true
		         rm -f /usr/bin/dnetd /etc/init.d/dnetd /etc/config/dnetd ;;
		entware) /opt/etc/init.d/S99dnetd stop 2>/dev/null || true; rm -f /opt/bin/dnetd /opt/etc/init.d/S99dnetd ;;
		systemd) systemctl disable --now dnetd 2>/dev/null || true; rm -f /etc/systemd/system/dnetd.service /usr/local/sbin/dnetd ;;
		*) killall dnetd 2>/dev/null || true; rm -f /jffs/dnetd /usr/local/sbin/dnetd ;;
	esac
	echo "dnetd удалён"
	exit 0
fi

A=$(arch)
BIN="$HERE/dnetd-$A"
[ -f "$BIN" ] || BIN="$HERE/../dist/router/dnetd-$A"
[ -f "$BIN" ] || { echo "Нет бинарника для архитектуры '$A' (система: $SYS). Соберите: python3 router/build.py или make"; exit 1; }
echo "Архитектура: $A, система: $SYS"

case "$SYS" in
	openwrt)
		cp "$BIN" /usr/bin/dnetd; chmod 755 /usr/bin/dnetd
		cp "$HERE/openwrt/dnetd.init" /etc/init.d/dnetd; chmod 755 /etc/init.d/dnetd
		[ -f /etc/config/dnetd ] || cp "$HERE/openwrt/dnetd.config" /etc/config/dnetd
		/etc/init.d/dnetd enable
		[ "$START" = 1 ] && /etc/init.d/dnetd restart ;;
	entware)
		cp "$BIN" /opt/bin/dnetd; chmod 755 /opt/bin/dnetd
		cp "$HERE/keenetic/S99dnetd" /opt/etc/init.d/S99dnetd; chmod 755 /opt/etc/init.d/S99dnetd
		[ "$START" = 1 ] && /opt/etc/init.d/S99dnetd restart ;;
	ddwrt)
		cp "$BIN" /jffs/dnetd; chmod 755 /jffs/dnetd
		echo "Скопировано в /jffs/dnetd. Вставьте содержимое ddwrt/startup.sh в Administration → Commands → Save Startup."
		[ "$START" = 1 ] && (/jffs/dnetd -l /tmp/dnetd.log &) ;;
	systemd)
		cp "$BIN" /usr/local/sbin/dnetd; chmod 755 /usr/local/sbin/dnetd
		cat > /etc/systemd/system/dnetd.service <<UNIT
[Unit]
Description=DNet beacon
After=network-online.target

[Service]
ExecStart=/usr/local/sbin/dnetd -l /tmp/dnetd.log
Restart=always

[Install]
WantedBy=multi-user.target
UNIT
		systemctl daemon-reload; systemctl enable dnetd
		[ "$START" = 1 ] && systemctl restart dnetd ;;
	*)
		cp "$BIN" /usr/local/sbin/dnetd 2>/dev/null || cp "$BIN" /tmp/dnetd
		echo "Автозапуск этой системы неизвестен. Запускайте: dnetd -l /tmp/dnetd.log &"
		[ "$START" = 1 ] && (/usr/local/sbin/dnetd -l /tmp/dnetd.log >/dev/null 2>&1 &) ;;
esac
echo "Готово. Проверка: в панели DNet на компьютере роутер появится в «Соседях» (тип «РОУТЕР»)."
