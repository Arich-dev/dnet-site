"""Кросс-сборка маяка dnetd под все популярные архитектуры роутеров (без SDK, нужен только zig).

    pip install ziglang
    python router/build.py          ->  dist/router/dnetd-<arch>  (+ SHA256SUMS)

Статические бинарники (musl), работают на OpenWrt, Keenetic/Entware, DD-WRT, Padavan и любом Linux.
"""
import sys as _s
if hasattr(_s.stdout, "reconfigure"):
    _s.stdout.reconfigure(encoding="utf-8", errors="replace")
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "dist" / "router"
# имя архитектуры -> цель zig. mips/mipsel без FPU (soft-float) — как в большинстве роутеров
TARGETS = {
    "mipsel": "mipsel-linux-musleabi",
    "mips": "mips-linux-musleabi",
    "arm": "arm-linux-musleabi",
    "aarch64": "aarch64-linux-musl",
    "x86": "x86-linux-musl",
    "x86_64": "x86_64-linux-musl",
}


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    sums = []
    for arch, target in TARGETS.items():
        dst = OUT / f"dnetd-{arch}"
        cmd = [sys.executable, "-m", "ziglang", "cc", "-target", target, "-Os", "-s", "-static", "-Wall",
               "-o", str(dst), str(ROOT / "router" / "dnetd.c")]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            raise SystemExit(f"{arch}: сборка не удалась\n{r.stderr}")
        h = hashlib.sha256(dst.read_bytes()).hexdigest()
        sums.append(f"{h}  {dst.name}")
        print(f"{dst.name:18} {dst.stat().st_size / 1024:6.1f} КБ")
    (OUT / "SHA256SUMS").write_text("\n".join(sums) + "\n")


if __name__ == "__main__":
    build()
